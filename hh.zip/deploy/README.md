# Deploy runbook

Everything below assumes the repository is in a Git provider and you have
credentials for the host. The application itself needs three things at runtime:
a Node process, a PostgreSQL database and an OpenRouter key.

---

## What is already in the repository

| File | Purpose |
|---|---|
| `Dockerfile.api` | Multi-stage API image, runs as a non-root user, has a healthcheck |
| `Dockerfile.web` | Builds the SPA and serves it with nginx |
| `deploy/nginx.conf` | Production reverse proxy, with SSE buffering disabled |
| `docker-compose.yml` | Complete three-service stack for one host or a VPS |
| `render.yaml` | Render blueprint (API + managed PostgreSQL) |
| `apps/web/vercel.json` | Vercel build config with SPA rewrites and cache headers |
| `.env.example` | Every variable, with no real values |

---

## Path A — one server (VPS, Hetzner, DigitalOcean, any box with Docker)

The shortest path, and the only one where the browser sees a single origin.

```bash
# on the server
git clone <repo> orbit-ai && cd orbit-ai
cp .env.example .env
```

Edit `.env` and set at minimum:

```dotenv
POSTGRES_PASSWORD=<a long random string>
SESSION_SECRET=<node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))">
CSRF_SECRET=<same command, run again>
OPENROUTER_API_KEY=sk-or-v1-…
ADMIN_EMAIL=you@yourdomain.com
ADMIN_PASSWORD=<12+ characters>
WEB_URL=https://yourdomain.com
API_URL=https://yourdomain.com
```

Then:

```bash
docker compose up -d --build
docker compose run --rm api node scripts/with-env.mjs npx prisma migrate deploy
docker compose run --rm api node scripts/with-env.mjs npx tsx prisma/seed.ts
```

Put your own nginx/Caddy in front of port 8080 for TLS, or use
`deploy/nginx.conf` as the template. The compose stack already serves the SPA
and proxies `/api` and `/media` to the API container.

**Verify**

```bash
curl https://yourdomain.com/api/health
curl https://yourdomain.com/api/health/openrouter
```

Expected:

```json
{"success":true,"data":{"configured":true,"model":"openrouter/free","status":"ok"}}
```

Then open the site, register, send a message, and confirm the credit counter
drops by one.

---

## Path B — split hosting (Vercel + Render/Railway + Neon/Supabase)

### B1. Database

Create a PostgreSQL database on Neon, Supabase or Render and copy its
connection string.

### B2. API on Render

`render.yaml` is a blueprint: Render creates the database, wires
`DATABASE_URL`, runs `prisma migrate deploy` before each deploy and health-checks
`/api/health`. Push the repo and choose **New → Blueprint**.

On Railway the same thing is a `railway.json` or simply the Dockerfile plus
these variables in the service settings:

| Variable | Value |
|---|---|
| Build | `npm ci && npm run build:shared && npm run build:api` |
| Start | `cd apps/api && node dist/index.js` |
| Health path | `/api/health` |

Required variables: `DATABASE_URL`, `SESSION_SECRET`, `CSRF_SECRET`,
`OPENROUTER_API_KEY`, `API_URL`, `WEB_URL`. See `.env.example` for the rest.

### B3. Frontend on Vercel

| Setting | Value |
|---|---|
| Root directory | repository root |
| Framework preset | Other |
| Build command | `npm run build:shared && npm run build:web` |
| Output directory | `apps/web/dist` |

Then set `VITE_API_URL=https://api.your-host.com` and rebuild, **or** leave it
empty and add a rewrite that proxies `/api` to the API host — the empty option
is better because it keeps the session cookie first-party.

If you use a separate API origin, set the frontend origin in the API's
`WEB_URL` (and `CORS_EXTRA_ORIGINS` if you have more than one).

### B4. Storage

Local disk does not survive a redeploy on Render/Railway unless you attach a
disk. Either attach one (`/app/apps/api/var/uploads`) or switch to object
storage:

```dotenv
STORAGE_PROVIDER=s3
STORAGE_PUBLIC_BASE_URL=https://cdn.yourdomain.com
S3_ENDPOINT=https://<account>.r2.cloudflarestorage.com   # or leave empty for AWS
S3_REGION=auto
S3_BUCKET=orbit-media
S3_ACCESS_KEY_ID=…
S3_SECRET_ACCESS_KEY=…
```

---

## Path C — Cloudflare Pages + Workers-compatible host

`apps/web/dist` uploads to Pages with:

| Setting | Value |
|---|---|
| Build command | `npm run build:shared && npm run build:web` |
| Output directory | `apps/web/dist` |

Cloudflare Pages does not run long-lived Node servers, so the API must live
elsewhere (Railway, Fly, Render, or a VPS). Remember to allow the Pages origin
in the API's `WEB_URL`.

---

## After every deploy — the checklist

```bash
curl -s https://YOUR-DOMAIN/api/health | jq
curl -s https://YOUR-DOMAIN/api/health/openrouter | jq
curl -s https://YOUR-DOMAIN/api/health/database | jq
```

- [ ] `/api/health` reports `"status":"ok"`
- [ ] `/api/health/openrouter` reports `"configured":true`
- [ ] `/api/health/database` responds
- [ ] Registering a new account works and shows the signup bonus
- [ ] Sending a message streams tokens in
- [ ] The credit counter drops by exactly one
- [ ] Stopping mid-generation refunds the credit
- [ ] Signing in as the administrator opens `/admin`
- [ ] Changing the site name in Customization updates the header immediately
- [ ] No `sk-…` string appears in the browser network tab or the page source

## Rotating the OpenRouter key

The key lives only in the API's environment. Update it on the host, restart the
service, and confirm with `curl -s https://YOUR-DOMAIN/api/health/openrouter`.
It never needs to be changed anywhere else — not in the frontend, not in the
database.
