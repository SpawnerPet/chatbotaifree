# Orbit AI

A production AI chat platform: real authentication, a real streaming AI
provider (OpenRouter), an internal credit ledger, an admin panel, and full
site customisation from the database — no code edits, no redeploys.

The name, logo, favicon, copy, colours, typography, background media and
background music are all controlled from **Admin → Customization**.

---

## Table of contents

1. [What it does](#1-what-it-does)
2. [Architecture](#2-architecture)
3. [Requirements](#3-requirements)
4. [Installation](#4-installation)
5. [Environment variables](#5-environment-variables)
6. [Database setup](#6-database-setup)
7. [Running in development](#7-running-in-development)
8. [Testing](#8-testing)
9. [Production build](#9-production-build)
10. [Deployment](#10-deployment)
11. [Storage configuration](#11-storage-configuration)
12. [OpenRouter configuration](#12-openrouter-configuration)
13. [Admin configuration](#13-admin-configuration)
14. [Credit system](#14-credit-system)
15. [API reference](#15-api-reference)
16. [Security notes](#16-security-notes)
17. [Project structure](#17-project-structure)
18. [Troubleshooting](#18-troubleshooting)

---

## 1. What it does

**Public**

- Landing page (hero, chat preview, features, how it works, CTA, footer)
- Register / sign in / sign out / forgot password / reset password
- Account settings: profile, password, active sessions, credit history, usage

**Chat**

- New conversation, rename, delete, search (title *and* message content)
- Streaming answers over Server-Sent Events, with a working **Stop** button
- Regenerate an answer, edit a user message and resend, retry a failure
- Markdown with GitHub-flavoured tables, task lists and strikethrough
- Code blocks with syntax highlighting, a language label and one-click copy
- Model picker (server-enforced allow-list)
- Full keyboard support, screen-reader labels, dark and light themes

**Admin** (`/admin`)

- Live dashboard: users, active/suspended/banned, credits outstanding,
  credits granted/consumed/refunded, conversations, messages, AI requests
  split into succeeded / failed / aborted
- User management: search, filter, paginate, view detail, suspend, activate,
  ban, promote/demote, grant or remove credits, full credit history
- Audit log of every privileged action, with the administrator who did it
- Media library: logo, favicon, background image, animated GIF, background
  video (MP4/WebM) and background music (MP3)
- Customisation: site name, tagline, landing and sign-in copy, chat welcome
  message, suggestion prompts, accent/background/text/border colours, button
  style, typography, default theme, background type, overlay strength,
  music volume and autoplay preference, and a constrained custom-CSS escape
  hatch

**Platform**

- PostgreSQL via Prisma with migrations, indexes, foreign keys and cascades
- HttpOnly session cookies, double-submit CSRF, brute-force rate limiting
- Local disk or any S3-compatible object storage
- Health endpoints, structured JSON logs with secret redaction

---

## 2. Architecture

```
Browser
  │  fetch (credentials: include)  +  X-CSRF-Token on mutations
  ▼
┌──────────────────────┐        ┌──────────────────────────────┐
│  apps/web            │        │  apps/api                    │
│  React + TypeScript  │───────▶│  Express + TypeScript        │
│  Vite + Tailwind v4  │  SSE   │                              │
└──────────────────────┘        │  routes → controllers →      │
                                │  services → Prisma           │
                                └───────┬──────────┬───────────┘
                                        │          │
                                        ▼          ▼
                              ┌──────────────┐  ┌──────────────────┐
                              │  PostgreSQL  │  │  OpenRouter API  │
                              └──────────────┘  └──────────────────┘
```

**The browser never talks to OpenRouter.** The API key lives only in the
server's environment and is read in exactly one file
(`apps/api/src/services/openrouter.service.ts`). It is never returned by an
endpoint, never logged, never written to the database and never sent to the
client.

### Request flow for a chat turn

1. `POST /api/chat/stream` — session resolved, CSRF checked, rate limited.
2. Body validated with Zod; the requested model checked against the allow-list.
3. **Credit check before any provider call.** Zero balance ⇒ the provider is
   never contacted.
4. A user message is persisted and an `AiRequest` row is opened.
5. Credit is deducted with one atomic `UPDATE … WHERE credits >= cost`.
6. Tokens stream to the browser as `meta` / `delta` / `done` SSE frames.
7. On success the assistant message is stored and the request marked
   `SUCCEEDED`.
8. On failure or abort the credit is **refunded in full**, the request is
   marked `FAILED` / `ABORTED`, and no assistant message is written.

---

## 3. Requirements

| | Version |
|---|---|
| Node.js | ≥ 20.10 (developed on 22) |
| npm | ≥ 10 (workspaces) |
| PostgreSQL | ≥ 14 (developed on 15) |
| OpenRouter | an API key with access to `openrouter/free` |

Docker is optional but supported (`Dockerfile.api`, `Dockerfile.web`,
`docker-compose.yml`).

---

## 4. Installation

```bash
git clone <your-repo> orbit-ai
cd orbit-ai
npm install
cp .env.example .env
```

Then edit `.env` and fill in at least:

```dotenv
DATABASE_URL=postgresql://user:password@localhost:5432/orbit?schema=public
SESSION_SECRET=<48+ random bytes>
CSRF_SECRET=<48+ random bytes>
OPENROUTER_API_KEY=sk-or-v1-…
```

Generate the two secrets with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

---

## 5. Environment variables

| Variable | Required | Default | Purpose |
|---|:--:|---|---|
| `NODE_ENV` | | `development` | `production` enables secure cookies, HSTS and generic errors |
| `PORT` | | `4000` | API port |
| `LOG_LEVEL` | | `info` | `silent` \| `error` \| `warn` \| `info` \| `debug` |
| `API_URL` | | `http://localhost:4000` | Public URL of the API |
| `WEB_URL` | | `http://localhost:5173` | Public URL of the frontend; first entry in the CORS allow-list |
| `CORS_EXTRA_ORIGINS` | | | Comma-separated extra allowed origins |
| `DATABASE_URL` | ✔ | | PostgreSQL connection string |
| `SESSION_SECRET` | ✔ | | ≥ 16 chars |
| `CSRF_SECRET` | ✔ | | ≥ 16 chars |
| `SESSION_TTL_DAYS` | | `14` | Session lifetime |
| `PASSWORD_RESET_TTL_MINUTES` | | `30` | Reset-token lifetime |
| `OPENROUTER_API_KEY` | ✔ | | **Server-side only.** Enables the AI provider |
| `OPENROUTER_API_KEYS` | | | Extra keys, comma separated. Rotated automatically |
| `OPENROUTER_KEY_COOLDOWN_SECONDS` | | `300` | How long a benched key waits before being retried |
| `OPENROUTER_KEY_MAX_FAILURES` | | `3` | Non-quota failures after which a key is parked until restart |
| `OPENROUTER_MODEL` | | `openrouter/free` | Default model |
| `OPENROUTER_BASE_URL` | | `https://openrouter.ai/api/v1` | Override for compatible gateways |
| `OPENROUTER_ALLOWED_MODELS` | | `openrouter/free` | Comma-separated picker allow-list |
| `OPENROUTER_TIMEOUT_MS` | | `120000` | Non-streaming timeout |
| `OPENROUTER_STREAM_TIMEOUT_MS` | | `180000` | Total streaming lifetime |
| `OPENROUTER_MAX_RETRIES` | | `2` | Retries for transient failures |
| `SIGNUP_BONUS_CREDITS` | | `100` | Credits granted at registration |
| `CHAT_COST_CREDITS` | | `1` | Cost of one successful answer |
| `ADMIN_EMAIL` | | | Seeds/updates the administrator |
| `ADMIN_PASSWORD` | | | ≥ 12 characters |
| `ADMIN_USERNAME` | | `admin` | |
| `STORAGE_PROVIDER` | | `local` | `local` \| `s3` |
| `STORAGE_LOCAL_DIR` | | `var/uploads` | Relative to `apps/api` |
| `STORAGE_PUBLIC_BASE_URL` | | `<API_URL>/media` | Base for locally served files |
| `S3_ENDPOINT` | | | e.g. `https://<account>.r2.cloudflarestorage.com` |
| `S3_REGION` | | `auto` | |
| `S3_BUCKET` | | | Required when `STORAGE_PROVIDER=s3` |
| `S3_ACCESS_KEY_ID` / `S3_SECRET_ACCESS_KEY` | | | Required when `STORAGE_PROVIDER=s3` |
| `S3_FORCE_PATH_STYLE` | | `true` | Keep on for R2 / MinIO |
| `MAX_IMAGE_UPLOAD_BYTES` | | `5242880` | |
| `MAX_VIDEO_UPLOAD_BYTES` | | `26214400` | |
| `MAX_AUDIO_UPLOAD_BYTES` | | `10485760` | |

`apps/web/.env` (optional):

| Variable | Purpose |
|---|---|
| `VITE_API_URL` | Absolute API base URL. **Leave empty for same-origin** (recommended) |
| `VITE_API_PROXY` | Dev-server proxy target, default `http://localhost:4000` |

`.env` is git-ignored. Only `.env.example` is committed, and it contains no
real values.

---

## 6. Database setup

```bash
# Development: creates the DB and applies migrations
npm run db:migrate -- --name init

# Production / CI: applies committed migrations only
npm run db:deploy

# Create the settings row and the administrator
npm run db:seed
```

Convenience wrapper:

```bash
npm run setup     # generate client + deploy migrations + seed
```

Migrations live in `apps/api/prisma/migrations/` and are committed.

**Bootstrap rule for administrators:** if `ADMIN_EMAIL` and `ADMIN_PASSWORD`
are set, the seed creates or updates that account and grants it the `ADMIN`
role. If they are absent and no administrator exists yet, the **first account
ever registered becomes an administrator**. There is no hard-coded
credential anywhere in the codebase.

---

## 7. Running in development

```bash
npm run dev
```

Runs three watchers in parallel:

| Process | URL |
|---|---|
| API | http://localhost:4000 |
| Web (Vite, proxies `/api` and `/media`) | http://localhost:5173 |
| Shared package (rebuilds on change) | — |

To exercise the production bundle locally:

```bash
npm run build
npm run dev:api        # API on :4000
npm run serve:dist     # built SPA on :4173, proxying /api
```

---

## 8. Testing

```bash
npm test               # 73 API tests (Vitest + supertest)
npm run lint           # ESLint, zero warnings allowed
npm run typecheck      # tsc for every workspace
npm run build          # production build for every workspace
npm run verify         # all of the above, in order
```

The API suite needs a **separate** PostgreSQL database. It refuses to run
against anything but `orbit_test`:

```
postgresql://orbit:orbit_dev_pw@127.0.0.1:5432/orbit_test
```

Set `TEST_DATABASE_URL` to point somewhere else. The schema is applied with
`prisma db push --force-reset` in the Vitest global setup.

Coverage by file:

| File | What it proves |
|---|---|
| `auth.test.ts` | registration, bcrypt hashing, signup bonus, login, logout, session invalidation, timing-equalised failures, suspended/banned accounts, CSRF enforcement, one-time password reset, password change, session listing and revocation, no stack traces in responses |
| `authorization.test.ts` | a normal user gets 403 on all seven admin routes, cannot escalate their own role or credits, anonymous requests get 401, cross-user conversation access returns 404 |
| `credit.test.ts` | charge on success, full refund on provider failure with no assistant message stored, **no provider call at zero credits**, 402 on the non-streaming path, no negative balance under 8 concurrent requests, refund on client abort, model allow-list, the API key never appears in a response |
| `admin.test.ts` | real statistics, search/filter/pagination, add credits with ledger + audit rows, remove credits and refuse to go negative, suspend revokes sessions, ban, self-demotion blocked, last administrator protected, user detail, audit filtering |
| `conversations.test.ts` | CRUD, streamed answers persisted in order, search by title and by message content, pagination, regenerate (and charge), failed regenerate refunds, edit truncates later replies, assistant messages are not editable, input validation |
| `openrouter.test.ts` | success, bearer header, 429/404 mapping, malformed JSON, empty response, timeout, retry on 503, streaming deltas, recovery from a malformed frame, failing a fully malformed stream, reasoning-only fallback, retry on an empty stream, abort, model allow-list |
| `customization.test.ts` | public settings, live re-branding persisted to the database, dangerous CSS rejected, colour validation, PNG upload + audit + storage key shape, MP3 upload, HTML-disguised-as-PNG rejected, mismatched declared type rejected, background application, audio refused as background, delete with fallback, 404 on unknown media |

**Browser tests** (`npm run test:e2e`) drive real Chromium through the
production build — 43 checks covering the landing page, sign-in, a real
streamed answer, credit accounting, sidebar search, syntax highlighting, copy,
GFM tables, regenerate, edit-and-resend, rename, theme switch, settings, the
admin dashboard, user search, granting credits, the audit log, media upload,
live re-branding, rejection of dangerous custom CSS, and mobile/tablet layouts
with no horizontal overflow. Where the provider is unavailable the suite
asserts the *correct* behaviour (error shown, credit refunded, no assistant
message stored) rather than skipping quietly. See
[`e2e/README.md`](e2e/README.md).

---

## 9. Production build

```bash
npm run build
```

Produces:

- `packages/shared/dist` — types and Zod schemas shared by both apps
- `apps/api/dist` — compiled Node ESM
- `apps/web/dist` — static assets, code-split per route

Bundle notes: React, TanStack Query and the markdown/highlight toolchain are
split into separate long-cached chunks; the admin screens are lazy-loaded, so
a normal visitor never downloads them.

---

## 10. Deployment

### 10.1 Everything with Docker (recommended starting point)

```bash
cp .env.example .env       # fill in secrets + OPENROUTER_API_KEY
docker compose up -d --build
docker compose run --rm api node scripts/with-env.mjs npx prisma migrate deploy
docker compose run --rm api node scripts/with-env.mjs npx tsx prisma/seed.ts
open http://localhost:8080
```

nginx serves the SPA on `:8080` and proxies `/api` and `/media` to the API
container. Because the browser sees a single origin, the session cookie is
first-party and there is no CORS preflight in the normal path.

### 10.2 Split hosting (Vercel / Cloudflare Pages + Railway / Render / Fly)

**Frontend → Vercel or Cloudflare Pages**

| Setting | Value |
|---|---|
| Build command | `npm ci && npm run build:web` |
| Output directory | `apps/web/dist` |
| Node version | 22 |
| `VITE_API_URL` | `https://api.your-domain.com` *(leave empty if you proxy `/api` on the same host instead)* |

**Backend → Railway / Render / Fly / any VPS**

| Setting | Value |
|---|---|
| Build command | `npm ci && npm run build:shared && npm run build:api` |
| Start command | `cd apps/api && node dist/index.js` |
| Health check | `/api/health` |

Environment: everything from `.env.example`, with `WEB_URL` set to the
frontend origin and `API_URL` to the backend origin. Add the frontend origin
to `CORS_EXTRA_ORIGINS` if it is not `WEB_URL`.

**Database** — Neon, Supabase, Railway Postgres, RDS… any managed PostgreSQL.
Set `DATABASE_URL`, then run `npm run db:deploy` once (as a release command
or a one-off task) to apply migrations.

**Storage** — set `STORAGE_PROVIDER=s3` and the `S3_*` variables. Use a
persisted volume instead if you keep `STORAGE_PROVIDER=local`.

### 10.3 Single host with nginx

```bash
npm ci && npm run build
cd apps/api && node dist/index.js          # behind nginx / systemd / pm2
```

Serve `apps/web/dist` with an SPA fallback and proxy `/api` and `/media` to
the Node process. A working configuration is in
[`deploy/nginx.conf`](deploy/nginx.conf); it also disables proxy buffering on
`/api/chat/stream` so Server-Sent Events are not delayed.

See [`deploy/README.md`](deploy/README.md) for a copy-paste runbook with a
post-deploy checklist.

### 10.4 Post-deploy verification

```bash
curl https://your-domain/api/health
# {"success":true,"data":{"status":"ok",...}}

curl https://your-domain/api/health/openrouter
# {"success":true,"data":{"configured":true,"model":"openrouter/free","status":"ok"}}
```

Then, in a browser: register → send a message → confirm tokens stream in →
confirm the credit count drops by one → sign in as the administrator → open
`/admin` → change the site name and watch the header update.

> **Deployment status of this repository:** the code, migrations, seed, tests,
> Docker images and hosting configuration are all complete and verified
> locally. It has **not** been deployed to a public host from this
> environment — the sandbox only exposes a static-site publisher, which cannot
> host the Node API or PostgreSQL that this product requires. Publishing the
> frontend alone would produce a site whose login and chat do not work, so it
> was deliberately not done. Follow one of the three routes above.

---

## 11. Storage configuration

`StorageService` is an interface with two implementations, selected by
`STORAGE_PROVIDER`.

**`local`** (development, or a single host with a volume) writes under
`apps/api/var/uploads/<kind>/<yyyy>/<mm>/<random>.ext` and is served from
`/media/*` with `X-Content-Type-Options: nosniff` and a strict
`Content-Security-Policy`.

**`s3`** works with AWS S3, Cloudflare R2, Supabase Storage, MinIO and Backblaze
B2. Set `S3_ENDPOINT`, `S3_REGION`, `S3_BUCKET`, `S3_ACCESS_KEY_ID`,
`S3_SECRET_ACCESS_KEY` and `STORAGE_PUBLIC_BASE_URL` (the public base URL of
the bucket). Objects are served with a one-year immutable cache header.

Binaries are **never** stored in the database — the `media` table holds only
the key, MIME type, size and dimensions.

---

## 12. OpenRouter configuration

- Default model: `openrouter/free`, which the router maps to a currently
  available free model.
- Change the default with `OPENROUTER_MODEL`.
- Offer a picker by listing models in `OPENROUTER_ALLOWED_MODELS`
  (comma-separated). Anything not on that list is rejected server-side, even
  if a client asks for it.
- `GET /api/health/openrouter` returns exactly three fields and never the key:

  ```json
  { "configured": true, "model": "openrouter/free", "status": "ok" }
  ```

`OpenRouterService` owns retries with exponential backoff, per-request
timeouts, abort propagation, 429/404/5xx classification, malformed-payload
detection, partial-frame tolerance and the reasoning-only fallback. Retries
stop as soon as the first token has been sent to the client, so a retry can
never duplicate output.

### Automatic key rotation

Free tiers run out. Rather than failing every user's request when one key is
exhausted, the service keeps a **pool of keys** and rotates:

```dotenv
OPENROUTER_API_KEY=sk-or-v1-primary
OPENROUTER_API_KEYS=sk-or-v1-second,sk-or-v1-third
```

| Provider response | Effect |
|---|---|
| `401`, `402`, `403`, `429` | The key is **benched** for `OPENROUTER_KEY_COOLDOWN_SECONDS` and the request is retried immediately on the next key — no user-visible failure and no waiting |
| `5xx`, timeout | Provider-side problem, not a key problem: the same key is retried with backoff |
| Repeated non-quota failures | The key is **parked** until the process restarts |

When every key is benched, the request fails fast with
`AI_PROVIDER_RATE_LIMITED` and the user's credit is refunded, exactly as with
any other provider failure.

Keys live in memory only. They are never persisted, never logged, and never
returned by an API — `GET /api/health/openrouter` reports only counts, and the
admin panel shows masked labels like `key #1 ····a1b2`.

---

## 13. Admin configuration

1. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` (12+ characters) in `.env`.
2. `npm run db:seed`.
3. Sign in and open `/admin`.

The seed is idempotent: re-running it updates the same account's password and
role rather than creating a duplicate.

The first user to register on a brand-new deployment is promoted to
administrator automatically, so you can also bootstrap through the UI.

---

## 14. Credit system

Credits are an internal control mechanism for using the chatbot. They are not
OpenRouter money — the deployment still uses whatever provider and model are
configured.

Rules enforced by the server:

- A new user receives `SIGNUP_BONUS_CREDITS` (default 100).
- Each **successful** answer costs `CHAT_COST_CREDITS` (default 1).
- A failed or aborted request costs nothing — the charge is refunded in full
  and the refund is recorded.
- At zero credits the provider is never called at all; the user is told why.
- Balances can never go negative.

Every change writes a `CreditTransaction` row with `amount`, `type`,
`balanceBefore`, `balanceAfter`, `description` and the acting user.

| Type | Meaning |
|---|---|
| `SIGNUP_BONUS` | Welcome grant |
| `CHAT_USAGE` | A successful AI answer |
| `ADMIN_ADD` / `ADMIN_REMOVE` | An administrator adjusted a balance |
| `REFUND` | A failed or aborted request was refunded |
| `BONUS` / `SYSTEM_ADJUSTMENT` | Manual adjustments |

**Race conditions.** The charge is a single conditional statement:

```sql
UPDATE "users"
   SET "credits" = "credits" - $1, "updatedAt" = NOW()
 WHERE "id" = $2 AND "credits" >= $1
RETURNING "credits";
```

If it matches no row, the balance was too low. Concurrent requests therefore
cannot oversell credits, and the check-then-decrement is atomic at the
database level rather than in application code. `test/credit.test.ts` proves
this with eight simultaneous requests against a two-credit balance.

---

## 15. API reference

Every response uses one envelope:

```jsonc
{ "success": true,  "data": { } }
{ "success": false, "error": { "code": "INSUFFICIENT_CREDITS", "message": "Insufficient credits." } }
```

Unexpected errors are logged server-side and replaced with a generic message —
stack traces and driver text never reach the client.

### Auth

| Method | Path | Auth | Purpose |
|---|---|:--:|---|
| POST | `/api/auth/register` | | Create an account, grant the bonus, sign in |
| POST | `/api/auth/login` | | Sign in |
| POST | `/api/auth/logout` | | Sign out and destroy the session |
| GET | `/api/auth/me` | ✔ | Current user |
| POST | `/api/auth/forgot-password` | | Request a reset link (always the same reply) |
| POST | `/api/auth/reset-password` | | Consume a one-time token |
| POST | `/api/auth/change-password` | ✔ | Change password, revoke other sessions |
| GET | `/api/auth/sessions` | ✔ | List active sessions |
| DELETE | `/api/auth/sessions/:id` | ✔ | Revoke one session |
| POST | `/api/auth/sessions/revoke-others` | ✔ | Revoke all other sessions |

### Conversations and messages

| Method | Path | Auth | Purpose |
|---|---|:--:|---|
| GET | `/api/conversations?page&pageSize&search` | ✔ | List / search |
| POST | `/api/conversations` | ✔ | Create |
| GET | `/api/conversations/:id?cursor&limit` | ✔ | Detail with messages |
| PATCH | `/api/conversations/:id` | ✔ | Rename |
| DELETE | `/api/conversations/:id` | ✔ | Delete (messages cascade) |
| PATCH | `/api/messages/:id` | ✔ | Edit a user message; later replies are removed |
| DELETE | `/api/messages/:id` | ✔ | Delete a message |

### Chat

| Method | Path | Auth | Purpose |
|---|---|:--:|---|
| POST | `/api/chat/stream` | ✔ | Stream an answer (SSE) |
| POST | `/api/chat/regenerate` | ✔ | Regenerate the answer for a user message |
| POST | `/api/chat` | ✔ | Non-streaming variant |
| GET | `/api/models` | ✔ | Allowed models |

SSE frame types: `meta`, `delta`, `done`, `error`, `aborted`.

### User

| Method | Path | Auth | Purpose |
|---|---|:--:|---|
| GET | `/api/user/profile` | ✔ | Profile |
| PATCH | `/api/user/profile` | ✔ | Update username / avatar |
| GET | `/api/user/credits` | ✔ | Credit ledger |
| GET | `/api/user/usage` | ✔ | Usage summary |

### Public

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/settings` | Branding and site settings used by the SPA |
| GET | `/api/health` | Liveness + configuration summary |
| GET | `/api/health/openrouter` | Provider configuration (never the key) |
| GET | `/api/health/database` | Database reachability |

### Admin (all require `ADMIN`)

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/admin/stats` | Dashboard figures |
| GET | `/api/admin/users?search&role&status&sort&order` | List / filter / paginate |
| GET | `/api/admin/users/:id` | Detail with credit history and audit trail |
| POST | `/api/admin/users/:id/credits` | Add or remove credits |
| PATCH | `/api/admin/users/:id/status` | Activate / suspend / ban |
| PATCH | `/api/admin/users/:id/role` | Promote / demote |
| GET | `/api/admin/audit-logs?action&adminId&targetUserId` | Audit log |
| GET | `/api/admin/media?kind` | Media library |
| POST | `/api/admin/media?category&filename` | Upload (raw bytes) |
| DELETE | `/api/admin/media/:id` | Delete |
| PATCH | `/api/admin/settings` | Update site settings |

---

## 16. Security notes

- **Passwords** — bcrypt with cost 12. Plaintext is never stored or logged.
  A missing account still performs a bcrypt comparison so response timing does
  not reveal whether an email is registered.
- **Sessions** — an opaque 32-byte random token in an `HttpOnly`, `SameSite=Lax`
  cookie (`Secure` in production). Only its SHA-256 hash is stored, so a
  database leak cannot be replayed. `lastUsedAt` is written at most once every
  five minutes.
- **CSRF** — double-submit. The readable `orbit.csrf` cookie is derived with
  HMAC from the session hash and must be echoed in `X-CSRF-Token` on every
  mutating request.
- **Authorization** — role, status and credit balance are read from the
  database on every request. Fields the client sends about itself (role,
  credits, cost) are ignored; `test/authorization.test.ts` proves it.
- **Rate limiting** — 10 sign-in attempts / 15 min, 5 registrations / hour,
  5 password resets / hour, 30 AI requests / minute, plus a global ceiling.
  Skipped under `NODE_ENV=test`.
- **Validation** — every request body, query and parameter goes through Zod.
  The parsed result replaces the raw input, so handlers only see validated data.
- **Uploads** — a file must match an allow-list by **magic bytes**, by declared
  MIME type *and* by extension. HTML renamed to `.png` is rejected. Sizes are
  capped per category. Storage keys are generated server-side, sanitised, and
  verified to stay inside the upload root.
- **XSS** — raw HTML is not enabled in the Markdown renderer; model output is
  escaped. The custom-CSS field rejects `@import`, `javascript:` URLs and HTML
  tags, and is admin-only. External links get `rel="noopener noreferrer"`.
- **Headers** — Helmet, a strict CORS allow-list, `X-Content-Type-Options` on
  uploads, HSTS in production, `trust proxy` enabled for correct client IPs.
- **Error handling** — 5xx responses are always
  `INTERNAL_ERROR` / "Something went wrong on our side.".
- **Logging** — a JSON logger that scrubs `sk-…` patterns, `Bearer …` tokens
  and any object key matching secret/token/password/apikey/cookie.
- **Secrets** — read from the environment only. `.env` is git-ignored;
  `.env.example` contains no real values. Invalid configuration fails at
  startup with the offending **variable names** only, never their values.

---

## 17. Project structure

```
.
├── apps
│   ├── api
│   │   ├── prisma
│   │   │   ├── schema.prisma
│   │   │   ├── migrations/
│   │   │   └── seed.ts
│   │   ├── scripts/with-env.mjs      # runs a command with the root .env
│   │   ├── src
│   │   │   ├── config/env.ts         # validated environment
│   │   │   ├── lib/                  # prisma, logger, errors, crypto, password, presenters
│   │   │   ├── middleware/           # auth, admin, csrf, rate-limit, validate, error-handler
│   │   │   ├── services/             # openrouter, credit, storage, media, settings, auth, audit
│   │   │   ├── controllers/          # request handlers
│   │   │   ├── routes/               # routing tables
│   │   │   ├── app.ts                # express assembly
│   │   │   └── index.ts              # bootstrap, graceful shutdown
│   │   └── test/                     # Vitest + supertest suites
│   └── web
│       └── src
│           ├── components/            # ui, layout, chat, admin
│           ├── context/               # providers (split from their hooks)
│           ├── hooks/                 # useChatStream, useDebouncedValue, …
│           ├── lib/                   # api client, utilities
│           └── pages/                 # landing, auth, chat, settings, admin
├── packages/shared                    # Zod schemas, DTOs, error codes, constants
├── deploy/nginx.conf                  # production reverse proxy
├── e2e                                # browser checks + local static server
├── Dockerfile.api / Dockerfile.web / docker-compose.yml
└── .env.example
```

---

## 18. Troubleshooting

**`Invalid environment configuration`** — a required variable is missing or
malformed. The error lists variable *names* only. Check `DATABASE_URL`,
`SESSION_SECRET`, `CSRF_SECRET` and `OPENROUTER_API_KEY`.

**`Environment variable not found: DATABASE_URL` from Prisma** — run Prisma
through the wrapper, which loads the root `.env`:
`npm run db:migrate`, not bare `npx prisma …`.

**`The AI provider is not configured`** — `OPENROUTER_API_KEY` is empty.
Check `/api/health/openrouter`.

**`429` / "The AI provider is rate limiting us"** — OpenRouter enforces a
per-day quota for free models (`free-models-per-day`). The app treats it as a
normal provider failure: the user sees a clear message, the credit is
refunded in full, no assistant message is stored, and the attempt is recorded
as `FAILED` in **Admin → Users → activity**. Adding credit to the OpenRouter
account raises the free quota; no code change is needed.

**Answers fail immediately and the balance never changes** — that is the
refund path working. The refund reason is visible in
**Admin → Users → credit history** and the error code in the API logs.

**`502` or a stuck stream behind a proxy** — proxy buffering must be off for
`/api/chat/stream`. Use `deploy/nginx.conf`, which already sets
`proxy_buffering off`.

**`Cross-origin` errors in development** — `WEB_URL` must match the exact
frontend origin including scheme and port. Requests whose `Origin` matches the
`Host` the API sees are already treated as same-origin, which covers the usual
reverse-proxy setup.

**Tests fail with a connection error** — the suite needs a reachable
PostgreSQL and the `orbit_test` database; `globalSetup` creates it.

**Uploads rejected immediately** — the file's real contents must match the
category. Inspect the bytes: an `.mp3` must be a real MPEG frame stream, not a
file with an `ID3` string in it.
