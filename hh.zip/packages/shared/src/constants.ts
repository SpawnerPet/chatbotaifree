/**
 * Domain constants shared between API and web.
 * Single source of truth so the two never drift.
 */

export const USER_ROLES = ['USER', 'ADMIN'] as const;
export type UserRole = (typeof USER_ROLES)[number];

export const USER_STATUSES = ['ACTIVE', 'SUSPENDED', 'BANNED'] as const;
export type UserStatus = (typeof USER_STATUSES)[number];

export const MESSAGE_ROLES = ['USER', 'ASSISTANT', 'SYSTEM'] as const;
export type MessageRole = (typeof MESSAGE_ROLES)[number];

export const CREDIT_TRANSACTION_TYPES = [
  'SIGNUP_BONUS',
  'CHAT_USAGE',
  'ADMIN_ADD',
  'ADMIN_REMOVE',
  'REFUND',
  'BONUS',
  'SYSTEM_ADJUSTMENT',
] as const;
export type CreditTransactionType = (typeof CREDIT_TRANSACTION_TYPES)[number];

export const AUDIT_ACTIONS = [
  'ADMIN_ADD_CREDIT',
  'ADMIN_REMOVE_CREDIT',
  'SUSPEND_USER',
  'ACTIVATE_USER',
  'BAN_USER',
  'CHANGE_ROLE',
  'UPDATE_SITE_SETTINGS',
  'UPLOAD_MEDIA',
  'DELETE_MEDIA',
  'MEDIA_REORDER',
  'ADMIN_LOGIN',
] as const;
export type AuditAction = (typeof AUDIT_ACTIONS)[number];

export const BACKGROUND_TYPES = ['STATIC_COLOR', 'IMAGE', 'GIF', 'VIDEO'] as const;
export type BackgroundType = (typeof BACKGROUND_TYPES)[number];

export const MEDIA_KINDS = ['IMAGE', 'GIF', 'VIDEO', 'AUDIO', 'ICON'] as const;
export type MediaKind = (typeof MEDIA_KINDS)[number];

export const DEFAULT_SITE_NAME = 'Orbit AI';
export const DEFAULT_SITE_TAGLINE = 'A calm place to think with a model.';
export const DEFAULT_CHAT_WELCOME =
  'Ask anything. I will keep it focused, and show my work.';
export const DEFAULT_LANDING_TITLE = 'A quieter way to work with an AI.';
export const DEFAULT_LANDING_DESCRIPTION =
  'Orbit is a focused chat workspace: real streaming answers, code you can copy, and a history that stays yours.';

export const STORAGE_PROVIDERS = ['local', 's3'] as const;
export type StorageProvider = (typeof STORAGE_PROVIDERS)[number];

/** Every API response envelope uses this shape. */
export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiFailure {
  success: false;
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export type ApiResponse<T> = ApiSuccess<T> | ApiFailure;
