import { z } from 'zod';
import { AUDIT_ACTIONS, CREDIT_TRANSACTION_TYPES } from '../constants.js';
import { idParamSchema, paginationSchema, safeText, userRoleSchema, userStatusSchema } from './common.js';

export const adminUserParamsSchema = idParamSchema;
export type AdminUserParams = z.infer<typeof adminUserParamsSchema>;

export const listAdminUsersSchema = paginationSchema.extend({
  search: z.string().trim().max(120).optional(),
  role: userRoleSchema.optional(),
  status: userStatusSchema.optional(),
  sort: z
    .enum(['createdAt', 'credits', 'lastLoginAt', 'email', 'username'])
    .default('createdAt'),
  order: z.enum(['asc', 'desc']).default('desc'),
});
export type ListAdminUsersInput = z.infer<typeof listAdminUsersSchema>;

export const adjustCreditsSchema = z.object({
  amount: z.coerce
    .number()
    .int('Credits must be a whole number.')
    .refine((v) => v !== 0, 'Amount cannot be zero.')
    .refine((v) => Math.abs(v) <= 1_000_000, 'Amount is too large.'),
  reason: safeText(1, 240),
});
export type AdjustCreditsInput = z.infer<typeof adjustCreditsSchema>;

export const setUserStatusSchema = z.object({
  status: userStatusSchema,
  reason: safeText(1, 240).optional(),
});
export type SetUserStatusInput = z.infer<typeof setUserStatusSchema>;

export const setUserRoleSchema = z.object({
  role: userRoleSchema,
  reason: safeText(1, 240).optional(),
});
export type SetUserRoleInput = z.infer<typeof setUserRoleSchema>;

export const listAuditLogsSchema = paginationSchema.extend({
  action: z.enum(AUDIT_ACTIONS).optional(),
  adminId: z.string().trim().max(64).optional(),
  targetUserId: z.string().trim().max(64).optional(),
});
export type ListAuditLogsInput = z.infer<typeof listAuditLogsSchema>;

export const listCreditTransactionsSchema = paginationSchema.extend({
  userId: z.string().trim().max(64).optional(),
  type: z.enum(CREDIT_TRANSACTION_TYPES).optional(),
});
export type ListCreditTransactionsInput = z.infer<typeof listCreditTransactionsSchema>;
