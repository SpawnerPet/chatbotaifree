import { z } from 'zod';

// Whitespace-only input is rejected without trimming the stored message.
const messageContent = z
  .string()
  .max(24000, 'Message is too long (24000 characters max).')
  .refine((v) => v.trim().length > 0, 'Message cannot be empty.');

/** Model ids are validated against the server allow-list, never trusted blindly. */
const modelId = z
  .string()
  .trim()
  .min(1)
  .max(120)
  .regex(/^[A-Za-z0-9._:\/-]+$/, 'Invalid model identifier.');

export const chatRequestSchema = z.object({
  conversationId: z.string().trim().min(1).max(64).optional(),
  message: messageContent,
  model: modelId.optional(),
});
export type ChatRequestInput = z.infer<typeof chatRequestSchema>;

export const regenerateSchema = z.object({
  conversationId: z.string().trim().min(1).max(64),
  /** The user message the assistant answer belongs to. */
  messageId: z.string().trim().min(1).max(64),
  model: modelId.optional(),
});
export type RegenerateInput = z.infer<typeof regenerateSchema>;

/**
 * Server-sent event names used by /api/chat/stream.
 * `meta` is sent first so the client can attach a stable id to the pending
 * assistant bubble before any content arrives.
 */
export const STREAM_EVENTS = {
  META: 'meta',
  DELTA: 'delta',
  DONE: 'done',
  ERROR: 'error',
  ABORTED: 'aborted',
} as const;

export type StreamEventName = (typeof STREAM_EVENTS)[keyof typeof STREAM_EVENTS];

export interface StreamMeta {
  event: 'meta';
  conversationId: string;
  userMessageId: string;
  assistantMessageId: string;
  model: string;
  creditsRemaining: number;
}

export interface StreamDelta {
  event: 'delta';
  text: string;
}

export interface StreamDone {
  event: 'done';
  conversationId: string;
  assistantMessageId: string;
  model: string;
  creditsRemaining: number;
  finishReason: string | null;
  durationMs: number;
}

export interface StreamError {
  event: 'error';
  code: string;
  message: string;
  refunded: boolean;
  creditsRemaining: number;
}

export interface StreamAborted {
  event: 'aborted';
  message: string;
  refunded: boolean;
  creditsRemaining: number;
}

export type StreamEvent =
  | StreamMeta
  | StreamDelta
  | StreamDone
  | StreamError
  | StreamAborted;
