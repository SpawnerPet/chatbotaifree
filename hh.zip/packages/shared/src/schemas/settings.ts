import { z } from 'zod';
import { BACKGROUND_TYPES } from '../constants.js';
import { hexColorSchema, safeText } from './common.js';

export const BUTTON_STYLES = ['solid', 'outline', 'ghost'] as const;
export type ButtonStyle = (typeof BUTTON_STYLES)[number];

export const DEFAULT_THEMES = ['dark', 'light', 'system'] as const;
export type DefaultTheme = (typeof DEFAULT_THEMES)[number];

export const FONT_CHOICES = [
  'inter',
  'system',
  'serif',
  'mono',
  'grotesk',
] as const;
export type FontChoice = (typeof FONT_CHOICES)[number];

export const backgroundTypeSchema = z.enum(BACKGROUND_TYPES);

/**
 * Custom CSS is a genuinely useful escape hatch but it is a stored-XSS vector,
 * so it is deliberately constrained: no `@import`, no external url(), no
 * `javascript:`, no `<`/`>` and a hard length cap. Everything else is admin-only.
 */
export const customCssSchema = z
  .string()
  .max(8000, 'Custom CSS is limited to 8000 characters.')
  .refine(
    (v) =>
      !/@import/i.test(v) &&
      !/url\s*\(\s*['"]?\s*(javascript:|data:text\/html)/i.test(v) &&
      !/[<>]/.test(v),
    'Custom CSS may not use @import, javascript: urls or HTML tags.',
  );

export const optionalUrl = z
  .string()
  .trim()
  .max(2048)
  .refine(
    (v) => v === '' || /^(https?:\/\/|\/)/.test(v),
    'Expected an http(s) URL or a root-relative path.',
  );

export const settingsSchema = z
  .object({
    siteName: safeText(1, 60),
    siteTagline: safeText(0, 160),
    logoUrl: optionalUrl,
    faviconUrl: optionalUrl,

    loginTitle: safeText(1, 120),
    loginSubtitle: safeText(0, 240),

    landingTitle: safeText(1, 160),
    landingDescription: safeText(0, 600),
    primaryCtaText: safeText(1, 60),
    secondaryCtaText: safeText(0, 60),
    footerText: safeText(0, 240),

    chatWelcomeMessage: safeText(0, 600),
    chatEmptyPrompts: z
      .array(safeText(1, 200))
      .max(6)
      .default([]),

    accentColor: hexColorSchema,
    backgroundColor: hexColorSchema,
    textColor: hexColorSchema,
    borderColor: hexColorSchema,
    buttonStyle: z.enum(BUTTON_STYLES),
    fontChoice: z.enum(FONT_CHOICES),
    defaultTheme: z.enum(DEFAULT_THEMES),

    backgroundType: backgroundTypeSchema,
    backgroundMediaId: z.string().trim().max(64).nullable().optional(),
    backgroundOverlayOpacity: z.coerce.number().min(0).max(0.95),
    backgroundParallax: z.boolean().default(false),

    musicEnabled: z.boolean(),
    musicUrl: optionalUrl,
    musicVolume: z.coerce.number().min(0).max(1),
    musicAutoplay: z.boolean(),

    supportEmail: z
      .string()
      .trim()
      .max(254)
      .refine((v) => v === '' || z.string().email().safeParse(v).success, 'Invalid email.')
      .default(''),

    customCss: customCssSchema.default(''),
  })
  .partial()
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update.');

export type UpdateSettingsInput = z.infer<typeof settingsSchema>;

/** Shape served to the browser. Identical fields, but typed for the web app. */
export interface PublicSettings {
  siteName: string;
  siteTagline: string;
  logoUrl: string;
  faviconUrl: string;

  loginTitle: string;
  loginSubtitle: string;

  landingTitle: string;
  landingDescription: string;
  primaryCtaText: string;
  secondaryCtaText: string;
  footerText: string;

  chatWelcomeMessage: string;
  chatEmptyPrompts: string[];

  accentColor: string;
  backgroundColor: string;
  textColor: string;
  borderColor: string;
  buttonStyle: ButtonStyle;
  fontChoice: FontChoice;
  defaultTheme: DefaultTheme;

  backgroundType: 'STATIC_COLOR' | 'IMAGE' | 'GIF' | 'VIDEO';
  backgroundMediaId: string | null;
  backgroundUrl: string | null;
  backgroundPosterUrl: string | null;
  backgroundOverlayOpacity: number;
  backgroundParallax: boolean;

  musicEnabled: boolean;
  musicUrl: string;
  musicVolume: number;
  musicAutoplay: boolean;

  supportEmail: string;
  customCss: string;

  updatedAt: string;
}

export interface PublicMedia {
  id: string;
  kind: 'IMAGE' | 'GIF' | 'VIDEO' | 'AUDIO' | 'ICON';
  mimeType: string;
  url: string;
  filename: string;
  size: number;
  width: number | null;
  height: number | null;
  altText: string;
  createdAt: string;
}

export interface ModelOption {
  id: string;
  label: string;
  isDefault: boolean;
}
