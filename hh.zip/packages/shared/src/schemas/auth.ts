import { z } from 'zod';
import { emailSchema, passwordSchema, safeText, usernameSchema } from './common.js';

export const registerSchema = z.object({
  email: emailSchema,
  username: usernameSchema,
  password: passwordSchema,
});
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: emailSchema,
  // Deliberately permissive: never leak password policy details on login.
  password: z.string().min(1, 'Password is required.').max(200),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({ email: emailSchema });
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;

export const resetPasswordSchema = z.object({
  token: z.string().trim().min(10).max(400),
  password: passwordSchema,
});
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(200),
  newPassword: passwordSchema,
});
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

export const updateProfileSchema = z
  .object({
    username: usernameSchema.optional(),
    avatarUrl: z
      .string()
      .trim()
      .max(2048)
      .refine(
        (v) => v === '' || /^(https?:\/\/|\/)/.test(v),
        'Avatar must be an http(s) URL or a root-relative path.',
      )
      .optional(),
  })
  .refine((v) => Object.keys(v).length > 0, 'Nothing to update.');
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;

export const listSessionsSchema = z.object({
  currentSessionId: z.string().max(64).optional(),
});
export type ListSessionsInput = z.infer<typeof listSessionsSchema>;

export const sessionContentSchema = z.object({
  reason: safeText(0, 200).optional(),
});
export type SessionContentInput = z.infer<typeof sessionContentSchema>;
