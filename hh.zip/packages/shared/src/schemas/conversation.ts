import { z } from 'zod';
import { paginationSchema, safeText } from './common.js';

export const createConversationSchema = z.object({
  title: safeText(1, 120).optional(),
});
export type CreateConversationInput = z.infer<typeof createConversationSchema>;

export const updateConversationSchema = z.object({
  title: safeText(1, 120),
});
export type UpdateConversationInput = z.infer<typeof updateConversationSchema>;

export const listConversationsSchema = paginationSchema.extend({
  search: z.string().trim().max(120).optional(),
});
export type ListConversationsInput = z.infer<typeof listConversationsSchema>;

export const listMessagesSchema = z.object({
  cursor: z.string().trim().max(200).optional(),
  limit: z.coerce.number().int().min(1).max(200).default(100),
});
export type ListMessagesInput = z.infer<typeof listMessagesSchema>;

export const editMessageSchema = z.object({
  content: z
    .string()
    .trim()
    .min(1, 'Message cannot be empty.')
    .max(24000, 'Message is too long.'),
});
export type EditMessageInput = z.infer<typeof editMessageSchema>;
