/**
 * Canonical error codes. The API never leaks internal errors, so the frontend
 * keys off these stable codes rather than message text.
 */
export const ERROR_CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  UNAUTHORIZED: 'UNAUTHORIZED',
  FORBIDDEN: 'FORBIDDEN',
  NOT_FOUND: 'NOT_FOUND',
  CONFLICT: 'CONFLICT',
  RATE_LIMITED: 'RATE_LIMITED',
  INSUFFICIENT_CREDITS: 'INSUFFICIENT_CREDITS',
  ACCOUNT_SUSPENDED: 'ACCOUNT_SUSPENDED',
  ACCOUNT_BANNED: 'ACCOUNT_BANNED',
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  EMAIL_TAKEN: 'EMAIL_TAKEN',
  USERNAME_TAKEN: 'USERNAME_TAKEN',
  WEAK_PASSWORD: 'WEAK_PASSWORD',
  INVALID_TOKEN: 'INVALID_TOKEN',
  CSRF_INVALID: 'CSRF_INVALID',
  UPLOAD_REJECTED: 'UPLOAD_REJECTED',
  PAYLOAD_TOO_LARGE: 'PAYLOAD_TOO_LARGE',
  UNSUPPORTED_MEDIA_TYPE: 'UNSUPPORTED_MEDIA_TYPE',
  AI_PROVIDER_ERROR: 'AI_PROVIDER_ERROR',
  AI_PROVIDER_TIMEOUT: 'AI_PROVIDER_TIMEOUT',
  AI_PROVIDER_RATE_LIMITED: 'AI_PROVIDER_RATE_LIMITED',
  AI_NOT_CONFIGURED: 'AI_NOT_CONFIGURED',
  ABORTED: 'ABORTED',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
} as const;

export type ErrorCode = (typeof ERROR_CODES)[keyof typeof ERROR_CODES];

const DEFAULT_STATUS: Record<string, number> = {
  VALIDATION_ERROR: 422,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  RATE_LIMITED: 429,
  INSUFFICIENT_CREDITS: 402,
  ACCOUNT_SUSPENDED: 403,
  ACCOUNT_BANNED: 403,
  INVALID_CREDENTIALS: 401,
  EMAIL_TAKEN: 409,
  USERNAME_TAKEN: 409,
  WEAK_PASSWORD: 422,
  INVALID_TOKEN: 400,
  CSRF_INVALID: 403,
  UPLOAD_REJECTED: 422,
  PAYLOAD_TOO_LARGE: 413,
  UNSUPPORTED_MEDIA_TYPE: 415,
  AI_PROVIDER_ERROR: 502,
  AI_PROVIDER_TIMEOUT: 504,
  AI_PROVIDER_RATE_LIMITED: 429,
  AI_NOT_CONFIGURED: 503,
  ABORTED: 499,
  INTERNAL_ERROR: 500,
};

const DEFAULT_MESSAGE: Record<string, string> = {
  VALIDATION_ERROR: 'The submitted data is invalid.',
  UNAUTHORIZED: 'You must be signed in to do that.',
  FORBIDDEN: 'You do not have access to this resource.',
  NOT_FOUND: 'The requested resource does not exist.',
  RATE_LIMITED: 'Too many requests. Please slow down.',
  INSUFFICIENT_CREDITS: 'Insufficient credits.',
  ACCOUNT_SUSPENDED: 'This account is suspended.',
  ACCOUNT_BANNED: 'This account is banned.',
  INVALID_CREDENTIALS: 'Incorrect email or password.',
  EMAIL_TAKEN: 'That email is already registered.',
  USERNAME_TAKEN: 'That username is already taken.',
  WEAK_PASSWORD: 'Password is too weak.',
  INVALID_TOKEN: 'This link is invalid or has expired.',
  CSRF_INVALID: 'Security token mismatch. Reload the page and try again.',
  UPLOAD_REJECTED: 'The uploaded file was rejected.',
  PAYLOAD_TOO_LARGE: 'The uploaded file is too large.',
  UNSUPPORTED_MEDIA_TYPE: 'That file type is not supported.',
  AI_PROVIDER_ERROR: 'The AI provider returned an error. You were not charged.',
  AI_PROVIDER_TIMEOUT: 'The AI provider timed out. You were not charged.',
  AI_PROVIDER_RATE_LIMITED: 'The AI provider is rate limiting us. Try again shortly.',
  AI_NOT_CONFIGURED: 'The AI provider is not configured yet.',
  ABORTED: 'The request was cancelled.',
  INTERNAL_ERROR: 'Something went wrong on our side.',
};

export function httpStatusForCode(code: string): number {
  return DEFAULT_STATUS[code] ?? 500;
}

export function defaultMessageForCode(code: string): string {
  return DEFAULT_MESSAGE[code] ?? DEFAULT_MESSAGE.INTERNAL_ERROR!;
}
