import type {
  AuditAction,
  CreditTransactionType,
  MessageRole,
  UserRole,
  UserStatus,
} from './constants.js';

/** Never includes passwordHash, session token or any internal column. */
export interface UserDTO {
  id: string;
  email: string;
  username: string;
  avatar: string;
  role: UserRole;
  status: UserStatus;
  credits: number;
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string | null;
}

export interface AuthUserDTO extends UserDTO {
  isAdmin: boolean;
}

export interface SessionDTO {
  id: string;
  userAgent: string;
  ip: string;
  createdAt: string;
  lastUsedAt: string;
  expiresAt: string;
  current: boolean;
}

export interface MessageDTO {
  id: string;
  conversationId: string;
  role: MessageRole;
  content: string;
  model: string | null;
  createdAt: string;
  updatedAt: string;
  /** Credit cost of the request that produced this message, 0 for user messages. */
  cost: number;
}

export interface ConversationDTO {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
  lastMessagePreview: string | null;
  model: string | null;
}

export interface ConversationDetailDTO extends ConversationDTO {
  messages: MessageDTO[];
}

export interface CreditTransactionDTO {
  id: string;
  userId: string;
  amount: number;
  type: CreditTransactionType;
  balanceBefore: number;
  balanceAfter: number;
  description: string;
  createdAt: string;
  createdBy: string | null;
}

export interface AuditLogDTO {
  id: string;
  adminId: string;
  adminUsername: string;
  action: AuditAction;
  targetUserId: string | null;
  targetUsername: string | null;
  metadata: unknown;
  createdAt: string;
}

export interface AdminStats {
  users: {
    total: number;
    active: number;
    suspended: number;
    banned: number;
    admins: number;
    newLast7Days: number;
    activeLast7Days: number;
  };
  credits: {
    outstanding: number;
    granted: number;
    consumed: number;
    refunded: number;
  };
  chat: {
    conversations: number;
    messages: number;
    assistantMessages: number;
  };
  requests: {
    total: number;
    succeeded: number;
    failed: number;
    aborted: number;
    refunded: number;
  };
  lastRequestAt: string | null;
}

export interface AdminUserDetailDTO {
  user: UserDTO;
  creditTransactions: CreditTransactionDTO[];
  conversationCount: number;
  messageCount: number;
  sessionCount: number;
  auditLogs: AuditLogDTO[];
  stats: {
    requests: number;
    succeeded: number;
    failed: number;
  };
}

export interface Paginated<T> {
  items: T[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
}

export interface ModelListDTO {
  models: import('./schemas/settings.js').ModelOption[];
  defaultModel: string;
}
