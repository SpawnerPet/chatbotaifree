// Serves the built SPA and proxies /api + /media to the running backend,
// so the browser test exercises the same origin layout as production.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';


const DIST = new URL('../apps/web/dist/', import.meta.url).pathname;
const API = { host: '127.0.0.1', port: Number(process.env.E2E_API_PORT ?? 4000) };
const PORT = Number(process.env.E2E_PORT ?? 4173);

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.mp3': 'audio/mpeg', '.mp4': 'video/mp4',
};

const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api') || req.url.startsWith('/media')) {
    const proxy = http.request({ ...API, path: req.url, method: req.method, headers: req.headers }, (pres) => {
      res.writeHead(pres.statusCode, pres.headers);
      pres.pipe(res);
    });
    proxy.on('error', () => { res.writeHead(502); res.end('proxy error'); });
    req.pipe(proxy);
    return;
  }
  let filePath = path.join(DIST, decodeURIComponent(req.url.split('?')[0]));
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) filePath = path.join(DIST, 'index.html');
  const ext = path.extname(filePath);
  const body = fs.readFileSync(filePath);
  res.writeHead(200, { 'Content-Type': MIME[ext] ?? 'application/octet-stream' });
  res.end(body);
});
server.listen(PORT, '127.0.0.1', () => console.log('spa server on', PORT));
