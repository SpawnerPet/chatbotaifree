import { chromium } from 'playwright';
import fs from 'node:fs';

const BASE = process.env.E2E_BASE_URL ?? 'http://127.0.0.1:4173';
const ADMIN_EMAIL = process.env.ORBIT_ADMIN_EMAIL ?? 'admin@orbit.local';
const ADMIN_PASSWORD = process.env.ORBIT_ADMIN_PASSWORD ?? 'OrbitAdmin!2026';
const OUT = process.env.E2E_SHOT_DIR ?? new URL('./screenshots/', import.meta.url).pathname;
fs.mkdirSync(OUT, { recursive: true });

const browser = await chromium.launch({ executablePath: '/root/.cache/ms-playwright/chromium-1243/chrome-linux/chrome', args: ['--no-sandbox', '--disable-dev-shm-usage'] });
const results = [];
const errors = [];

/**
 * Signs in and returns the resulting storage state, so the other viewports can
 * reuse one session. Sign-in is rate limited (10 / 15 min) and that limit is
 * deliberate, so the suite must not burn a login per viewport.
 */
async function signIn(page) {
  await page.goto(`${BASE}/login`, { waitUntil: 'networkidle' });
  await page.fill('#email', ADMIN_EMAIL);
  await page.fill('#password', ADMIN_PASSWORD);
  await page.click('button[type=submit]');
  await page.waitForURL('**/chat', { timeout: 20000 });
  await page.waitForSelector('#orbit-composer', { timeout: 20000 });
  await page.waitForTimeout(800);
  return page.context().storageState();
}

async function readCredits(page) {
  const text = await page.locator('text=/credits?/').first().innerText();
  return Number(/(\d+)/.exec(text ?? '')?.[1] ?? NaN);
}

/**
 * Sends a prompt and waits for the turn to settle.
 *
 * The free OpenRouter router occasionally returns an empty completion. That is
 * a provider behaviour, not an app bug, so the result is reported as either
 * `answered` or `errored` and the caller asserts the app reacted correctly
 * in both cases (answer persisted, or error shown and the credit refunded).
 */
async function sendAndWait(page, text, opts = {}) {
  const wantCode = opts.wantCode ?? false;
  const attempts = opts.attempts ?? 3;

  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const before = await readCredits(page);
    await page.fill('#orbit-composer', text);
    await page.click('button[aria-label="Send message"]');
    await page.waitForFunction(
      () => !document.querySelector('button[aria-label="Stop generating"]'),
      { timeout: 120000 },
    );
    await page.waitForTimeout(2000);

    if (wantCode) {
      await page.locator('.code-block').first().waitFor({ timeout: 15000 }).catch(() => {});
      if ((await page.locator('.code-block').count()) > 0) return 'answered';
      continue;
    }

    const answered = await page
      .locator('article[aria-label="Assistant message"]')
      .last()
      .waitFor({ timeout: 15000 })
      .then(() => true)
      .catch(() => false);
    if (answered) return 'answered';

    // No answer: the app must show an error and refund the credit.
    const errorShown = await page
      .locator('text=/could not|went wrong|empty answer|timed out|try again/i')
      .first()
      .isVisible()
      .catch(() => false);
    const after = await readCredits(page);
    if (!errorShown || after !== before) {
      return `unexpected (errorShown=${errorShown} ${before}->${after})`;
    }
    console.log('  (provider returned an empty answer; app errored and refunded)');
  }
  return 'errored';
}

function check(name, ok, detail = '') {
  results.push({ name, ok, detail });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail ? ' :: ' + detail : ''}`);
}

// ── Desktop ───────────────────────────────────────────────
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
page.on('console', (m) => { if (m.type() === 'error') errors.push(`[console] ${m.text()}`); });
page.on('pageerror', (e) => errors.push(`[pageerror] ${e.message}`));

await page.goto(BASE, { waitUntil: 'networkidle' });
await page.waitForTimeout(600);
check('landing renders hero', (await page.locator('h1').first().textContent())?.length > 5,
  (await page.locator('h1').first().textContent())?.slice(0, 50));
await page.screenshot({ path: `${OUT}/01-landing-dark.png`, fullPage: true });

// no horizontal overflow
const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
check('no horizontal overflow (desktop landing)', overflow <= 0, `delta=${overflow}`);

// ── Sign in (the seeded administrator) ────────────────────
let authState;
try {
  authState = await signIn(page);
} catch (e) {
  console.log('login failed, alert =', await page.locator('[role=alert]').allInnerTexts());
  throw e;
}
check('login lands in chat', page.url().includes('/chat'), page.url());
check('composer visible', await page.locator('#orbit-composer').isVisible());
const creditsText = await page.locator('text=/credits?/').first().innerText();
const startCredits = Number(/(\d+)/.exec(creditsText ?? '')?.[1] ?? '-1');
check('credit balance shown', startCredits >= 0, creditsText ?? '');

// ── Send a message, real streaming ────────────────────────
const outcome = await sendAndWait(page, 'Write a 2-line haiku about databases.');
const providerUp = outcome === 'answered';
check('turn completed (answered or handled error)', providerUp || outcome === 'errored', outcome);
if (!providerUp) {
  console.log('  note: the OpenRouter free tier is rate limited, so live-model checks are skipped.');
}
const bubbles = await page.locator('article[aria-label]').count();
check('message bubbles rendered', bubbles >= 1, `count=${bubbles}`);

if (outcome === 'answered') {
  const assistantText = (await page.locator('article[aria-label="Assistant message"]').last().innerText()) ?? '';
  check('assistant produced text', assistantText.trim().length > 5, assistantText.trim().slice(0, 60));
  const creditsNow = await readCredits(page);
  check('credit was charged', creditsNow === startCredits - 1, `${startCredits} -> ${creditsNow}`);
} else {
  const creditsNow = await readCredits(page);
  check('failed turn refunded the credit', creditsNow === startCredits, `${startCredits} -> ${creditsNow}`);
  check('no assistant bubble was stored', (await page.locator('article[aria-label="Assistant message"]').count()) === 0);
}
await page.screenshot({ path: `${OUT}/03-chat-answer.png` });

// ── Conversation appears in the sidebar + search ──────────
await page.waitForTimeout(1500);
const sidebarTitles = await page.locator('nav[aria-label="Conversations"] button span.block').allTextContents();
check('conversation listed in sidebar', sidebarTitles.some((t) => t.includes('haiku')), sidebarTitles.join('|'));
await page.fill('#conversation-search', 'haiku');
await page.waitForTimeout(900);
const filtered = await page.locator('nav[aria-label="Conversations"] li').count();
check('sidebar search filters', filtered >= 1, `items=${filtered}`);
await page.fill('#conversation-search', '');
await page.waitForTimeout(600);

// ── Code block + copy ─────────────────────────────────────
// Deterministic: the markdown renderer is verified against a stored message,
// so this check does not depend on what the live model happens to return
// (the OpenRouter free tier is rate limited per day).
const conversationId = page.url().split('/chat/')[1];
check('conversation id available for the fixture', Boolean(conversationId), conversationId ?? '');

const fixture = [
  'Here you go:',
  '',
  '```python',
  'def reverse_text(s):',
  '    return s[::-1]',
  '```',
  '',
  '| a | b |',
  '| - | - |',
  '| 1 | 2 |',
].join('\n');

// Written through a temp .sql file so real newlines survive the shell.
const { writeFileSync, unlinkSync } = await import('node:fs');
const { execFileSync } = await import('node:child_process');
const sqlFile = '/tmp/orbit-e2e-fixture.sql';
const quoted = fixture.replace(/'/g, "''");
writeFileSync(
  sqlFile,
  `-- Render fixture: exercises the markdown renderer without the live model.\n` +
    `DELETE FROM messages WHERE id LIKE 'uifixture%';\n` +
    `INSERT INTO messages (id, "conversationId", role, content, model, cost, "createdAt", "updatedAt")\n` +
    `VALUES ('uifixture_' || substr(md5(random()::text), 1, 12), '${conversationId ?? ''}', 'ASSISTANT',\n` +
    `        '${quoted}', 'openrouter/free', 0, now(), now());\n`,
  'utf8',
);
try {
  execFileSync('psql', ['-h', '127.0.0.1', '-U', 'orbit', '-d', 'orbit', '-v', 'ON_ERROR_STOP=1', '-f', sqlFile], {
    env: { ...process.env, PGPASSWORD: 'orbit_dev_pw' },
    stdio: 'ignore',
  });
} finally {
  unlinkSync(sqlFile);
}

await page.reload({ waitUntil: 'networkidle' });
const firstBlock = page.locator('.code-block').first();
await firstBlock.waitFor({ timeout: 30000 });

check('code block rendered', (await page.locator('.code-block').count()) > 0);
const highlighted = await page.locator('.code-block pre code .hljs-keyword, .code-block pre code .hljs-title').count();
check('code is syntax highlighted', highlighted > 0, `tokens=${highlighted}`);
const lang = (await firstBlock.locator('div > span').first().innerText()) ?? '';
check('code block shows a language label', lang.trim().toLowerCase() === 'python', lang);
check('GFM table rendered', (await page.locator('.md table').count()) > 0);
await ctx.grantPermissions(['clipboard-read', 'clipboard-write']);
await firstBlock.locator('button').first().click();
await page.waitForTimeout(600);
const copied = await page.evaluate(() => navigator.clipboard.readText());
const blockText = (await firstBlock.locator('pre').first().innerText()).trim();
check('copy button copies the code', copied.trim() === blockText && copied.includes('def reverse_text'),
  `copied=${copied.slice(0, 32).replace(/\n/g, '\\n')}`);
await page.screenshot({ path: `${OUT}/04-chat-code.png` });

// ── Regenerate ────────────────────────────────────────────
const assistantMessages = page.locator('article[aria-label="Assistant message"]');
const regenButton = page.locator('button[aria-label="Regenerate this answer"]').last();
check('regenerate control is offered', (await regenButton.count()) > 0);
const beforeRegen =
  (await assistantMessages.count()) > 0 ? (await assistantMessages.last().innerText()) ?? '' : '';
const creditsBeforeRegen = await readCredits(page);
await regenButton.click();
await page.waitForFunction(() => !document.querySelector('button[aria-label="Stop generating"]'), { timeout: 120000 });
await page.waitForTimeout(2500);

if ((await assistantMessages.count()) > 0) {
  const regenText = (await assistantMessages.last().innerText()) ?? '';
  check('regenerate replaced the answer', regenText.trim().length > 0 && regenText !== beforeRegen,
    `changed=${regenText !== beforeRegen}`);
} else {
  // Provider unavailable: the old answer is dropped and the credit refunded.
  const creditsAfterRegen = await readCredits(page);
  check('regenerate failure refunded the credit', creditsAfterRegen === creditsBeforeRegen,
    `${creditsBeforeRegen} -> ${creditsAfterRegen}`);
  await sendAndWait(page, 'Say hello.', { attempts: 1 }).catch(() => undefined);
}

// ── Edit a user message ───────────────────────────────────
check('edit control is offered', (await page.locator('button[aria-label="Edit message"]').count()) > 0);
await page.locator('button[aria-label="Edit message"]').last().click();
await page.waitForTimeout(400);
const editBox = page.locator('textarea[aria-label="Edit message"]');
check('edit mode opens an editor', await editBox.isVisible());
await editBox.fill('Now give me the same thing in TypeScript.');
await page.locator('button:has-text("Save & resend")').click();
await page.waitForFunction(() => !document.querySelector('button[aria-label="Stop generating"]'), { timeout: 120000 });
await page.waitForTimeout(1000);
const lastUser = (await page.locator('article[aria-label="Your message"]').last().innerText()) ?? '';
check('edited message persisted', lastUser.includes('TypeScript'), lastUser.trim().slice(0, 50));
await page.screenshot({ path: `${OUT}/05-chat-edited.png` });

// ── Rename + delete ───────────────────────────────────────
page.once('dialog', (d) => d.accept('Renamed by UI test'));
await page.locator('button[aria-label="Rename conversation"]').click();
await page.waitForTimeout(1200);
const header = (await page.locator('header h1').textContent()) ?? '';
check('conversation renamed', header.includes('Renamed by UI test'), header);

// ── Light theme ───────────────────────────────────────────
await page.locator('button[aria-label*="theme"]').first().click();
await page.waitForTimeout(600);
const theme = await page.evaluate(() => document.documentElement.dataset.theme);
check('theme toggles to light', theme === 'light', theme ?? '');
await page.screenshot({ path: `${OUT}/06-chat-light.png` });
await page.locator('button[aria-label*="theme"]').first().click();
await page.waitForTimeout(400);

// ── Settings page ─────────────────────────────────────────
await page.goto(`${BASE}/settings`, { waitUntil: 'networkidle' });
await page.waitForTimeout(900);
check('settings page renders', (await page.locator('h1').textContent())?.includes('Settings'));
check('credit history shown', await page.locator('text=Credit history').isVisible());
await page.screenshot({ path: `${OUT}/07-settings.png`, fullPage: true });

// ── Admin dashboard ───────────────────────────────────────
await page.goto(`${BASE}/admin`, { waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
check('admin dashboard renders', (await page.locator('h1').textContent())?.includes('Dashboard'));
const statCards = await page.locator('text=Total users').count();
check('stats show real figures', statCards > 0);
await page.screenshot({ path: `${OUT}/11-admin-dashboard.png`, fullPage: true });

await page.goto(`${BASE}/admin/users`, { waitUntil: 'networkidle' });
await page.waitForSelector('table', { timeout: 20000 });
const rows = await page.locator('table tbody tr').count();
check('user table lists accounts', rows > 0, `rows=${rows}`);
await page.fill('#admin-user-search', 'admin@');
await page.waitForTimeout(1200);
const filteredRows = await page.locator('table tbody tr').count();
check('user search filters', filteredRows >= 1 && filteredRows <= rows, `${rows} -> ${filteredRows}`);
await page.screenshot({ path: `${OUT}/12-admin-users.png`, fullPage: true });

// Give a user credits through the real modal.
await page.fill('#admin-user-search', 'ui');
await page.waitForTimeout(1200);
const firstUser = page.locator('table tbody tr').first();
const userName = (await firstUser.locator('td').first().innerText()).split('\n')[0];
await firstUser.locator('button[aria-label^="Adjust credits"]').click();
await page.waitForSelector('#credit-amount', { timeout: 10000 });
await page.fill('#credit-amount', '25');
await page.fill('#credit-reason', 'UI test grant');
await page.locator('button:has-text("Apply")').click();
await page.waitForTimeout(2500);
const toast = (await page.locator('[role=status], [role=alert]').allInnerTexts()).join(' ');
check('admin credit grant applied', /Balance is now/.test(toast), toast.slice(0, 90));
await page.screenshot({ path: `${OUT}/13-admin-credits.png` });
void userName;

// Audit log
await page.goto(`${BASE}/admin/audit`, { waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
const auditEntries = await page.locator('main ul li').count();
check('audit log has entries', auditEntries > 0, `entries=${auditEntries}`);
check('audit records the credit action', (await page.locator('text=ADMIN_ADD_CREDIT').count()) > 0);
await page.screenshot({ path: `${OUT}/14-admin-audit.png`, fullPage: true });

// Media upload with a real PNG
await page.goto(`${BASE}/admin/media`, { waitUntil: 'networkidle' });
await page.waitForSelector('input[type=file]', { state: 'attached', timeout: 20000 });
const pngBytes = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64',
);
await page.setInputFiles('input[type=file]', {
  name: 'ui-upload.png',
  mimeType: 'image/png',
  buffer: pngBytes,
});
await page.waitForTimeout(3000);
const mediaCount = await page.locator('main li').count();
check('media library shows the upload', mediaCount > 0, `items=${mediaCount}`);
check('upload succeeded (toast)', (await page.locator('text=/Uploaded|Copy URL/').count()) > 0);
await page.screenshot({ path: `${OUT}/15-admin-media.png`, fullPage: true });

// Customization
await page.goto(`${BASE}/admin/customization`, { waitUntil: 'networkidle' });
await page.waitForSelector('#siteName', { timeout: 20000 });
const originalName = await page.inputValue('#siteName');
await page.fill('#siteName', 'Orbit QA');
await page.locator('button:has-text("Save changes")').first().click();
await page.waitForTimeout(2500);
check('site renamed from admin', (await page.locator('header').first().innerText()).includes('Orbit QA'),
  (await page.locator('header').first().innerText()).slice(0, 40));

// The change is live on the public site.
const anon = await browser.newContext();
const apage = await anon.newPage();
await apage.goto(BASE, { waitUntil: 'networkidle' });
await apage.waitForTimeout(800);
const liveBrand = await apage.locator('header').first().innerText();
check('branding change applies site-wide', liveBrand.includes('Orbit QA'), liveBrand.split('\n')[0]);
await apage.screenshot({ path: `${OUT}/16-customized-landing.png` });
await apage.close();

// Reject a dangerous custom CSS value.
await page.fill('textarea.font-mono', '@import url("https://evil.test/x.css");');
await page.locator('button:has-text("Save changes")').first().click();
await page.waitForTimeout(2000);
const cssToast = (await page.locator('[role=alert]').allInnerTexts()).join(' ');
check('dangerous custom CSS is rejected', /invalid|@import|characters/i.test(cssToast), cssToast.slice(0, 90));

// Restore the original name.
await page.fill('#siteName', originalName);
await page.locator('button:has-text("Save changes")').first().click();
await page.waitForTimeout(2000);

// ── Mobile ────────────────────────────────────────────────
const mctx = await browser.newContext({
  viewport: { width: 390, height: 844 },
  isMobile: true,
  hasTouch: true,
  deviceScaleFactor: 3,
  storageState: authState,
});
const mpage = await mctx.newPage();
mpage.on('pageerror', (e) => errors.push(`[mobile pageerror] ${e.message}`));
await mpage.goto(`${BASE}/chat`, { waitUntil: 'networkidle' });
await mpage.waitForTimeout(1500);
const mOverflow = await mpage.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
check('no horizontal overflow (mobile chat)', mOverflow <= 1, `delta=${mOverflow}`);
check('mobile composer usable', await mpage.locator('#orbit-composer').isVisible());
check('desktop sidebar hidden on mobile', !(await mpage.locator('aside[aria-label="Conversation list"]').isVisible()));
await mpage.screenshot({ path: `${OUT}/08-mobile-chat.png` });

await mpage.locator('button[aria-label="Open conversations"]').click();
await mpage.waitForTimeout(700);
check('mobile drawer opens', await mpage.locator('[role=dialog][aria-label="Conversations"]').isVisible());
await mpage.screenshot({ path: `${OUT}/09-mobile-drawer.png` });
await mpage.locator('button[aria-label="Close sidebar"]').click();
await mpage.waitForTimeout(400);

// ── Tablet ────────────────────────────────────────────────
const tctx = await browser.newContext({ viewport: { width: 820, height: 1180 }, storageState: authState });
const tpage = await tctx.newPage();
await tpage.goto(`${BASE}/`, { waitUntil: 'networkidle' });
await tpage.waitForTimeout(600);
const tOverflow = await tpage.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
check('no horizontal overflow (tablet landing)', tOverflow <= 0, `delta=${tOverflow}`);
await tpage.screenshot({ path: `${OUT}/10-tablet-landing.png` });

await browser.close();

console.log('\n--- console/page errors ---');
console.log(errors.length === 0 ? '(none)' : errors.slice(0, 20).join('\n'));
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} UI checks passed`);
if (failed.length) process.exitCode = 1;
