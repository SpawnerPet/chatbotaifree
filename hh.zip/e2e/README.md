# End-to-end browser checks

Real browser checks (Playwright + Chromium) against a running stack. They are
deliberately **not** part of `npm test`, which needs no browser, no server and
no AI provider.

```bash
# terminal A — database, migrations, seed, production build
npm run setup
npm run build

# terminal B — API
npm run dev:api                  # http://localhost:4000

# terminal C — the built frontend, proxying /api to the API
npm run serve:dist               # http://127.0.0.1:4173

# terminal D
npx playwright install chromium  # once
npm run test:e2e
```

Screenshots land in `e2e/screenshots/`. The script also needs `psql` and
credentials for the development database, because it seeds one assistant
message directly to verify the markdown renderer deterministically.

## What it covers (43 checks)

Landing page, sign-in, sending a real message, sidebar listing and search,
credit accounting, markdown + syntax highlighting + language label + copy,
GFM tables, regenerate, edit-and-resend, conversation rename, theme switch,
settings, the admin dashboard, user search, granting credits through the real
modal, the audit log, media upload, live re-branding from the customization
page, rejection of dangerous custom CSS, and mobile / tablet layouts with no
horizontal overflow.

## Design notes

**One login per run.** Sign-in is rate limited to 10 attempts per 15 minutes
and that limit is deliberate, so the suite signs in once and reuses the
storage state for the other viewports.

**Provider independence.** The OpenRouter free tier allows a limited number of
requests per day, and can also return an empty completion. When that happens
the suite asserts the *correct* behaviour rather than skipping silently: the
app must show an error, refund the credit in full, and store no assistant
message. Markdown rendering is verified against a stored message, so those
checks never depend on the model.

**The rate limit is not bypassed.** If a burst of runs exhausts the sign-in
window, restart the API to clear the in-memory store.
