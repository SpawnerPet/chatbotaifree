import type { ServerResponse } from 'node:http';
import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { mockOpenRouter } from './mock-openrouter.js';
import { Session, createUser, loginAs, parseSse, startServer } from './helpers.js';

const okStream = (chunks: string[]) => (call: unknown, res: ServerResponse) => {
  void call;
  mockOpenRouter.sse(res, chunks);
};

const failing = (status: number, message = 'upstream exploded') => (
  _call: unknown,
  res: ServerResponse,
) => {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: { message } }));
};

async function balance(userId: string): Promise<number> {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  return user.credits;
}

describe('credit system', () => {
  it('charges exactly one credit for a successful streamed answer', async () => {
    mockOpenRouter.setHandler(okStream(['Hello', ' there']));

    const user = await createUser({ credits: 10 });
    const session = await loginAs(user);

    const res = await session.post('/api/chat/stream', { message: 'hi' });
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/text\/event-stream/);

    const events = parseSse(res.text);
    expect(events[0]?.event).toBe('meta');
    expect(events.some((e) => e.event === 'delta')).toBe(true);

    const done = events.find((e) => e.event === 'done');
    expect(done).toBeDefined();
    expect(done?.creditsRemaining).toBe(9);

    expect(await balance(user.id)).toBe(9);

    const usage = await prisma.creditTransaction.findFirst({
      where: { userId: user.id, type: 'CHAT_USAGE' },
      orderBy: { createdAt: 'desc' },
    });
    expect(usage?.amount).toBe(-1);
    expect(usage?.balanceBefore).toBe(10);
    expect(usage?.balanceAfter).toBe(9);

    // The answer is persisted, not just streamed.
    const stored = await prisma.message.findFirst({
      where: { conversationId: (done?.conversationId as string) ?? '', role: 'ASSISTANT' },
    });
    expect(stored?.content).toBe('Hello there');
  });

  it('refunds in full when the provider fails, and stores no assistant message', async () => {
    mockOpenRouter.setHandler(failing(500));

    const user = await createUser({ credits: 7 });
    const session = await loginAs(user);

    const res = await session.post('/api/chat/stream', { message: 'hi' });
    const events = parseSse(res.text);
    const error = events.find((e) => e.event === 'error');

    expect(error).toBeDefined();
    expect(error?.code).toBe('AI_PROVIDER_ERROR');
    expect(error?.refunded).toBe(true);
    expect(error?.creditsRemaining).toBe(7);
    expect(events.some((e) => e.event === 'done')).toBe(false);

    expect(await balance(user.id)).toBe(7);

    const ledger = await prisma.creditTransaction.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'asc' },
    });
    expect(ledger.map((t) => t.type)).toEqual(['BONUS', 'CHAT_USAGE', 'REFUND']);
    expect(ledger.find((t) => t.type === 'CHAT_USAGE')?.amount).toBe(-1);
    expect(ledger.find((t) => t.type === 'REFUND')?.amount).toBe(1);

    const assistantMessages = await prisma.message.count({ where: { role: 'ASSISTANT' } });
    expect(assistantMessages).toBe(0);

    const request = await prisma.aiRequest.findFirst();
    expect(request?.status).toBe('FAILED');
    expect(request?.refundedCredits).toBe(1);
  });

  it('refuses to call the provider when the balance is zero', async () => {
    mockOpenRouter.setHandler(okStream(['should never happen']));

    const user = await createUser({ credits: 0 });
    const session = await loginAs(user);

    const res = await session.post('/api/chat/stream', { message: 'hi' });
    expect(res.status).toBe(200);

    const events = parseSse(res.text);
    const error = events.find((e) => e.event === 'error');
    expect(error?.code).toBe('INSUFFICIENT_CREDITS');
    expect(error?.refunded).toBe(false);

    // The decisive assertion: the provider was never contacted.
    expect(mockOpenRouter.callCount()).toBe(0);
    expect(await balance(user.id)).toBe(0);
  });

  it('returns 402 for the non-streaming endpoint with no credits', async () => {
    const user = await createUser({ credits: 0 });
    const session = await loginAs(user);

    const res = await session.post('/api/chat', { message: 'hi' });
    expect(res.status).toBe(402);
    expect(res.body.error.code).toBe('INSUFFICIENT_CREDITS');
    expect(mockOpenRouter.callCount()).toBe(0);
  });

  it('never lets a balance go negative under concurrent requests', async () => {
    // Slow provider so the requests genuinely overlap in time.
    mockOpenRouter.setHandler((_call, res) => {
      setTimeout(() => mockOpenRouter.sse(res, ['ok']), 150);
    });

    const user = await createUser({ credits: 2 });
    const session = await loginAs(user);

    const attempts = await Promise.all(
      Array.from({ length: 8 }).map((_, index) =>
        session.post('/api/chat/stream', { message: `concurrent ${index}` }),
      ),
    );

    const finalBalance = await balance(user.id);
    expect(finalBalance).toBeGreaterThanOrEqual(0);
    // Two credits, two successful answers — no more.
    expect(finalBalance).toBe(0);

    const succeeded = attempts.filter((r) => parseSse(r.text).some((e) => e.event === 'done'));
    expect(succeeded).toHaveLength(2);

    const insufficent = attempts.filter((r) =>
      parseSse(r.text).some((e) => e.code === 'INSUFFICIENT_CREDITS'),
    );
    expect(insufficent).toHaveLength(6);

    // The provider was only called for the two that could be paid for.
    expect(mockOpenRouter.callCount()).toBe(2);

    const chatUsage = await prisma.creditTransaction.count({
      where: { userId: user.id, type: 'CHAT_USAGE' },
    });
    expect(chatUsage).toBe(2);
  });

  it('refunds when the user stops generation mid-stream', async () => {
    // The provider streams one chunk and then hangs, so only a real client
    // disconnect can end the request.
    mockOpenRouter.setHandler((_call, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(
        `data: ${JSON.stringify({ choices: [{ delta: { content: 'partial answer' } }] })}\n\n`,
      );
    });

    const user = await createUser({ credits: 5 });
    const session = await loginAs(user);
    const server = await startServer();
    const http = await import('node:http');

    await new Promise<void>((resolve) => {
      const req = http.request(
        `${server.url}/api/chat/stream`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': session.csrfHeader(),
            Cookie: session.cookieHeader(),
          },
        },
        (res) => {
          res.resume();
          res.once('data', () => {
            // First delta received — now pull the plug, like the Stop button.
            setTimeout(() => {
              req.destroy();
              resolve();
            }, 200);
          });
        },
      );
      req.on('error', () => {
        /* destroy() surfaces as an error; the assertion below is the real check */
        resolve();
      });
      req.end(JSON.stringify({ message: 'long one' }));
      setTimeout(() => {
        req.destroy();
        resolve();
      }, 3000);
    });

    // The server needs a moment to notice the closed socket and refund.
    await new Promise((resolve) => setTimeout(resolve, 800));
    await server.close();

    expect(await balance(user.id)).toBe(5);

    const refund = await prisma.creditTransaction.findFirst({
      where: { userId: user.id, type: 'REFUND' },
    });
    expect(refund?.amount).toBe(1);

    const request = await prisma.aiRequest.findFirst({ orderBy: { createdAt: 'desc' } });
    expect(request?.status).toBe('ABORTED');

    expect(await prisma.message.count({ where: { role: 'ASSISTANT' } })).toBe(0);
  });

  it('rejects a model that is not on the allow-list', async () => {
    mockOpenRouter.setHandler(okStream(['nope']));
    const user = await createUser();
    const session = await loginAs(user);

    const res = await session.post('/api/chat', {
      message: 'hi',
      model: 'anthropic/claude-3-opus',
    });
    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(mockOpenRouter.callCount()).toBe(0);
  });

  it('never forwards the API key to the browser', async () => {
    const user = await createUser();
    const session = new Session();
    await session.post('/api/auth/login', { email: user.email, password: user.password });

    const health = await session.get('/api/health/openrouter');
    expect(health.status).toBe(200);
    // Counts and the model only — never the key itself.
    expect(health.body.data).toEqual({
      configured: true,
      model: 'openrouter/free',
      status: 'ok',
      keysTotal: 1,
      keysAvailable: 1,
    });
    expect(JSON.stringify(health.body)).not.toContain(envApiKey());
  });
});

function envApiKey(): string {
  return process.env.OPENROUTER_API_KEY ?? '';
}
