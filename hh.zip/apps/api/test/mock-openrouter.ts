import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { type AddressInfo } from 'node:net';

export const MOCK_PORT = 4599;
export const MOCK_BASE_URL = `http://127.0.0.1:${MOCK_PORT}/v1`;

/**
 * A controllable stand-in for the OpenRouter HTTP API.
 *
 * This is a test double for a THIRD-PARTY service only — the application code
 * under test (credit ledger, streaming, retries, refunds) is the real thing.
 * The real provider is exercised separately against the live API.
 */

export interface MockCall {
  path: string;
  body: unknown;
  authorization: string | undefined;
}

export type MockHandler = (
  call: MockCall,
  res: ServerResponse,
) => void | Promise<void>;

interface MockState {
  handler: MockHandler | null;
  calls: MockCall[];
  server: Server | null;
  starting: Promise<void> | null;
}

/**
 * Vitest re-instantiates modules for every test file, so a module-level object
 * here would give the test file a different `handler` slot than the running
 * server. Pinning the state to globalThis guarantees one shared instance
 * regardless of the runner's isolation settings.
 */
const GLOBAL_KEY = '__orbitMockOpenRouterState';
const globalScope = globalThis as typeof globalThis & { [GLOBAL_KEY]?: MockState };

const state: MockState = (globalScope[GLOBAL_KEY] ??= {
  handler: null,
  calls: [],
  server: null,
  starting: null,
});

export const mockOpenRouter = {
  setHandler(handler: MockHandler): void {
    state.handler = handler;
  },
  reset(): void {
    state.handler = null;
    state.calls = [];
  },
  calls(): MockCall[] {
    return state.calls;
  },
  callCount(): number {
    return state.calls.length;
  },
  /** Sends `data:` SSE frames, then terminates the stream. */
  sse(res: ServerResponse, chunks: string[], opts: { failAfter?: number } = {}): void {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      Connection: 'keep-alive',
    });
    let sent = 0;
    for (const chunk of chunks) {
      if (opts.failAfter !== undefined && sent >= opts.failAfter) break;
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: chunk } }] })}\n\n`);
      sent += 1;
    }
    if (opts.failAfter !== undefined && sent >= opts.failAfter) {
      res.destroy();
      return;
    }
    res.write('data: [DONE]\n\n');
    res.end();
  },
};

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

async function handle(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const raw = await readBody(req);
  let body: unknown = null;
  try {
    body = raw.length > 0 ? JSON.parse(raw.toString('utf8')) : null;
  } catch {
    body = null;
  }

  const call: MockCall = {
    path: req.url ?? '',
    body,
    authorization: req.headers.authorization,
  };
  state.calls.push(call);

  if (!state.handler) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: { message: 'mock handler not configured' } }));
    return;
  }
  await state.handler(call, res);
}

export function startMockOpenRouter(): Promise<void> {
  if (state.starting) return state.starting;

  const server = createServer((req, res) => {
    void handle(req, res).catch(() => {
      if (!res.headersSent) res.writeHead(500);
      res.end();
    });
  });
  server.unref();
  state.server = server;

  state.starting = new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(MOCK_PORT, '127.0.0.1', () => {
      const address = server.address() as AddressInfo;
      if (address.port !== MOCK_PORT) {
        reject(
          new Error(
            `Mock OpenRouter expected port ${MOCK_PORT} but bound ${address.port}. Another process is using that port.`,
          ),
        );
        return;
      }
      resolve();
    });
  });

  return state.starting;
}

/** Kept for explicit teardown only; the suite leaves the shared server up. */
export function stopMockOpenRouter(): void {
  state.server?.close();
  state.server = null;
  state.starting = null;
}
