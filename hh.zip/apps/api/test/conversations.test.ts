import type { ServerResponse } from 'node:http';
import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { mockOpenRouter } from './mock-openrouter.js';
import { createUser, loginAs, parseSse } from './helpers.js';

const streamAnswer = (text: string) => (_c: unknown, res: ServerResponse) => {
  mockOpenRouter.sse(res, [text]);
};

describe('conversations and messages', () => {
  it('creates, lists, renames and deletes a conversation', async () => {
    const user = await createUser();
    const session = await loginAs(user);

    const created = await session.post('/api/conversations', { title: 'First thoughts' });
    expect(created.status).toBe(201);
    const id = created.body.data.id as string;

    const list = await session.get('/api/conversations');
    expect(list.body.data.items).toHaveLength(1);
    expect(list.body.data.items[0].title).toBe('First thoughts');

    const renamed = await session.patch(`/api/conversations/${id}`, { title: 'Better title' });
    expect(renamed.status).toBe(200);
    expect(renamed.body.data.title).toBe('Better title');

    const removed = await session.delete(`/api/conversations/${id}`);
    expect(removed.status).toBe(200);

    // Messages cascade with the conversation.
    expect(await prisma.message.count()).toBe(0);
    expect((await session.get('/api/conversations')).body.data.items).toHaveLength(0);
  });

  it('streams an answer and persists both messages in order', async () => {
    mockOpenRouter.setHandler(streamAnswer('Here is the plan.'));

    const user = await createUser();
    const session = await loginAs(user);

    const res = await session.post('/api/chat/stream', { message: 'Make me a plan' });
    const done = parseSse(res.text).find((e) => e.event === 'done');
    const conversationId = done?.conversationId as string;

    const detail = await session.get(`/api/conversations/${conversationId}`);
    expect(detail.status).toBe(200);
    // The title is derived from the first user message.
    expect(detail.body.data.title).toBe('Make me a plan');
    expect(detail.body.data.messages).toHaveLength(2);
    expect(detail.body.data.messages[0]).toMatchObject({ role: 'USER', content: 'Make me a plan' });
    expect(detail.body.data.messages[1]).toMatchObject({
      role: 'ASSISTANT',
      content: 'Here is the plan.',
    });
    expect(detail.body.data.messages[1].cost).toBe(1);
  });

  it('searches conversations by title and by message content', async () => {
    mockOpenRouter.setHandler(streamAnswer('Answer about kubernetes.'));

    const user = await createUser();
    const session = await loginAs(user);

    await session.post('/api/conversations', { title: 'Database design' });
    const second = await session.post('/api/chat/stream', { message: 'How do I deploy this?' });
    void second;

    const byTitle = await session.get('/api/conversations?search=deploy');
    expect(byTitle.body.data.total).toBe(1);
    expect(byTitle.body.data.items[0].title).toBe('How do I deploy this?');

    // The word only appears in the assistant's answer, not the title.
    const byContent = await session.get('/api/conversations?search=kubernetes');
    expect(byContent.body.data.total).toBe(1);

    const noMatch = await session.get('/api/conversations?search=zzzznothing');
    expect(noMatch.body.data.total).toBe(0);
  });

  it('paginates the sidebar list', async () => {
    const user = await createUser();
    const session = await loginAs(user);
    for (let i = 0; i < 5; i += 1) {
      await session.post('/api/conversations', { title: `Chat ${i}` });
    }
    const page1 = await session.get('/api/conversations?page=1&pageSize=2');
    expect(page1.body.data.items).toHaveLength(2);
    expect(page1.body.data.total).toBe(5);
    expect(page1.body.data.totalPages).toBe(3);
  });

  it('regenerates an answer and charges for it', async () => {
    mockOpenRouter.setHandler(streamAnswer('First answer.'));
    const user = await createUser({ credits: 10 });
    const session = await loginAs(user);

    const first = await session.post('/api/chat/stream', { message: 'Question' });
    const done = parseSse(first.text).find((e) => e.event === 'done');
    const conversationId = done?.conversationId as string;
    const userMessageId = (parseSse(first.text).find((e) => e.event === 'meta') as { userMessageId: string })
      .userMessageId;

    mockOpenRouter.setHandler(streamAnswer('Second answer.'));
    const regenerated = await session.post('/api/chat/regenerate', {
      conversationId,
      messageId: userMessageId,
    });
    const regenDone = parseSse(regenerated.text).find((e) => e.event === 'done');
    expect(regenDone).toBeDefined();

    const detail = await session.get(`/api/conversations/${conversationId}`);
    expect(detail.body.data.messages).toHaveLength(2);
    expect(detail.body.data.messages[1].content).toBe('Second answer.');

    const user2 = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
    expect(user2.credits).toBe(8); // two successful answers charged
  });

  it('refunds a failed regeneration and keeps the user message', async () => {
    mockOpenRouter.setHandler(streamAnswer('ok'));
    const user = await createUser({ credits: 10 });
    const session = await loginAs(user);
    const first = await session.post('/api/chat/stream', { message: 'Question' });
    const frames = parseSse(first.text);
    const conversationId = frames.find((e) => e.event === 'done')?.conversationId as string;
    const userMessageId = (frames.find((e) => e.event === 'meta') as { userMessageId: string })
      .userMessageId;

    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'bad gateway' } }));
    });

    const regenerated = await session.post('/api/chat/regenerate', {
      conversationId,
      messageId: userMessageId,
    });
    const error = parseSse(regenerated.text).find((e) => e.event === 'error');
    expect(error?.refunded).toBe(true);

    const after = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
    expect(after.credits).toBe(9);

    // The previous assistant answer was removed and nothing replaced it.
    const detail = await session.get(`/api/conversations/${conversationId}`);
    expect(detail.body.data.messages).toHaveLength(1);
    expect(detail.body.data.messages[0].role).toBe('USER');
  });

  it('edits a user message and truncates the replies after it', async () => {
    mockOpenRouter.setHandler(streamAnswer('Answer one.'));
    const user = await createUser();
    const session = await loginAs(user);
    const first = await session.post('/api/chat/stream', { message: 'Original question' });
    const frames = parseSse(first.text);
    const conversationId = frames.find((e) => e.event === 'done')?.conversationId as string;
    const userMessageId = (frames.find((e) => e.event === 'meta') as { userMessageId: string })
      .userMessageId;

    const edited = await session.patch(`/api/messages/${userMessageId}`, {
      content: 'Edited question',
    });
    expect(edited.status).toBe(200);
    expect(edited.body.data.content).toBe('Edited question');

    const detail = await session.get(`/api/conversations/${conversationId}`);
    expect(detail.body.data.messages).toHaveLength(1);
    expect(detail.body.data.messages[0].content).toBe('Edited question');
  });

  it('refuses to edit an assistant message through the user endpoint', async () => {
    mockOpenRouter.setHandler(streamAnswer('Answer.'));
    const user = await createUser();
    const session = await loginAs(user);
    const first = await session.post('/api/chat/stream', { message: 'Question' });
    const done = parseSse(first.text).find((e) => e.event === 'done');

    const assistant = await prisma.message.findFirstOrThrow({
      where: { conversationId: done?.conversationId as string, role: 'ASSISTANT' },
    });

    const res = await session.patch(`/api/messages/${assistant.id}`, { content: 'Hijacked' });
    expect(res.status).toBe(404);
  });

  it('validates input instead of storing it', async () => {
    const user = await createUser();
    const session = await loginAs(user);

    const emptyMessage = await session.post('/api/chat/stream', { message: '   ' });
    expect(emptyMessage.status).toBe(422);
    expect(emptyMessage.body.error.code).toBe('VALIDATION_ERROR');

    const emptyTitle = await session.post('/api/conversations', { title: '  ' });
    expect(emptyTitle.status).toBe(422);

    const badId = await session.get('/api/conversations/..%2F..%2Fetc%2Fpasswd');
    expect([400, 404, 422]).toContain(badId.status);
  });
});
