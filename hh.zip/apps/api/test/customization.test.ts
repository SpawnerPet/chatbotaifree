import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { rm } from 'node:fs/promises';
import { env } from '../src/config/env.js';
import supertest from 'supertest';
import { createUser, loginAs, getApp, type Session } from './helpers.js';

/** Smallest valid PNG: 1×1, 67 bytes. */
const PNG_1X1 = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
  'base64',
);

/**
 * A structurally valid MP3: an empty ID3v2.3 tag followed by real MPEG-1
 * Layer III frame headers (sync 0xFFFB, 128 kbps, 44.1 kHz, 417-byte frames).
 * Magic-byte sniffing requires genuine frames, not a "MP3" string.
 */
const MP3_FRAME = Buffer.concat([
  Buffer.from([0xff, 0xfb, 0x90, 0x40]),
  Buffer.alloc(413, 0x55),
]);
const MP3_BYTES = Buffer.concat([
  Buffer.from('ID3', 'ascii'),
  Buffer.from([0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]),
  ...Array.from({ length: 20 }, () => MP3_FRAME),
]);

/** An HTML document renamed to .png — the classic disguised-upload attack. */
const DISGUISED_HTML = Buffer.from(
  '<!doctype html><html><body><script>alert(document.cookie)</script></body></html>',
  'utf8',
);

async function adminSession(): Promise<Session> {
  const admin = await createUser({ role: 'ADMIN', username: 'root' });
  return loginAs(admin);
}

describe('site customization and media', () => {
  it('serves default public settings to anonymous visitors', async () => {
    const res = await supertest(getApp()).get('/api/settings');
    expect(res.status).toBe(200);
    expect(res.body.data.siteName).toBe('Orbit AI');
    expect(res.body.data.backgroundType).toBe('STATIC_COLOR');
    expect(Array.isArray(res.body.data.chatEmptyPrompts)).toBe(true);
  });

  it('renames the site and persists the change in the database', async () => {
    const session = await adminSession();

    const res = await session.patch('/api/admin/settings', {
      siteName: 'Nebula',
      landingTitle: 'Think out loud.',
      accentColor: '#3355ff',
      defaultTheme: 'light',
      chatWelcomeMessage: 'Ask me anything.',
      chatEmptyPrompts: ['First prompt', 'Second prompt'],
    });

    expect(res.status).toBe(200);
    expect(res.body.data.siteName).toBe('Nebula');
    expect(res.body.data.accentColor).toBe('#3355ff');
    expect(res.body.data.chatEmptyPrompts).toEqual(['First prompt', 'Second prompt']);

    // Read straight from the database — not from a cache.
    const row = await prisma.siteSettings.findUniqueOrThrow({ where: { id: 'default' } });
    expect(row.siteName).toBe('Nebula');
    expect(row.defaultTheme).toBe('light');

    // Public endpoint reflects it.
    const publicRes = await supertest(getApp()).get('/api/settings');
    expect(publicRes.body.data.siteName).toBe('Nebula');

    const audit = await prisma.auditLog.findFirstOrThrow({ where: { action: 'UPDATE_SITE_SETTINGS' } });
    expect(audit.metadata).toMatchObject({ changed: expect.arrayContaining(['siteName']) });
  });

  it('rejects dangerous custom CSS', async () => {
    const session = await adminSession();

    for (const css of [
      '@import url("https://evil.test/x.css");',
      'body { background: url(javascript:alert(1)); }',
      '<script>alert(1)</script>',
    ]) {
      const res = await session.patch('/api/admin/settings', { customCss: css });
      expect(res.status, css).toBe(422);
    }

    const safe = await session.patch('/api/admin/settings', {
      customCss: '.card { border-radius: 2px; }',
    });
    expect(safe.status).toBe(200);
  });

  it('rejects an invalid colour and an unknown key', async () => {
    const session = await adminSession();

    const badColor = await session.patch('/api/admin/settings', { accentColor: 'red' });
    expect(badColor.status).toBe(422);

    const unknown = await session.patch('/api/admin/settings', { notAField: 'x' });
    expect(unknown.status).toBe(422);
  });

  it('uploads a valid PNG, serves it, and records an audit entry', async () => {
    const session = await adminSession();

    const res = await session.postRaw('/api/admin/media?category=image&filename=logo.png', 'image/png', PNG_1X1);

    expect(res.status).toBe(201);
    expect(res.body.data.mimeType).toBe('image/png');
    expect(res.body.data.kind).toBe('IMAGE');
    expect(res.body.data.size).toBe(PNG_1X1.length);
    expect(res.body.data.url).toMatch(/^https?:\/\/.+\/media\/image\//);

    // Binary is on disk, not in the database.
    const media = await prisma.media.findUniqueOrThrow({ where: { id: res.body.data.id } });
    expect(media.storageKey).toMatch(/^image\/\d{4}\/\d{2}\/[0-9a-f]{32}\.png$/);
    expect(await prisma.message.count()).toBe(0);

    const audit = await prisma.auditLog.findFirstOrThrow({ where: { action: 'UPLOAD_MEDIA' } });
    expect(audit.metadata).toMatchObject({ mediaId: res.body.data.id, kind: 'IMAGE' });

    const list = await session.get('/api/admin/media');
    expect(list.body.data).toHaveLength(1);
  });

  it('accepts an MP3 for background music', async () => {
    const session = await adminSession();
    const res = await session.postRaw('/api/admin/media?category=audio&filename=calm.mp3', 'audio/mpeg', MP3_BYTES);

    expect(res.status).toBe(201);
    expect(res.body.data.kind).toBe('AUDIO');
  });

  it('rejects HTML disguised as a PNG', async () => {
    const session = await adminSession();
    const res = await session.postRaw('/api/admin/media?category=image&filename=evil.png', 'image/png', DISGUISED_HTML);

    expect(res.status).toBe(422);
    expect(res.body.error.code).toBe('UPLOAD_REJECTED');
    expect(await prisma.media.count()).toBe(0);
  });

  it('rejects a file whose declared type does not match its contents', async () => {
    const session = await adminSession();
    const res = await session.postRaw('/api/admin/media?category=image&filename=photo.jpg', 'image/png', PNG_1X1);

    expect(res.status).toBe(422);
    expect(await prisma.media.count()).toBe(0);
  });

  it('rejects an unsupported category and an empty body', async () => {
    const session = await adminSession();

    const badCategory = await session.postRaw('/api/admin/media?category=executable', 'image/png', PNG_1X1);
    expect(badCategory.status).toBe(422);

    const empty = await session.postRaw(
      '/api/admin/media?category=image',
      'image/png',
      Buffer.alloc(0),
    );
    expect(empty.status).toBe(422);
  });

  it('applies an uploaded image as the page background', async () => {
    const session = await adminSession();
    const uploaded = await session.postRaw('/api/admin/media?category=image&filename=bg.png', 'image/png', PNG_1X1);
    const mediaId = uploaded.body.data.id as string;

    const res = await session.patch('/api/admin/settings', { backgroundMediaId: mediaId });
    expect(res.status).toBe(200);
    // The server picks the matching background type automatically.
    expect(res.body.data.backgroundType).toBe('IMAGE');
    expect(res.body.data.backgroundUrl).toContain('/media/image/');
  });

  it('refuses audio as a page background', async () => {
    const session = await adminSession();
    const audio = await session.postRaw('/api/admin/media?category=audio&filename=track.mp3', 'audio/mpeg', MP3_BYTES);

    const res = await session.patch('/api/admin/settings', {
      backgroundMediaId: audio.body.data.id,
    });
    expect(res.status).toBe(422);
  });

  it('deletes media and falls back to a flat background', async () => {
    const session = await adminSession();
    const uploaded = await session.postRaw('/api/admin/media?category=image&filename=bg.png', 'image/png', PNG_1X1);
    const mediaId = uploaded.body.data.id as string;
    const storageKey = (await prisma.media.findUniqueOrThrow({ where: { id: mediaId } })).storageKey;

    await session.patch('/api/admin/settings', { backgroundMediaId: mediaId });
    expect((await prisma.siteSettings.findUniqueOrThrow({ where: { id: 'default' } })).backgroundMediaId)
      .toBe(mediaId);

    const deleted = await session.delete(`/api/admin/media/${mediaId}`);
    expect(deleted.status).toBe(200);
    expect(await prisma.media.count()).toBe(0);

    // The settings row survives with a null reference, not a broken one.
    const settings = await prisma.siteSettings.findUniqueOrThrow({ where: { id: 'default' } });
    expect(settings.backgroundMediaId).toBeNull();

    // The object is gone from storage too.
    const { storageService } = await import('../src/services/storage.service.js');
    expect(await storageService.exists(storageKey)).toBe(false);

    const audit = await prisma.auditLog.findFirstOrThrow({ where: { action: 'DELETE_MEDIA' } });
    expect(audit.metadata).toMatchObject({ mediaId });
  });

  it('404s when deleting media that does not exist', async () => {
    const session = await adminSession();
    expect((await session.delete('/api/admin/media/nope')).status).toBe(404);
  });

  it('cleans up the local upload directory after the suite', async () => {
    await rm(env.storageLocalPath, { recursive: true, force: true });
  });
});
