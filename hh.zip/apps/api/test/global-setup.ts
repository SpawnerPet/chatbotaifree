import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const apiRoot = path.resolve(here, '..');

/**
 * Prepares the test database and applies the Prisma schema to it.
 * Runs once, before any test file is loaded.
 */
export default function globalSetup(): void {
  const databaseUrl =
    process.env.TEST_DATABASE_URL ??
    'postgresql://orbit:orbit_dev_pw@127.0.0.1:5432/orbit_test?schema=public';

  const env = { ...process.env, DATABASE_URL: databaseUrl };

  execFileSync('npx', ['prisma', 'db', 'push', '--force-reset', '--skip-generate'], {
    cwd: apiRoot,
    env,
    stdio: 'inherit',
  });
}
