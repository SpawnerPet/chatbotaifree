import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { type Session, createUser, loginAs } from './helpers.js';
import supertest from 'supertest';
import { getApp } from './helpers.js';

async function adminSession(): Promise<{ admin: Awaited<ReturnType<typeof createUser>>; session: Session }> {
  const admin = await createUser({ role: 'ADMIN', username: 'root', credits: 0 });
  const session = await loginAs(admin);
  return { admin, session };
}

describe('admin panel', () => {
  it('reports real platform statistics', async () => {
    await createUser();
    await createUser({ status: 'SUSPENDED' });
    const { session } = await adminSession();

    const res = await session.get('/api/admin/stats');
    expect(res.status).toBe(200);

    const stats = res.body.data;
    expect(stats.users.total).toBe(3); // two users + the admin
    expect(stats.users.suspended).toBe(1);
    expect(stats.users.active).toBe(2);
    expect(stats.users.admins).toBe(1);
    expect(stats.credits.outstanding).toBe(200); // 100 + 100 + 0
    expect(stats.requests.total).toBe(0);
  });

  it('searches, filters and paginates users', async () => {
    await createUser({ email: 'alice@example.com', username: 'alice' });
    await createUser({ email: 'bob@example.com', username: 'bob' });
    await createUser({ email: 'carol@example.com', username: 'carol', status: 'BANNED' });
    const { session } = await adminSession();

    const byName = await session.get('/api/admin/users?search=ali');
    expect(byName.body.data.items).toHaveLength(1);
    expect(byName.body.data.items[0].username).toBe('alice');

    const banned = await session.get('/api/admin/users?status=BANNED');
    expect(banned.body.data.items).toHaveLength(1);

    const page1 = await session.get('/api/admin/users?page=1&pageSize=2');
    expect(page1.body.data.items).toHaveLength(2);
    expect(page1.body.data.total).toBe(4);
    expect(page1.body.data.totalPages).toBe(2);

    const page2 = await session.get('/api/admin/users?page=2&pageSize=2');
    const ids = new Set([
      ...page1.body.data.items.map((u: { id: string }) => u.id),
      ...page2.body.data.items.map((u: { id: string }) => u.id),
    ]);
    expect(ids.size).toBe(4);
  });

  it('adds credits with a ledger row and an audit entry', async () => {
    const target = await createUser({ credits: 10 });
    const { admin, session } = await adminSession();

    const res = await session.post(`/api/admin/users/${target.id}/credits`, {
      amount: 25,
      reason: 'Promotional top-up',
    });

    expect(res.status).toBe(200);
    expect(res.body.data.balanceBefore).toBe(10);
    expect(res.body.data.balanceAfter).toBe(35);
    expect(res.body.data.user.credits).toBe(35);

    const tx = await prisma.creditTransaction.findFirstOrThrow({
      where: { userId: target.id, type: 'ADMIN_ADD' },
    });
    expect(tx.amount).toBe(25);
    expect(tx.balanceBefore).toBe(10);
    expect(tx.balanceAfter).toBe(35);
    expect(tx.createdById).toBe(admin.id);
    expect(tx.description).toBe('Promotional top-up');

    const audit = await prisma.auditLog.findFirstOrThrow({
      where: { action: 'ADMIN_ADD_CREDIT', targetUserId: target.id },
    });
    expect(audit.adminId).toBe(admin.id);
    expect(audit.metadata).toMatchObject({ amount: 25, balanceAfter: 35 });
  });

  it('removes credits and refuses to go negative', async () => {
    const target = await createUser({ credits: 10 });
    const { session } = await adminSession();

    const ok = await session.post(`/api/admin/users/${target.id}/credits`, {
      amount: -4,
      reason: 'Correction',
    });
    expect(ok.status).toBe(200);
    expect(ok.body.data.user.credits).toBe(6);

    const tooMuch = await session.post(`/api/admin/users/${target.id}/credits`, {
      amount: -100,
      reason: 'Too much',
    });
    expect(tooMuch.status).toBe(422);
    expect(tooMuch.body.error.code).toBe('VALIDATION_ERROR');

    const unchanged = await prisma.user.findUniqueOrThrow({ where: { id: target.id } });
    expect(unchanged.credits).toBe(6);

    await expect(
      prisma.creditTransaction.count({ where: { userId: target.id, type: 'ADMIN_REMOVE' } }),
    ).resolves.toBe(1);
  });

  it('rejects a zero credit adjustment', async () => {
    const target = await createUser();
    const { session } = await adminSession();
    const res = await session.post(`/api/admin/users/${target.id}/credits`, {
      amount: 0,
      reason: 'nothing',
    });
    expect(res.status).toBe(422);
  });

  it('suspends a user, revokes their sessions and reactivates them', async () => {
    const target = await createUser();
    const targetSession = await loginAs(target);
    expect((await targetSession.get('/api/auth/me')).status).toBe(200);

    const { session } = await adminSession();

    const suspended = await session.patch(`/api/admin/users/${target.id}/status`, {
      status: 'SUSPENDED',
      reason: 'Abuse',
    });
    expect(suspended.status).toBe(200);
    expect(suspended.body.data.status).toBe('SUSPENDED');

    // Access is cut immediately.
    expect((await targetSession.get('/api/auth/me')).status).toBe(401);
    const relogin = await supertest(getApp())
      .post('/api/auth/login')
      .send({ email: target.email, password: target.password });
    expect(relogin.status).toBe(403);

    const reactivated = await session.patch(`/api/admin/users/${target.id}/status`, {
      status: 'ACTIVE',
    });
    expect(reactivated.status).toBe(200);
    expect(
      (await supertest(getApp())
        .post('/api/auth/login')
        .send({ email: target.email, password: target.password })).status,
    ).toBe(200);

    const actions = await prisma.auditLog.findMany({
      where: { targetUserId: target.id },
      orderBy: { createdAt: 'asc' },
      select: { action: true },
    });
    expect(actions.map((a) => a.action)).toEqual(['SUSPEND_USER', 'ACTIVATE_USER']);
  });

  it('bans a user permanently', async () => {
    const target = await createUser();
    const { session } = await adminSession();
    const res = await session.patch(`/api/admin/users/${target.id}/status`, { status: 'BANNED' });
    expect(res.status).toBe(200);
    const audit = await prisma.auditLog.findFirst({ where: { targetUserId: target.id } });
    expect(audit?.action).toBe('BAN_USER');
  });

  it('stops an admin from demoting or suspending themselves', async () => {
    const { admin, session } = await adminSession();

    const demote = await session.patch(`/api/admin/users/${admin.id}/role`, { role: 'USER' });
    expect(demote.status).toBe(422);

    const suspend = await session.patch(`/api/admin/users/${admin.id}/status`, {
      status: 'SUSPENDED',
    });
    expect(suspend.status).toBe(422);
  });

  it('keeps at least one administrator in place', async () => {
    const other = await createUser({ role: 'ADMIN' });
    const { admin, session } = await adminSession();

    const demoteOther = await session.patch(`/api/admin/users/${other.id}/role`, { role: 'USER' });
    expect(demoteOther.status).toBe(200);

    const demoteLast = await session.patch(`/api/admin/users/${admin.id}/role`, { role: 'USER' });
    expect(demoteLast.status).toBe(422);
    expect((await prisma.user.findUniqueOrThrow({ where: { id: admin.id } })).role).toBe('ADMIN');
  });

  it('returns a user detail view with credit history and audit trail', async () => {
    const target = await createUser({ credits: 20 });
    const { session } = await adminSession();

    await session.post(`/api/admin/users/${target.id}/credits`, {
      amount: 5,
      reason: 'Bonus',
    });

    const res = await session.get(`/api/admin/users/${target.id}`);
    expect(res.status).toBe(200);
    expect(res.body.data.user.credits).toBe(25);
    expect(res.body.data.creditTransactions.length).toBeGreaterThanOrEqual(2);
    expect(res.body.data.auditLogs[0].action).toBe('ADMIN_ADD_CREDIT');
  });

  it('lists audit logs and filters by action', async () => {
    const target = await createUser();
    const { session } = await adminSession();

    await session.post(`/api/admin/users/${target.id}/credits`, { amount: 1, reason: 'x' });
    await session.patch(`/api/admin/users/${target.id}/status`, { status: 'SUSPENDED' });

    const all = await session.get('/api/admin/audit-logs');
    expect(all.body.data.total).toBe(2);

    const filtered = await session.get('/api/admin/audit-logs?action=SUSPEND_USER');
    expect(filtered.body.data.total).toBe(1);
    expect(filtered.body.data.items[0].adminUsername).toBe('root');
  });

  it('404s for a user that does not exist', async () => {
    const { session } = await adminSession();
    const res = await session.get('/api/admin/users/does-not-exist');
    expect(res.status).toBe(404);
  });
});
