import { describe, expect, it } from 'vitest';
import { createKeyPool, maskKey } from '../src/services/openrouter-keys.service.js';
import { mockOpenRouter } from './mock-openrouter.js';

const K1 = 'sk-or-v1-aaaaaaaaaaaaaaaa1111';
const K2 = 'sk-or-v1-bbbbbbbbbbbbbbbb2222';
const K3 = 'sk-or-v1-cccccccccccccccc3333';

import type { ServerResponse } from 'node:http';

const okJson = (content: string) => (_c: unknown, res: ServerResponse) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(
    JSON.stringify({
      id: 'gen-1',
      model: 'test/model:free',
      choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }],
    }),
  );
};

describe('OpenRouter key pool', () => {
  it('masks keys so they can be told apart but never used', () => {
    expect(maskKey(K1, 0)).toBe('key #1 ····1111');
    expect(maskKey('short', 3)).toBe('key #4');
    expect(maskKey(K1, 0)).not.toContain('aaaaaaaa');
  });

  it('rotates through keys in order', () => {
    const pool = createKeyPool([K1, K2, K3]);
    expect(pool.size).toBe(3);
    expect(pool.acquire()).toBe(K1);
    expect(pool.acquire()).toBe(K2);
    expect(pool.acquire()).toBe(K3);
    expect(pool.acquire()).toBe(K1);
  });

  it('benches a key on 429 and serves the next request from another key', () => {
    const pool = createKeyPool([K1, K2]);
    expect(pool.acquire()).toBe(K1);
    pool.reportFailure(K1, 429, 'AI_PROVIDER_RATE_LIMITED');

    expect(pool.acquire()).toBe(K2);
    const status = pool.status();
    expect(status[0]?.state).toBe('cooldown');
    expect(status[0]?.cooldownRemainingSeconds).toBeGreaterThan(0);
    expect(status[1]?.state).toBe('active');
    expect(pool.availableCount()).toBe(1);
  });

  it('benches a key on 401, 402 and 403 as well', () => {
    for (const status of [401, 402, 403]) {
      const pool = createKeyPool([K1, K2]);
      pool.acquire();
      pool.reportFailure(K1, status, 'AI_PROVIDER_ERROR');
      expect(pool.acquire(), `status ${status}`).toBe(K2);
    }
  });

  it('does not bench a key for a transient server error', () => {
    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 503, 'AI_PROVIDER_ERROR');
    // 503 is the provider's problem, not the key's: the key stays in rotation.
    expect(pool.status()[0]?.state).toBe('active');
  });

  it('parks a key after repeated transient failures', () => {
    const pool = createKeyPool([K1, K2]);
    for (let i = 0; i < 3; i += 1) {
      pool.acquire();
      pool.reportFailure(K1, 500, 'AI_PROVIDER_ERROR');
    }
    expect(pool.status()[0]?.state).toBe('parked');
    expect(pool.acquire()).toBe(K2);
  });

  it('clears the failure streak on success', () => {
    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 500, 'AI_PROVIDER_ERROR');
    pool.reportFailure(K1, 500, 'AI_PROVIDER_ERROR');
    pool.reportSuccess(K1);
    expect(pool.status()[0]?.consecutiveFailures).toBe(0);
  });

  it('returns a key to rotation once the cooldown expires', () => {
    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 429, 'AI_PROVIDER_RATE_LIMITED');
    expect(pool.acquire()).toBe(K2);

    // Reach into the entry to simulate the clock moving past the bench.
    const entries = pool as unknown as { entries: Array<{ cooldownUntil: number }> };
    const first = entries.entries[0];
    if (first) first.cooldownUntil = Date.now() - 1000;

    expect(pool.acquire()).toBe(K1);
    expect(pool.status()[0]?.state).toBe('active');
  });

  it('returns null only when every key is benched', () => {
    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 429, 'X');
    pool.acquire();
    pool.reportFailure(K2, 429, 'X');
    expect(pool.acquire()).toBeNull();
    expect(pool.availableCount()).toBe(0);
  });

  it('never exposes a key through status()', () => {
    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 429, 'AI_PROVIDER_RATE_LIMITED');
    const serialised = JSON.stringify(pool.status());
    expect(serialised).not.toContain('aaaaaaaa');
    expect(serialised).not.toContain('bbbbbbbb');
    expect(serialised).not.toContain(K1);
  });
});

describe('automatic key rotation during a request', () => {
  it('switches keys transparently when the first one is rate limited', async () => {
    const { OpenRouterService } = await import('../src/services/openrouter.service.js');
    const { createKeyPool } = await import('../src/services/openrouter-keys.service.js');

    const seen: string[] = [];
    let call = 0;
    mockOpenRouter.setHandler((c, res) => {
      seen.push(c.authorization ?? '');
      call += 1;
      if (call === 1) {
        res.writeHead(429, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'free-models-per-day' } }));
        return;
      }
        okJson('answered after rotation')(c, res);
    });

    const pool = createKeyPool([K1, K2]);
    const service = new OpenRouterService(pool);

    const result = await service.complete({
      model: 'openrouter/free',
      messages: [{ role: 'user', content: 'hi' }],
    });

    expect(result.content).toBe('answered after rotation');
    // Two calls, two DIFFERENT keys — and the first call produced no output
    // for the user, so nothing was duplicated.
    expect(seen).toHaveLength(2);
    expect(seen[0]).toBe(`Bearer ${K1}`);
    expect(seen[1]).toBe(`Bearer ${K2}`);
    expect(pool.status()[0]?.state).toBe('cooldown');
    expect(pool.rotationCount).toBe(1);
  }, 20_000);

  it('fails fast with a clear message when every key is benched', async () => {
    const { OpenRouterService } = await import('../src/services/openrouter.service.js');
    const { createKeyPool } = await import('../src/services/openrouter-keys.service.js');

    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'quota' } }));
    });

    const pool = createKeyPool([K1]);
    const service = new OpenRouterService(pool);

    // First call benches the only key; the next one has nowhere to rotate to.
    await expect(
      service.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'a' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_RATE_LIMITED' });

    pool.acquire();
    pool.reportFailure(K1, 429, 'AI_PROVIDER_RATE_LIMITED');

    await expect(
      service.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'b' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_RATE_LIMITED' });
  }, 20_000);

  it('keeps a transient 5xx on the same key', async () => {
    const { OpenRouterService } = await import('../src/services/openrouter.service.js');
    const { createKeyPool } = await import('../src/services/openrouter-keys.service.js');

    const seen: string[] = [];
    let call = 0;
    mockOpenRouter.setHandler((c, res) => {
      seen.push(c.authorization ?? '');
      call += 1;
      if (call === 1) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'cold start' } }));
        return;
      }
      okJson('same key, second try')(c, res);
    });

    const pool = createKeyPool([K1, K2]);
    const service = new OpenRouterService(pool);
    const result = await service.complete({
      model: 'openrouter/free',
      messages: [{ role: 'user', content: 'hi' }],
    });

    expect(result.content).toBe('same key, second try');
    expect(seen[0]).toBe(seen[1]);
    // No rotation: a 503 is the provider's problem, not the key's.
    expect(pool.rotationCount).toBe(0);
  }, 20_000);

  it('reports pool health without exposing any key', async () => {
    const { OpenRouterService } = await import('../src/services/openrouter.service.js');
    const { createKeyPool } = await import('../src/services/openrouter-keys.service.js');

    const pool = createKeyPool([K1, K2]);
    pool.acquire();
    pool.reportFailure(K1, 429, 'AI_PROVIDER_RATE_LIMITED');

    const health = await new OpenRouterService(pool).health();
    expect(health.status).toBe('ok');
    expect(health.keysTotal).toBe(2);
    expect(health.keysAvailable).toBe(1);
    expect(JSON.stringify(health)).not.toContain('aaaaaaaa');
  });
});
