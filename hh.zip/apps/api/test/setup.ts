import { afterAll, beforeAll, beforeEach, expect } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { env } from '../src/config/env.js';
import { startMockOpenRouter, mockOpenRouter } from './mock-openrouter.js';
import { openRouterKeyPool } from '../src/services/openrouter-keys.service.js';

/**
 * Guard rail: the suite must never touch the development database.
 * If this fails, vitest.config.ts `test.env` stopped being applied and every
 * other test result would be meaningless.
 */
beforeAll(() => {
  expect(env.NODE_ENV).toBe('test');
  expect(env.DATABASE_URL).toContain('orbit_test');
  expect(env.isTest).toBe(true);
  expect(env.OPENROUTER_BASE_URL).toBe('http://127.0.0.1:4599/v1');
});

await startMockOpenRouter();

beforeEach(async () => {
  mockOpenRouter.reset();
  // The pool is a process-wide singleton; clear any simulated outage so it
  // cannot leak from one test file into the next.
  openRouterKeyPool.resetHealth();
  // TRUNCATE ... CASCADE resets every table in one statement.
  await prisma.$executeRawUnsafe(
    'TRUNCATE TABLE "credit_transactions", "audit_logs", "messages", "ai_requests", ' +
      '"conversations", "password_resets", "sessions", "media", "users", "site_settings" ' +
      'RESTART IDENTITY CASCADE',
  );
  await prisma.siteSettings.create({ data: { id: 'default' } });
});

afterAll(async () => {
  // The mock server is process-wide and shared across test files, so it is
  // deliberately NOT closed here — a later file would find a dead listener on
  // port 4599. It is unref'd, so the runner still exits cleanly.
  await prisma.$disconnect();
});
