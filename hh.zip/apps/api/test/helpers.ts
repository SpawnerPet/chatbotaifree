import type { Express } from 'express';
import supertest from 'supertest';
import type TestAgent from 'supertest/lib/agent.js';
import { createApp } from '../src/app.js';
import { hashPassword } from '../src/lib/password.js';
import { prisma } from '../src/lib/prisma.js';

let app: Express | null = null;

export function getApp(): Express {
  if (!app) app = createApp();
  return app;
}

export interface TestUser {
  id: string;
  email: string;
  username: string;
  password: string;
}

/**
 * A supertest agent that keeps the session cookie AND knows the CSRF token, so
 * tests exercise the real double-submit flow instead of bypassing it.
 */
export class Session {
  readonly agent: TestAgent;
  csrf: string | null = null;
  /** Raw name=value pairs accumulated from Set-Cookie, for raw http requests. */
  private readonly cookieJar = new Map<string, string>();

  constructor() {
    this.agent = supertest.agent(getApp());
  }

  /** Reads the readable CSRF cookie the server just set. */
  private captureCsrf(res: supertest.Response): void {
    const cookies = res.headers['set-cookie'];
    if (!Array.isArray(cookies)) return;
    for (const cookie of cookies) {
      const [pair = ''] = cookie.split(';');
      const eq = pair.indexOf('=');
      if (eq === -1) continue;
      const name = pair.slice(0, eq).trim();
      const value = pair.slice(eq + 1).trim();
      if (value.length === 0) this.cookieJar.delete(name);
      else this.cookieJar.set(name, value);
      if (name === 'orbit.csrf') this.csrf = decodeURIComponent(value);
    }
  }

  private withCsrf(req: supertest.Test): supertest.Test {
    return this.csrf ? req.set('X-CSRF-Token', this.csrf) : req;
  }

  async get(path: string) {
    const res = await this.agent.get(path);
    this.captureCsrf(res);
    return res;
  }

  async post(path: string, body?: unknown) {
    const res = await this.withCsrf(this.agent.post(path)).send(body as object);
    this.captureCsrf(res);
    return res;
  }

  async patch(path: string, body?: unknown) {
    const res = await this.withCsrf(this.agent.patch(path)).send(body as object);
    this.captureCsrf(res);
    return res;
  }

  async delete(path: string) {
    const res = await this.withCsrf(this.agent.delete(path));
    this.captureCsrf(res);
    return res;
  }

  /** POST of raw bytes with an explicit Content-Type (media uploads). */
  postRaw(path: string, contentType: string, body: Buffer) {
    return this.withCsrf(this.agent.post(path))
      .set('Content-Type', contentType)
      .send(body);
  }

  /** POST that deliberately omits the CSRF header. */
  postWithoutCsrf(path: string, body?: unknown) {
    return this.agent.post(path).send(body as object);
  }

  /** Raw Cookie header, for tests that need a real socket (abort, streaming). */
  cookieHeader(): string {
    return Array.from(this.cookieJar.entries())
      .map(([name, value]) => `${name}=${value}`)
      .join('; ');
  }

  csrfHeader(): string {
    if (!this.csrf) throw new Error('No CSRF token captured yet — log in first.');
    return this.csrf;
  }
}

let counter = 0;

export async function createUser(
  overrides: Partial<{ email: string; username: string; password: string; role: 'USER' | 'ADMIN'; credits: number; status: 'ACTIVE' | 'SUSPENDED' | 'BANNED' }> = {},
): Promise<TestUser> {
  counter += 1;
  const email = overrides.email ?? `user${counter}@example.test`;
  const username = overrides.username ?? `user${counter}`;
  const password = overrides.password ?? 'Passw0rd!23';
  const passwordHash = await hashPassword(password);

  const user = await prisma.user.create({
    data: {
      email,
      emailLower: email.toLowerCase(),
      username,
      passwordHash,
      role: overrides.role ?? 'USER',
      status: overrides.status ?? 'ACTIVE',
      credits: overrides.credits ?? 100,
    },
  });

  if ((overrides.credits ?? 100) > 0) {
    await prisma.creditTransaction.create({
      data: {
        userId: user.id,
        amount: overrides.credits ?? 100,
        type: 'BONUS',
        balanceBefore: 0,
        balanceAfter: overrides.credits ?? 100,
        description: 'Test setup',
      },
    });
  }

  return { id: user.id, email, username, password };
}

export async function loginAs(user: TestUser): Promise<Session> {
  const session = new Session();
  const res = await session.post('/api/auth/login', { email: user.email, password: user.password });
  if (res.status !== 200) {
    throw new Error(`Login failed in test setup: ${res.status} ${JSON.stringify(res.body)}`);
  }
  return session;
}

/** Reads the `data: {...}` frames out of an SSE response body. */
export function parseSse(raw: string): Array<Record<string, unknown>> {
  return raw
    .split('\n\n')
    .map((frame) => frame.split('\n').find((line) => line.startsWith('data:')))
    .filter((line): line is string => Boolean(line))
    .map((line) => line.slice(5).trim())
    .filter((payload) => payload.length > 0 && payload !== '[DONE]')
    .map((payload) => {
      try {
        return JSON.parse(payload) as Record<string, unknown>;
      } catch {
        return { event: 'unparseable', raw: payload };
      }
    });
}

/** Starts the real Express app on an ephemeral port, for tests that need a socket. */
export async function startServer(): Promise<{ url: string; close(): Promise<void> }> {
  const { createServer } = await import('node:http');
  const server = createServer(getApp());
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  const port = typeof address === 'object' && address ? address.port : 0;
  return {
    url: `http://127.0.0.1:${port}`,
    close: () =>
      new Promise<void>((resolve) => {
        server.closeAllConnections?.();
        server.close(() => resolve());
      }),
  };
}
