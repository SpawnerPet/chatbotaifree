import bcrypt from 'bcryptjs';
import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { Session, createUser, getApp, loginAs } from './helpers.js';
import supertest from 'supertest';

describe('authentication', () => {
  it('registers a user, hashes the password and grants the signup bonus', async () => {
    const app = getApp();
    const res = await supertest(app)
      .post('/api/auth/register')
      .send({ email: 'New.User@Example.com', username: 'newuser', password: 'Passw0rd!23' });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.email).toBe('new.user@example.com');
    expect(res.body.data.credits).toBe(100);
    expect(res.body.data).not.toHaveProperty('passwordHash');

    const stored = await prisma.user.findUniqueOrThrow({
      where: { emailLower: 'new.user@example.com' },
    });
    expect(stored.passwordHash).not.toBe('Passw0rd!23');
    expect(await bcrypt.compare('Passw0rd!23', stored.passwordHash)).toBe(true);

    const ledger = await prisma.creditTransaction.findMany({
      where: { userId: stored.id, type: 'SIGNUP_BONUS' },
    });
    expect(ledger).toHaveLength(1);
    expect(ledger[0]?.balanceBefore).toBe(0);
    expect(ledger[0]?.balanceAfter).toBe(100);
  });

  it('rejects a weak password and a duplicate email', async () => {
    const app = getApp();

    const weak = await supertest(app)
      .post('/api/auth/register')
      .send({ email: 'weak@example.com', username: 'weak', password: 'short' });
    expect(weak.status).toBe(422);
    expect(weak.body.error.code).toBe('VALIDATION_ERROR');

    await createUser({ email: 'taken@example.com', username: 'taken' });
    const dup = await supertest(app)
      .post('/api/auth/register')
      .send({ email: 'taken@example.com', username: 'other', password: 'Passw0rd!23' });
    expect(dup.status).toBe(409);
    expect(dup.body.error.code).toBe('EMAIL_TAKEN');
  });

  it('logs in, exposes /me, then logs out and invalidates the session', async () => {
    const user = await createUser({ email: 'login@example.com' });
    const session = new Session();

    const login = await session.post('/api/auth/login', {
      email: user.email,
      password: user.password,
    });
    expect(login.status).toBe(200);
    expect(login.body.data.credits).toBe(100);
    // HttpOnly session cookie, readable CSRF cookie.
    const cookies = login.headers['set-cookie'] as unknown as string[];
    expect(cookies.some((c) => c.startsWith('orbit.sid=') && c.includes('HttpOnly'))).toBe(true);
    expect(cookies.some((c) => c.startsWith('orbit.csrf='))).toBe(true);
    expect(cookies.join(';')).not.toContain(user.password);

    const me = await session.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.data.email).toBe(user.email);

    const logout = await session.post('/api/auth/logout');
    expect(logout.status).toBe(200);

    const after = await session.get('/api/auth/me');
    expect(after.status).toBe(401);
  });

  it('rejects a wrong password without revealing whether the account exists', async () => {
    const app = getApp();
    const user = await createUser({ email: 'secret@example.com' });

    const wrongPassword = await supertest(app)
      .post('/api/auth/login')
      .send({ email: user.email, password: 'WrongPassw0rd!' });
    const noSuchUser = await supertest(app)
      .post('/api/auth/login')
      .send({ email: 'nobody@example.com', password: 'WrongPassw0rd!' });

    expect(wrongPassword.status).toBe(401);
    expect(noSuchUser.status).toBe(401);
    expect(wrongPassword.body.error.message).toBe(noSuchUser.body.error.message);
  });

  it('blocks suspended and banned accounts at login', async () => {
    const app = getApp();
    const suspended = await createUser({
      email: 'suspended@example.com',
      status: 'SUSPENDED',
    });
    const banned = await createUser({ email: 'banned@example.com', status: 'BANNED' });

    const s = await supertest(app)
      .post('/api/auth/login')
      .send({ email: suspended.email, password: suspended.password });
    expect(s.status).toBe(403);
    expect(s.body.error.code).toBe('ACCOUNT_SUSPENDED');

    const b = await supertest(app)
      .post('/api/auth/login')
      .send({ email: banned.email, password: banned.password });
    expect(b.status).toBe(403);
    expect(b.body.error.code).toBe('ACCOUNT_BANNED');
  });

  it('requires the CSRF token on mutating requests but not on login', async () => {
    const user = await createUser();
    const session = await loginAs(user);

    const missing = await session.postWithoutCsrf('/api/conversations', { title: 'nope' });
    expect(missing.status).toBe(403);
    expect(missing.body.error.code).toBe('CSRF_INVALID');

    const ok = await session.post('/api/conversations', { title: 'allowed' });
    expect(ok.status).toBe(201);
  });

  it('resets a password with a one-time token and revokes existing sessions', async () => {
    const user = await createUser({ email: 'reset@example.com' });
    const session = await loginAs(user);
    expect((await session.get('/api/auth/me')).status).toBe(200);

    const app = getApp();
    const forgot = await supertest(app)
      .post('/api/auth/forgot-password')
      .send({ email: user.email });
    expect(forgot.status).toBe(200);
    // The response is intentionally identical for unknown addresses.
    const unknown = await supertest(app)
      .post('/api/auth/forgot-password')
      .send({ email: 'nobody@example.com' });
    expect(unknown.body.data.message).toBe(forgot.body.data.message);

    const token = forgot.headers['x-dev-reset-token'] as string;
    expect(typeof token).toBe('string');
    expect(token.length).toBeGreaterThan(20);

    const reset = await supertest(app)
      .post('/api/auth/reset-password')
      .send({ token, password: 'BrandNew!42' });
    expect(reset.status).toBe(200);

    // The old session is dead.
    expect((await session.get('/api/auth/me')).status).toBe(401);

    // The token cannot be replayed.
    const replay = await supertest(app)
      .post('/api/auth/reset-password')
      .send({ token, password: 'Another!42' });
    expect(replay.status).toBe(400);
    expect(replay.body.error.code).toBe('INVALID_TOKEN');

    const relogin = await supertest(app)
      .post('/api/auth/login')
      .send({ email: user.email, password: 'BrandNew!42' });
    expect(relogin.status).toBe(200);
  });

  it('changes the password and keeps the current session alive', async () => {
    const user = await createUser({ email: 'change@example.com' });
    const session = await loginAs(user);

    const wrong = await session.post('/api/auth/change-password', {
      currentPassword: 'NotTheOne!1',
      newPassword: 'FreshPassw0rd!',
    });
    expect(wrong.status).toBe(401);

    const changed = await session.post('/api/auth/change-password', {
      currentPassword: user.password,
      newPassword: 'FreshPassw0rd!',
    });
    expect(changed.status).toBe(200);
    expect((await session.get('/api/auth/me')).status).toBe(200);

    const old = await supertest(getApp())
      .post('/api/auth/login')
      .send({ email: user.email, password: user.password });
    expect(old.status).toBe(401);
  });

  it('lists and revokes sessions', async () => {
    const user = await createUser();
    const first = await loginAs(user);
    const second = await loginAs(user);

    const sessions = await first.get('/api/auth/sessions');
    expect(sessions.status).toBe(200);
    expect(sessions.body.data).toHaveLength(2);
    expect(sessions.body.data.filter((s: { current: boolean }) => s.current)).toHaveLength(1);

    const other = sessions.body.data.find((s: { current: boolean }) => !s.current);
    const revoked = await first.delete(`/api/auth/sessions/${other.id}`);
    expect(revoked.status).toBe(200);
    expect((await second.get('/api/auth/me')).status).toBe(401);
  });

  it('never returns a stack trace or internal message on failure', async () => {
    const res = await supertest(getApp())
      .post('/api/auth/login')
      .send({ email: 'not-an-email', password: '' });
    expect(res.status).toBe(422);
    expect(res.body.success).toBe(false);
    expect(JSON.stringify(res.body)).not.toMatch(/at \w+ \(.*:\d+:\d+\)/);
    expect(res.body.error).not.toHaveProperty('stack');
  });
});
