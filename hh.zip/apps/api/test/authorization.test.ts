import { describe, expect, it } from 'vitest';
import { prisma } from '../src/lib/prisma.js';
import { createUser, loginAs, Session } from './helpers.js';

describe('authorization', () => {
  it('keeps a normal user out of every admin endpoint', async () => {
    const user = await createUser({ role: 'USER' });
    const session = await loginAs(user);

    const endpoints: Array<[string, () => Promise<{ status: number }>]> = [
      ['/api/admin/stats', () => session.get('/api/admin/stats')],
      ['/api/admin/users', () => session.get('/api/admin/users')],
      ['/api/admin/audit-logs', () => session.get('/api/admin/audit-logs')],
      ['/api/admin/media', () => session.get('/api/admin/media')],
      [
        `/api/admin/users/${user.id}/status`,
        () => session.patch(`/api/admin/users/${user.id}/status`, { status: 'BANNED' }),
      ],
      [
        `/api/admin/users/${user.id}/credits`,
        () => session.post(`/api/admin/users/${user.id}/credits`, { amount: 999, reason: 'self' }),
      ],
      ['/api/admin/settings', () => session.patch('/api/admin/settings', { siteName: 'Hacked' })],
    ];

    for (const [label, call] of endpoints) {
      const res = await call();
      expect(res.status, `${label} should be forbidden`).toBe(403);
    }

    // The user could not escalate their own role or credits.
    const after = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
    expect(after.role).toBe('USER');
    expect(after.status).toBe('ACTIVE');
    expect(after.credits).toBe(100);
  });

  it('ignores a role or credit value sent by the client on a chat request', async () => {
    const user = await createUser({ role: 'USER', credits: 5 });
    const session = await loginAs(user);

    // The client tries to smuggle privileged fields into the body.
    const res = await session.post('/api/chat', {
      message: 'hi',
      role: 'ADMIN',
      credits: 100000,
      cost: 0,
    });

    // The mock provider is not configured for this file, so the call fails —
    // what matters is that the request was charged normally and the user was
    // not granted anything.
    const after = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });
    expect(after.role).toBe('USER');
    expect(after.credits).toBeLessThanOrEqual(5);
    expect(res.body).toBeDefined();
  });

  it('requires authentication for chat and conversation routes', async () => {
    const anonymous = new Session();
    const calls: Array<[string, Promise<{ status: number }>]> = [
      ['/api/conversations', anonymous.get('/api/conversations')],
      ['/api/chat', anonymous.post('/api/chat', { message: 'hi' })],
      ['/api/chat/stream', anonymous.post('/api/chat/stream', { message: 'hi' })],
      ['/api/user/profile', anonymous.get('/api/user/profile')],
    ];

    for (const [label, pending] of calls) {
      const res = await pending;
      expect(res.status, `${label} should require auth`).toBe(401);
    }
  });

  it('hides other users’ conversations', async () => {
    const owner = await createUser();
    const intruder = await createUser();
    const ownerSession = await loginAs(owner);

    const created = await ownerSession.post('/api/conversations', { title: 'Private plans' });
    const conversationId = created.body.data.id as string;

    const intruderSession = await loginAs(intruder);
    expect((await intruderSession.get(`/api/conversations/${conversationId}`)).status).toBe(404);
    expect((await intruderSession.patch(`/api/conversations/${conversationId}`, { title: 'x' })).status).toBe(404);
    expect((await intruderSession.delete(`/api/conversations/${conversationId}`)).status).toBe(404);

    const list = await intruderSession.get('/api/conversations');
    expect(list.body.data.items).toHaveLength(0);
  });
});
