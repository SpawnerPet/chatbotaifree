import type { ServerResponse } from 'node:http';
import { describe, expect, it } from 'vitest';
import { openRouterService } from '../src/services/openrouter.service.js';
import { mockOpenRouter } from './mock-openrouter.js';

const okJson = (content: string) => (_c: unknown, res: ServerResponse) => {
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(
    JSON.stringify({
      id: 'gen-1',
      model: 'test/model:free',
      choices: [{ index: 0, message: { role: 'assistant', content }, finish_reason: 'stop' }],
    }),
  );
};

describe('OpenRouterService', () => {
  it('completes a request and normalises the payload', async () => {
    mockOpenRouter.setHandler(okJson('The answer.'));

    const result = await openRouterService.complete({
      model: 'openrouter/free',
      messages: [{ role: 'user', content: 'hi' }],
    });

    expect(result.content).toBe('The answer.');
    expect(result.model).toBe('test/model:free');
    expect(result.finishReason).toBe('stop');
    expect(result.durationMs).toBeGreaterThanOrEqual(0);
  });

  it('sends the API key as a bearer token and never in the body', async () => {
    mockOpenRouter.setHandler(okJson('ok'));
    await openRouterService.complete({
      model: 'openrouter/free',
      messages: [{ role: 'user', content: 'hi' }],
    });

    const call = mockOpenRouter.calls()[0]!;
    expect(call.authorization).toMatch(/^Bearer sk-or-v1-/);
    expect(JSON.stringify(call.body)).not.toContain('sk-or-v1-');
  });

  it('maps a 429 to a rate-limit error', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'slow down' } }));
    });

    await expect(
      openRouterService.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_RATE_LIMITED' });
  });

  it('maps a 404 to an unavailable-model error', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: { message: 'no such model' } }));
    });

    await expect(
      openRouterService.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_ERROR' });
  });

  it('rejects a malformed JSON body instead of crashing', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end('{"choices": [ this is not json');
    });

    await expect(
      openRouterService.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_ERROR' });
  });

  it('rejects a well-formed but empty response', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ choices: [{ index: 0, message: { role: 'assistant', content: null } }] }));
    });

    await expect(
      openRouterService.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_ERROR' });
  });

  it('times out a hanging request', async () => {
    mockOpenRouter.setHandler(() => {
      // Never respond.
    });

    await expect(
      openRouterService.complete({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }),
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_TIMEOUT' });
  }, 20_000);

  it('retries a transient 500 and succeeds on the second attempt', async () => {
    let attempts = 0;
    mockOpenRouter.setHandler((_c, res) => {
      attempts += 1;
      if (attempts === 1) {
        res.writeHead(503, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: { message: 'cold start' } }));
        return;
      }
      okJson('recovered')(_c, res);
    });

    const result = await openRouterService.complete({
      model: 'openrouter/free',
      messages: [{ role: 'user', content: 'x' }],
    });
    expect(result.content).toBe('recovered');
    expect(attempts).toBe(2);
  }, 20_000);

  it('reports a health check without leaking the key', async () => {
    const health = await openRouterService.health();
    expect(health).toEqual({
      configured: true,
      model: 'openrouter/free',
      status: 'ok',
      keysTotal: 1,
      keysAvailable: 1,
    });
    expect(JSON.stringify(health)).not.toContain('sk-or-v1-');
  });

  it('streams deltas and resolves on [DONE]', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      mockOpenRouter.sse(res, ['one ', 'two ', 'three']);
    });

    const chunks: string[] = [];
    const handle = openRouterService.stream(
      { model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] },
      (chunk) => chunks.push(chunk.text),
    );
    const result = await handle.done;

    expect(chunks.join('')).toBe('one two three');
    expect(result.model).toBe('openrouter/free');
  });

  it('survives a single malformed SSE frame', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {not json}\n\n');
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: 'recovered' } }] })}\n\n`);
      res.write('data: [DONE]\n\n');
      res.end();
    });

    const chunks: string[] = [];
    await openRouterService.stream(
      { model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] },
      (chunk) => chunks.push(chunk.text),
    ).done;

    expect(chunks.join('')).toBe('recovered');
  });

  it('fails a stream that never produces a valid frame', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write('data: {not json}\n\n');
      res.end();
    });

    await expect(
      openRouterService
        .stream({ model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] }, () => undefined)
        .done,
    ).rejects.toMatchObject({ code: 'AI_PROVIDER_ERROR' });
  });

  it('falls back to streamed reasoning when a model emits no content', async () => {
    // Some free models answer with reasoning only and leave `content` empty.
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(
        `data: ${JSON.stringify({ choices: [{ delta: { reasoning: 'Thinking it through.' } }] })}\n\n`,
      );
      res.write('data: [DONE]\n\n');
      res.end();
    });

    const chunks: string[] = [];
    await openRouterService.stream(
      { model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] },
      (chunk) => chunks.push(chunk.text),
    ).done;

    expect(chunks.join('')).toBe('Thinking it through.');
  });

  it('retries a stream that completes with no usable output', async () => {
    let attempts = 0;
    mockOpenRouter.setHandler((_c, res) => {
      attempts += 1;
      if (attempts === 1) {
        // Valid frames, but the model produced nothing.
        res.writeHead(200, { 'Content-Type': 'text/event-stream' });
        res.write('data: [DONE]\n\n');
        res.end();
        return;
      }
      mockOpenRouter.sse(res, ['second time lucky']);
    });

    const chunks: string[] = [];
    await openRouterService.stream(
      { model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] },
      (chunk) => chunks.push(chunk.text),
    ).done;

    expect(attempts).toBe(2);
    expect(chunks.join('')).toBe('second time lucky');
  }, 20_000);

  it('aborts an in-flight stream on request', async () => {
    mockOpenRouter.setHandler((_c, res) => {
      res.writeHead(200, { 'Content-Type': 'text/event-stream' });
      res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: 'partial' } }] })}\n\n`);
      // Hangs until the client goes away.
    });

    const handle = openRouterService.stream(
      { model: 'openrouter/free', messages: [{ role: 'user', content: 'x' }] },
      () => undefined,
    );
    await new Promise((resolve) => setTimeout(resolve, 100));
    handle.abort('user pressed stop');

    await expect(handle.done).rejects.toMatchObject({ code: 'ABORTED' });
    expect(handle.aborted).toBe(true);
  });

  it('refuses a model that is not on the allow-list', async () => {
    await expect(
      openRouterService.complete({
        model: 'some/paid-model',
        messages: [{ role: 'user', content: 'x' }],
      }),
    ).rejects.toMatchObject({ code: 'VALIDATION_ERROR' });
    expect(mockOpenRouter.callCount()).toBe(0);
  });
});
