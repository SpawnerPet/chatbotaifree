import compression from 'compression';
import cookieParser from 'cookie-parser';
import cors, { type CorsOptions } from 'cors';
import express, { type Express } from 'express';
import helmet from 'helmet';
import { ERROR_CODES } from '@orbit/shared';
import { env } from './config/env.js';
import { AppError } from './lib/errors.js';
import { logger } from './lib/logger.js';
import { attachSession, csrfProtection, notFoundHandler } from './middleware/auth.js';
import { errorHandler } from './middleware/error-handler.js';
import { globalLimiter } from './middleware/rate-limit.js';
import { authRouter } from './routes/auth.routes.js';
import { apiRouter } from './routes/index.js';
import * as userController from './controllers/user.controller.js';
import { asyncHandler } from './middleware/error-handler.js';
import { requireAuth } from './middleware/auth.js';
import { updateProfileSchema } from '@orbit/shared';
import { validate } from './middleware/validate.js';
import { mkdir } from 'node:fs/promises';

/** True when `origin` points at the same host this process is serving. */
function sameHost(origin: string, host: string): boolean {
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export function createApp(): Express {
  const app = express();

  // Behind a reverse proxy (nginx, Railway, Fly) so rate limiting and IP
  // logging see the real client address.
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.set('etag', 'strong');

  app.use(
    helmet({
      contentSecurityPolicy: false, // The SPA is served separately; API responses are JSON.
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
      hsts: env.isProd ? { maxAge: 31_536_000, includeSubDomains: true, preload: false } : false,
    }),
  );

  /**
   * CORS is a real allow-list, not a blanket `true`.
   *
   * Besides the configured frontend origins, a request whose Origin matches
   * the Host this process sees is treated as same-origin. That is the normal
   * production topology (nginx / Railway / Fly proxying /api to this service),
   * where the browser still sends an Origin header on POST.
   */
  app.use(
    cors((req, callback) => {
      const origin = req.headers.origin;
      const host = req.headers.host;

      const allowed =
        !origin ||
        env.corsOrigins.includes(origin) ||
        (host !== undefined && sameHost(origin, host));

      if (!allowed) {
        callback(new AppError(ERROR_CODES.FORBIDDEN, 'Origin not allowed by CORS'), { origin: false } as CorsOptions);
        return;
      }

      callback(null, {
        origin: true,
        credentials: true,
        methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'X-CSRF-Token', 'Authorization'],
        exposedHeaders: ['X-Dev-Reset-Token'],
        maxAge: 600,
      });
    }),
  );

  app.use(compression());
  app.use(cookieParser());
  app.use(express.json({ limit: env.maxBodyJsonBytes }));
  app.use(express.urlencoded({ extended: false, limit: env.maxBodyJsonBytes }));
  app.use(globalLimiter);
  app.use(attachSession);
  app.use(csrfProtection);

  // Locally-served uploads. The response is immutable and sniffed-safe: only
  // validated media ever lands in this directory.
  app.use(
    '/media',
    (_req, res, next) => {
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      res.setHeader(
        'Content-Security-Policy',
        "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'",
      );
      next();
    },
    express.static(env.storageLocalPath, { index: false, dotfiles: 'deny', fallthrough: true }),
  );

  const userRouter = express.Router();
  userRouter.use(requireAuth);
  userRouter.get('/profile', asyncHandler(userController.getProfile));
  userRouter.patch(
    '/profile',
    validate(updateProfileSchema),
    asyncHandler(userController.updateProfile),
  );
  userRouter.get('/credits', asyncHandler(userController.getCreditHistory));
  userRouter.get('/usage', asyncHandler(userController.getUsageSummary));

  app.use('/api/auth', authRouter);
  app.use('/api/user', userRouter);
  app.use('/api', apiRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}

export async function prepareStorage(): Promise<void> {
  if (env.STORAGE_PROVIDER !== 'local') return;
  await mkdir(env.storageLocalPath, { recursive: true });
  logger.info('upload directory ready', { dir: env.storageLocalPath });
}
