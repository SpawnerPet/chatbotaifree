import { env } from '../config/env.js';
import { logger } from '../lib/logger.js';

export type KeyState = 'active' | 'cooldown' | 'parked';

export interface KeyStatus {
  /** Position in the pool; #1 is tried first. */
  position: number;
  /** Safe to display: never the key itself. */
  label: string;
  state: KeyState;
  consecutiveFailures: number;
  /** ISO timestamp until which this key is benched. */
  cooldownUntil: string | null;
  cooldownRemainingSeconds: number;
  lastUsedAt: string | null;
  lastError: string | null;
  totalUses: number;
  totalFailures: number;
}

interface PoolEntry {
  key: string;
  label: string;
  state: KeyState;
  consecutiveFailures: number;
  cooldownUntil: number;
  totalUses: number;
  totalFailures: number;
  lastUsedAt: number;
  lastError: string | null;
}

/**
 * Provider errors that mean "this key is not usable right now" rather than
 * "this request was bad".
 */
const QUOTA_STATUSES = new Set([401, 402, 403, 429]);

/**
 * A rotating pool of provider API keys.
 *
 * When a key is rate limited, out of quota or rejected, it is benched and the
 * next request uses a different key automatically. Keys are never logged, never
 * returned by an endpoint, and never persisted — they exist only in memory,
 * read from the environment at boot.
 */
export class OpenRouterKeyPool {
  private readonly entries: PoolEntry[] = [];
  private cursor = 0;
  private rotations = 0;

  constructor(keys: string[] = env.openRouterKeyPool) {
    keys.forEach((key, index) => {
      this.entries.push({
        key,
        label: maskKey(key, index),
        state: 'active',
        consecutiveFailures: 0,
        cooldownUntil: 0,
        totalUses: 0,
        totalFailures: 0,
        lastUsedAt: 0,
        lastError: null,
      });
    });
  }

  get size(): number {
    return this.entries.length;
  }

  isConfigured(): boolean {
    return this.entries.length > 0;
  }

  /**
   * Returns the next usable key.
   *
   * `preferred` lets a retry keep the key it already used: a transient 5xx is
   * the provider's problem, not the key's, so churning the pool would be noise.
   * If the preferred key has since been benched, rotation kicks in instead.
   */
  acquire(preferred?: string): string | null {
    const now = Date.now();
    if (preferred) {
      const entry = this.find(preferred);
      if (entry && (entry.state === 'active' || (entry.state === 'cooldown' && entry.cooldownUntil <= now))) {
        if (entry.state === 'cooldown') {
          entry.state = 'active';
          entry.cooldownUntil = 0;
          entry.consecutiveFailures = 0;
          entry.lastError = null;
        }
        entry.totalUses += 1;
        entry.lastUsedAt = now;
        return entry.key;
      }
    }
    for (let step = 0; step < this.entries.length; step += 1) {
      const index = (this.cursor + step) % this.entries.length;
      const entry = this.entries[index];
      if (!entry) continue;

      if (entry.state === 'cooldown' && entry.cooldownUntil <= now) {
        // The bench expired; give the key another chance.
        entry.state = 'active';
        entry.cooldownUntil = 0;
        entry.consecutiveFailures = 0;
        entry.lastError = null;
        logger.info('openrouter key cooldown expired', { label: entry.label });
      }

      if (entry.state === 'active') {
        this.cursor = (index + 1) % this.entries.length;
        entry.totalUses += 1;
        entry.lastUsedAt = now;
        return entry.key;
      }
    }
    return null;
  }

  /** How many keys are usable right now. */
  availableCount(): number {
    const now = Date.now();
    return this.entries.filter(
      (e) => e.state === 'active' || (e.state === 'cooldown' && e.cooldownUntil <= now),
    ).length;
  }

  reportSuccess(key: string): void {
    const entry = this.find(key);
    if (!entry) return;
    entry.consecutiveFailures = 0;
    entry.lastError = null;
    if (entry.state === 'cooldown') {
      entry.state = 'active';
      entry.cooldownUntil = 0;
    }
  }

  /**
   * Records a provider outcome. Quota/auth errors bench the key; everything
   * else (5xx, timeouts) counts towards the failure threshold but does not
   * rotate immediately, because the key itself is probably fine.
   */
  reportFailure(key: string, status: number | null, code: string): void {
    const entry = this.find(key);
    if (!entry) return;

    entry.totalFailures += 1;
    entry.consecutiveFailures += 1;
    entry.lastError = `${status ?? 'network'} ${code}`;

    const quotaIssue = status !== null && QUOTA_STATUSES.has(status);

    if (quotaIssue) {
      const cooldownMs = env.OPENROUTER_KEY_COOLDOWN_SECONDS * 1000;
      entry.state = 'cooldown';
      entry.cooldownUntil = Date.now() + cooldownMs;
      this.rotations += 1;
      logger.warn('openrouter key benched', {
        label: entry.label,
        status,
        code,
        cooldownSeconds: env.OPENROUTER_KEY_COOLDOWN_SECONDS,
        remaining: this.availableCount(),
      });
      return;
    }

    if (entry.consecutiveFailures >= env.OPENROUTER_KEY_MAX_FAILURES) {
      entry.state = 'parked';
      this.rotations += 1;
      logger.error('openrouter key parked after repeated failures', {
        label: entry.label,
        failures: entry.consecutiveFailures,
        code,
      });
    }
  }

  status(): KeyStatus[] {
    const now = Date.now();
    return this.entries.map((entry, index) => {
      const cooling = entry.state === 'cooldown' && entry.cooldownUntil > now;
      return {
        position: index + 1,
        label: entry.label,
        state: cooling ? 'cooldown' : entry.state,
        consecutiveFailures: entry.consecutiveFailures,
        cooldownUntil: entry.cooldownUntil ? new Date(entry.cooldownUntil).toISOString() : null,
        cooldownRemainingSeconds: cooling
          ? Math.ceil((entry.cooldownUntil - now) / 1000)
          : 0,
        lastUsedAt: entry.lastUsedAt ? new Date(entry.lastUsedAt).toISOString() : null,
        lastError: entry.lastError,
        totalUses: entry.totalUses,
        totalFailures: entry.totalFailures,
      };
    });
  }

  /** Number of times a key has been taken out of rotation. */
  get rotationCount(): number {
    return this.rotations;
  }

  private find(key: string): PoolEntry | undefined {
    return this.entries.find((e) => e.key === key);
  }

  /**
   * Clears all per-key health state without dropping the keys themselves.
   * Used between test files so one file's simulated outage cannot leak into
   * the next.
   */
  resetHealth(): void {
    this.cursor = 0;
    this.rotations = 0;
    for (const entry of this.entries) {
      entry.state = 'active';
      entry.consecutiveFailures = 0;
      entry.cooldownUntil = 0;
      entry.totalUses = 0;
      entry.totalFailures = 0;
      entry.lastError = null;
    }
  }
}

/**
 * Safe display label. Enough to tell two keys apart in a UI without being
 * usable: only the last four characters survive.
 */
export function maskKey(key: string, index: number): string {
  if (key.length <= 8) return `key #${index + 1}`;
  return `key #${index + 1} ····${key.slice(-4)}`;
}

export const openRouterKeyPool = new OpenRouterKeyPool();

/** Test hook: rebuild the pool from an explicit list. */
export function createKeyPool(keys: string[]): OpenRouterKeyPool {
  return new OpenRouterKeyPool(keys);
}
