import type { AuditAction, Prisma } from '@prisma/client';
import { prisma } from '../lib/prisma.js';

export interface AuditInput {
  adminId: string;
  action: AuditAction;
  targetUserId?: string | null;
  metadata?: Prisma.InputJsonValue;
}

/** Every privileged mutation lands here so "who did what" is always answerable. */
export async function recordAudit(input: AuditInput): Promise<void> {
  try {
    await prisma.auditLog.create({
      data: {
        adminId: input.adminId,
        action: input.action,
        targetUserId: input.targetUserId ?? null,
        metadata: input.metadata ?? {},
      },
    });
  } catch (err) {
    // Auditing must never break the admin action that triggered it, but a
    // failure here is a real problem and should be visible in the logs.
    const { logger } = await import('../lib/logger.js');
    logger.error('audit log write failed', { action: input.action, error: String(err) });
  }
}
