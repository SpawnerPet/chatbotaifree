import {
  DeleteObjectCommand,
  GetObjectCommand,
  PutObjectCommand,
  S3Client,
} from '@aws-sdk/client-s3';
import { mkdir, rm, stat } from 'node:fs/promises';
import path from 'node:path';
import { env } from '../config/env.js';
import { logger } from '../lib/logger.js';

export interface PutResult {
  key: string;
  url: string;
  size: number;
}

export interface StorageService {
  readonly provider: string;
  put(key: string, body: Buffer, contentType: string): Promise<PutResult>;
  delete(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
  /** Absolute path on disk, or null for remote providers. */
  localPath(key: string): string | null;
}

function assertSafeKey(key: string): void {
  if (
    key.includes('..') ||
    key.startsWith('/') ||
    key.includes('\0') ||
    !/^[A-Za-z0-9][A-Za-z0-9/_.-]*$/.test(key)
  ) {
    throw new Error('Unsafe storage key rejected.');
  }
}

/** Development default: files land on disk under apps/api/var/uploads. */
class LocalStorageService implements StorageService {
  readonly provider = 'local';

  constructor(private readonly root: string) {}

  private resolve(key: string): string {
    assertSafeKey(key);
    const full = path.join(this.root, key);
    // Belt and braces: the resolved path must stay inside the root.
    if (!full.startsWith(path.resolve(this.root) + path.sep)) {
      throw new Error('Storage path escapes the upload root.');
    }
    return full;
  }

  async put(key: string, body: Buffer, _contentType: string): Promise<PutResult> {
    const full = this.resolve(key);
    await mkdir(path.dirname(full), { recursive: true });
    const { writeFile } = await import('node:fs/promises');
    await writeFile(full, body, { mode: 0o644 });
    return { key, url: `${env.storagePublicBaseUrl.replace(/\/+$/, '')}/${key}`, size: body.byteLength };
  }

  async delete(key: string): Promise<void> {
    const full = this.resolve(key);
    await rm(full, { force: true });
  }

  async exists(key: string): Promise<boolean> {
    try {
      await stat(this.resolve(key));
      return true;
    } catch {
      return false;
    }
  }

  localPath(key: string): string | null {
    return this.resolve(key);
  }
}

/**
 * Production default: any S3-compatible store — AWS S3, Cloudflare R2,
 * Supabase Storage, MinIO, Backblaze B2.
 */
class S3StorageService implements StorageService {
  readonly provider = 's3';
  private readonly client: S3Client;

  constructor(
    private readonly bucket: string,
    endpoint: string,
    region: string,
    accessKeyId: string,
    secretAccessKey: string,
    forcePathStyle: boolean,
  ) {
    this.client = new S3Client({
      region,
      // R2 and most S3-compatible providers want path-style addressing.
      endpoint: endpoint || undefined,
      forcePathStyle,
      credentials: { accessKeyId, secretAccessKey },
    });
  }

  async put(key: string, body: Buffer, contentType: string): Promise<PutResult> {
    assertSafeKey(key);
    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucket,
        Key: key,
        Body: body,
        ContentType: contentType,
        CacheControl: 'public, max-age=31536000, immutable',
      }),
    );
    return { key, url: this.publicUrl(key), size: body.byteLength };
  }

  async delete(key: string): Promise<void> {
    assertSafeKey(key);
    await this.client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }

  async exists(key: string): Promise<boolean> {
    try {
      await this.client.send(new GetObjectCommand({ Bucket: this.bucket, Key: key, Range: 'bytes=0-0' }));
      return true;
    } catch {
      return false;
    }
  }

  localPath(): string | null {
    return null;
  }

  private publicUrl(key: string): string {
    const base = env.storagePublicBaseUrl.replace(/\/+$/, '');
    if (base) return `${base}/${key}`;
    const endpoint = env.S3_ENDPOINT.replace(/\/+$/, '');
    return `${endpoint}/${this.bucket}/${key}`;
  }
}

function createStorage(): StorageService {
  if (env.STORAGE_PROVIDER === 's3') {
    const { S3_ENDPOINT, S3_REGION, S3_BUCKET, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_FORCE_PATH_STYLE } =
      env;
    if (!S3_BUCKET || !S3_ACCESS_KEY_ID || !S3_SECRET_ACCESS_KEY) {
      throw new Error(
        'STORAGE_PROVIDER=s3 requires S3_BUCKET, S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY.',
      );
    }
    logger.info('storage: s3-compatible backend enabled', { bucket: S3_BUCKET });
    return new S3StorageService(
      S3_BUCKET,
      S3_ENDPOINT,
      S3_REGION,
      S3_ACCESS_KEY_ID,
      S3_SECRET_ACCESS_KEY,
      S3_FORCE_PATH_STYLE,
    );
  }
  logger.info('storage: local disk backend enabled');
  return new LocalStorageService(env.storageLocalPath);
}

export const storageService: StorageService = createStorage();
