import { ERROR_CODES } from '@orbit/shared';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { openRouterKeyPool, type OpenRouterKeyPool } from './openrouter-keys.service.js';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface CompletionRequest {
  model: string;
  messages: ChatMessage[];
  maxTokens?: number;
  temperature?: number;
  signal?: AbortSignal;
}

export interface CompletionResult {
  content: string;
  model: string;
  finishReason: string | null;
  durationMs: number;
}

export interface StreamChunk {
  text: string;
}

export interface StreamHandle {
  /** Resolves once the stream ends normally. Rejects with AppError otherwise. */
  done: Promise<{ model: string; finishReason: string | null; durationMs: number }>;
  abort(reason?: string): void;
  readonly aborted: boolean;
}

const DEFAULT_MAX_TOKENS = 4096;
const DEFAULT_TEMPERATURE = 0.7;

export function isConfigured(): boolean {
  return openRouterKeyPool.isConfigured();
}

function assertConfigured(): void {
  if (!isConfigured()) {
    throw new AppError(
      ERROR_CODES.AI_NOT_CONFIGURED,
      'The AI provider is not configured. Add OPENROUTER_API_KEY to the server environment.',
    );
  }
}

function assertModelAllowed(model: string): void {
  if (!env.allowedModels.includes(model)) {
    throw new AppError(
      ERROR_CODES.VALIDATION_ERROR,
      'That model is not available on this deployment.',
    );
  }
}

function buildHeaders(apiKey: string): Record<string, string> {
  // The key is passed in by the pool and never logged or echoed.
  return {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    'HTTP-Referer': env.WEB_URL,
    'X-Title': 'Orbit AI',
  };
}

function classifyStatus(status: number): AppError {
  const withStatus = (err: AppError) => {
    // The key pool needs the status to decide between rotating and retrying.
    (err as AppError & { providerStatus?: number }).providerStatus = status;
    return err;
  };

  if (status === 429) return withStatus(new AppError(ERROR_CODES.AI_PROVIDER_RATE_LIMITED));
  if (status === 408 || status === 504) return withStatus(new AppError(ERROR_CODES.AI_PROVIDER_TIMEOUT));

  if (status === 402 || status === 403) {
    return withStatus(
      new AppError(
        ERROR_CODES.AI_PROVIDER_ERROR,
        'The AI provider rejected this request. You were not charged.',
      ),
    );
  }
  if (status === 404) {
    return withStatus(
      new AppError(
        ERROR_CODES.AI_PROVIDER_ERROR,
        'The selected model is currently unavailable. You were not charged.',
      ),
    );
  }
  if (status >= 500) {
    return withStatus(
      new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI provider is unavailable. You were not charged.'),
    );
  }
  return withStatus(
    new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI request was rejected. You were not charged.'),
  );
}

/** Statuses that mean "this key cannot serve the request right now". */
function isQuotaStatus(status: number | null): boolean {
  return status !== null && (status === 401 || status === 402 || status === 403 || status === 429);
}

function providerStatusOf(err: unknown): number | null {
  if (err instanceof AppError) {
    const status = (err as AppError & { providerStatus?: number }).providerStatus;
    return typeof status === 'number' ? status : null;
  }
  return null;
}

function isRetryable(err: unknown): boolean {
  if (err instanceof AppError) {
    return (
      err.code === ERROR_CODES.AI_PROVIDER_TIMEOUT ||
      err.code === ERROR_CODES.AI_PROVIDER_ERROR
    );
  }
  // Network-level failures (DNS, TLS, reset) are worth one more try.
  return err instanceof Error;
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Owns every outbound call to OpenRouter.
 *
 * Responsibilities: request building, streaming/SSE parsing, timeouts,
 * cancellation, retries on transient failures, provider error mapping and
 * defence against malformed payloads. The API key never leaves this module.
 */
export class OpenRouterService {
  private readonly endpoint = `${env.OPENROUTER_BASE_URL.replace(/\/+$/, '')}/chat/completions`;
  /** Injectable so the key-rotation path can be tested with a multi-key pool. */
  private readonly pool: OpenRouterKeyPool;

  constructor(pool: OpenRouterKeyPool = openRouterKeyPool) {
    this.pool = pool;
  }

  /** Non-streaming completion. Retries transient failures with backoff. */
  async complete(req: CompletionRequest): Promise<CompletionResult> {
    assertConfigured();
    assertModelAllowed(req.model);

    const started = Date.now();
    const maxAttempts = env.OPENROUTER_MAX_RETRIES + 1;
    let lastError: unknown;
    let usedKey: string | undefined;

    for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
      const apiKey = this.pool.acquire(usedKey);
      usedKey = apiKey ?? undefined;
      if (!apiKey) {
        // Every key is benched. Fail fast rather than burning a user turn.
        lastError = new AppError(
          ERROR_CODES.AI_PROVIDER_RATE_LIMITED,
          'The AI provider is rate limited on every configured key. You were not charged.',
        );
        break;
      }
      try {
        const result = await this.attemptComplete(req, started, apiKey);
        this.pool.reportSuccess(apiKey);
        return result;
      } catch (err) {
        lastError = err;
        this.pool.reportFailure(apiKey, providerStatusOf(err), codeOf(err));

        if (req.signal?.aborted) break;

        // A quota/auth failure means the key is spent, not the request — switch
        // keys immediately instead of waiting out a backoff.
        const rotated = providerStatusOf(err) !== null && isQuotaStatus(providerStatusOf(err));
        if (rotated) {
          logger.warn('openrouter rotating key after quota error', {
            attempt,
            code: codeOf(err),
            available: this.pool.availableCount(),
          });
          if (attempt === maxAttempts || this.pool.availableCount() === 0) break;
          continue;
        }

        if (attempt === maxAttempts || !isRetryable(err)) break;
        const backoff = Math.min(4000, 400 * 2 ** (attempt - 1)) + Math.floor(Math.random() * 250);
        logger.warn('openrouter retry', { attempt, delayMs: backoff, code: codeOf(err) });
        await sleep(backoff);
      }
    }
    throw toAppError(lastError);
  }

  private async attemptComplete(
    req: CompletionRequest,
    started: number,
    apiKey: string,
  ): Promise<CompletionResult> {
    const timeout = AbortSignal.timeout(env.OPENROUTER_TIMEOUT_MS);
    const signal = combineSignals([req.signal, timeout]);

    let res: Response;
    try {
      res = await fetch(this.endpoint, {
        method: 'POST',
        headers: buildHeaders(apiKey),
        body: JSON.stringify({
          model: req.model,
          messages: req.messages,
          max_tokens: req.maxTokens ?? DEFAULT_MAX_TOKENS,
          temperature: req.temperature ?? DEFAULT_TEMPERATURE,
        }),
        signal,
      });
    } catch (err) {
      throw translateNetworkError(err, signal, timeout);
    }

    if (!res.ok) {
      const detail = await safeText(res);
      logger.warn('openrouter http error', { status: res.status, model: req.model, detail: detail.slice(0, 200) });
      throw classifyStatus(res.status);
    }

    let payload: unknown;
    try {
      payload = await res.json();
    } catch {
      throw new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI provider returned a malformed response. You were not charged.');
    }

    const content = extractContent(payload);
    const finishReason = extractFinishReason(payload);
    const model = extractModel(payload) ?? req.model;

    return { content, model, finishReason, durationMs: Date.now() - started };
  }

  /**
   * Streaming completion. `onChunk` is invoked per content delta.
   *
   * Retries are only attempted while nothing has been emitted yet — once the
   * client has seen tokens, a retry would duplicate output.
   */
  stream(req: CompletionRequest, onChunk: (chunk: StreamChunk) => void): StreamHandle {
    assertConfigured();
    assertModelAllowed(req.model);

    const controller = new AbortController();
    const started = Date.now();
    let emitted = false;
    let aborted = false;

    const forwardAbort = () => {
      aborted = true;
      controller.abort();
    };
    if (req.signal) {
      if (req.signal.aborted) forwardAbort();
      else req.signal.addEventListener('abort', forwardAbort, { once: true });
    }

    const done = (async () => {
      const maxAttempts = env.OPENROUTER_MAX_RETRIES + 1;
      let lastError: unknown;
      let usedKey: string | undefined;

      for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
        if (aborted) throw new AppError(ERROR_CODES.ABORTED);

        const apiKey = this.pool.acquire(usedKey);
        usedKey = apiKey ?? undefined;
        if (!apiKey) {
          lastError = new AppError(
            ERROR_CODES.AI_PROVIDER_RATE_LIMITED,
            'The AI provider is rate limited on every configured key. You were not charged.',
          );
          break;
        }

        try {
          const result = await this.attemptStream(
            req,
            controller,
            onChunk,
            () => {
              emitted = true;
            },
            started,
            apiKey,
          );
          this.pool.reportSuccess(apiKey);
          return result;
        } catch (err) {
          lastError = err;
          this.pool.reportFailure(apiKey, providerStatusOf(err), codeOf(err));

          if (aborted || req.signal?.aborted) {
            throw new AppError(ERROR_CODES.ABORTED);
          }

          const status = providerStatusOf(err);
          if (status !== null && isQuotaStatus(status)) {
            logger.warn('openrouter rotating key after quota error (stream)', {
              attempt,
              code: codeOf(err),
              available: this.pool.availableCount(),
            });
            if (attempt === maxAttempts || this.pool.availableCount() === 0) break;
            continue;
          }

          if (emitted || attempt === maxAttempts || !isRetryable(err)) break;
          const backoff = Math.min(4000, 400 * 2 ** (attempt - 1));
          logger.warn('openrouter stream retry', { attempt, delayMs: backoff, code: codeOf(err) });
          await sleep(backoff);
        }
      }
      throw toAppError(lastError);
    })();

    return {
      done,
      abort: (reason?: string) => {
        if (reason) logger.debug('openrouter stream aborted', { reason });
        forwardAbort();
      },
      get aborted() {
        return aborted;
      },
    };
  }

  private async attemptStream(
    req: CompletionRequest,
    controller: AbortController,
    onChunk: (chunk: StreamChunk) => void,
    markEmitted: () => void,
    started: number,
    apiKey: string,
  ): Promise<{ model: string; finishReason: string | null; durationMs: number }> {
    const timeout = AbortSignal.timeout(env.OPENROUTER_STREAM_TIMEOUT_MS);
    const signal = combineSignals([controller.signal, timeout]);

    let res: Response;
    try {
      res = await fetch(this.endpoint, {
        method: 'POST',
        headers: { ...buildHeaders(apiKey), Accept: 'text/event-stream' },
        body: JSON.stringify({
          model: req.model,
          messages: req.messages,
          max_tokens: req.maxTokens ?? DEFAULT_MAX_TOKENS,
          temperature: req.temperature ?? DEFAULT_TEMPERATURE,
          stream: true,
        }),
        signal,
      });
    } catch (err) {
      throw translateNetworkError(err, signal, timeout);
    }

    if (!res.ok) {
      await safeText(res);
      throw classifyStatus(res.status);
    }
    if (!res.body) {
      throw new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI provider returned an empty stream. You were not charged.');
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let model = req.model;
    let finishReason: string | null = null;
    let sawAnyEvent = false;
    let sawContent = false;
    // Reasoning is buffered, not streamed: models that emit a visible
    // scratchpad before their answer would otherwise show it to the user.
    let reasoningBuffer = '';

    try {
      for (;;) {
        const { done: finished, value } = await reader.read();
        if (finished) break;
        buffer += decoder.decode(value, { stream: true });

        // SSE frames are separated by a blank line.
        let sep = buffer.indexOf('\n\n');
        while (sep !== -1) {
          const frame = buffer.slice(0, sep);
          buffer = buffer.slice(sep + 2);
          const handled = handleFrame(
            frame,
            (text) => {
              sawContent = true;
              markEmitted();
              onChunk({ text });
            },
            (text) => {
              reasoningBuffer += text;
            },
            (m, f) => {
              model = m;
              finishReason = f;
            },
          );
          if (handled === 'done') {
            if (!sawContent) emitReasoning();
            if (!sawContent) throw emptyCompletion();
            return { model, finishReason, durationMs: Date.now() - started };
          }
          if (handled) sawAnyEvent = true;
          sep = buffer.indexOf('\n\n');
        }
      }

      // Some providers end the response without a trailing blank line, so the
      // final frame can still be sitting in the buffer at EOF.
      if (buffer.trim().length > 0) {
        const handled = handleFrame(
          buffer,
          (text) => {
            sawContent = true;
            markEmitted();
            onChunk({ text });
          },
          (text) => {
            reasoningBuffer += text;
          },
          (m, f) => {
            model = m;
            finishReason = f;
          },
        );
        buffer = '';
        if (handled === 'done') {
          if (!sawContent) emitReasoning();
          if (!sawContent) throw emptyCompletion();
          return { model, finishReason, durationMs: Date.now() - started };
        }
        if (handled) sawAnyEvent = true;
      }
    } catch (err) {
      if (controller.signal.aborted || req.signal?.aborted) {
        throw new AppError(ERROR_CODES.ABORTED);
      }
      if (signal.aborted) throw new AppError(ERROR_CODES.AI_PROVIDER_TIMEOUT);
      if (err instanceof AppError) throw err;
      throw translateNetworkError(err, signal, timeout);
    } finally {
      reader.cancel().catch(() => undefined);
    }

    if (!sawAnyEvent) {
      throw new AppError(
        ERROR_CODES.AI_PROVIDER_ERROR,
        'The AI provider returned a malformed stream. You were not charged.',
      );
    }
    if (!sawContent) emitReasoning();
    if (!sawContent) throw emptyCompletion();

    return { model, finishReason, durationMs: Date.now() - started };

    /** Last resort: a model answered only with reasoning. */
    function emitReasoning(): void {
      if (reasoningBuffer.trim().length === 0) return;
      sawContent = true;
      markEmitted();
      onChunk({ text: reasoningBuffer });
    }
  }

  /**
   * Liveness probe used by GET /api/health/openrouter.
   * Reports how many keys are usable, never a key itself.
   */
  async health(): Promise<{
    configured: boolean;
    model: string;
    status: 'ok' | 'degraded' | 'unconfigured';
    keysTotal: number;
    keysAvailable: number;
  }> {
    if (!isConfigured()) {
      return {
        configured: false,
        model: env.OPENROUTER_MODEL,
        status: 'unconfigured',
        keysTotal: 0,
        keysAvailable: 0,
      };
    }
    const available = this.pool.availableCount();
    return {
      configured: true,
      model: env.OPENROUTER_MODEL,
      status: available === 0 ? 'degraded' : 'ok',
      keysTotal: this.pool.size,
      keysAvailable: available,
    };
  }
}

function emptyCompletion(): AppError {
  return new AppError(
    ERROR_CODES.AI_PROVIDER_ERROR,
    'The AI provider returned an empty answer. You were not charged.',
  );
}

function handleFrame(
  frame: string,
  emit: (text: string) => void,
  collectReasoning: (text: string) => void,
  setMeta: (model: string, finishReason: string | null) => void,
): boolean | 'done' {
  const lines = frame.split('\n');
  let sawData = false;

  for (const line of lines) {
    if (!line.startsWith('data:')) continue;
    const payload = line.slice(5).trim();
    if (!payload) continue;
    if (payload === '[DONE]') return 'done';

    let parsed: unknown;
    try {
      parsed = JSON.parse(payload);
    } catch {
      // A single malformed frame must not kill a healthy stream.
      continue;
    }

    if (!parsed || typeof parsed !== 'object') continue;

    // Only a frame we actually understood counts as a live event; a stream of
    // unparseable frames is malformed and must fail loudly.
    sawData = true;
    const obj = parsed as Record<string, unknown>;

    if (typeof obj.model === 'string') setMeta(obj.model, null);
    if (typeof obj.finish_reason === 'string') setMeta(String(obj.model ?? ''), obj.finish_reason);

    if (obj.error && typeof obj.error === 'object') {
      const code = (obj.error as Record<string, unknown>).code;
      throw new AppError(
        ERROR_CODES.AI_PROVIDER_ERROR,
        `The AI provider reported an error${typeof code === 'string' ? ` (${code})` : ''}. You were not charged.`,
      );
    }

    const choices = obj.choices;
    if (!Array.isArray(choices) || choices.length === 0) continue;
    const delta = (choices[0] as Record<string, unknown>).delta as
      | Record<string, unknown>
      | undefined;

    const text = delta?.content;
    if (typeof text === 'string' && text.length > 0) {
      emit(text);
      continue;
    }

    // Some reasoning models stream their thinking in a separate field. Buffer
    // it: it is only used if the turn produces no answer at all.
    const reasoning = delta?.reasoning ?? delta?.reasoning_content;
    if (typeof reasoning === 'string' && reasoning.length > 0) collectReasoning(reasoning);
  }

  return sawData;
}

function combineSignals(signals: (AbortSignal | undefined)[]): AbortSignal {
  const list = signals.filter((s): s is AbortSignal => Boolean(s));
  if (list.length === 0) return new AbortController().signal;
  if (list.length === 1) return list[0]!;
  return AbortSignal.any(list);
}

function translateNetworkError(
  err: unknown,
  signal: AbortSignal,
  timeoutSignal: AbortSignal,
): AppError {
  if (signal.aborted) {
    if (timeoutSignal.aborted) {
      return new AppError(ERROR_CODES.AI_PROVIDER_TIMEOUT);
    }
    return new AppError(ERROR_CODES.ABORTED);
  }
  const message = err instanceof Error ? err.message : String(err);
  logger.warn('openrouter network error', { message: message.slice(0, 200) });
  return new AppError(
    ERROR_CODES.AI_PROVIDER_ERROR,
    'Could not reach the AI provider. You were not charged.',
  );
}

function codeOf(err: unknown): string {
  return err instanceof AppError ? err.code : 'UNKNOWN';
}

function toAppError(err: unknown): AppError {
  if (err instanceof AppError) return err;
  return new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI request failed. You were not charged.');
}

async function safeText(res: Response): Promise<string> {
  try {
    const text = await res.text();
    return text.slice(0, 500);
  } catch {
    return '';
  }
}

function extractContent(payload: unknown): string {
  if (!payload || typeof payload !== 'object') {
    throw new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI provider returned a malformed response. You were not charged.');
  }
  const choices = (payload as Record<string, unknown>).choices;
  if (!Array.isArray(choices) || choices.length === 0) {
    throw new AppError(ERROR_CODES.AI_PROVIDER_ERROR, 'The AI provider returned no choices. You were not charged.');
  }
  const message = (choices[0] as Record<string, unknown>).message as
    | Record<string, unknown>
    | undefined;
  const content = message?.content;
  if (typeof content === 'string' && content.length > 0) return content;

  // Some reasoning models return null content with a separate reasoning field.
  const reasoning = message?.reasoning;
  if (typeof reasoning === 'string' && reasoning.length > 0) return reasoning;

  throw new AppError(
    ERROR_CODES.AI_PROVIDER_ERROR,
    'The AI provider returned an empty answer. You were not charged.',
  );
}

function extractFinishReason(payload: unknown): string | null {
  if (!payload || typeof payload !== 'object') return null;
  const choices = (payload as Record<string, unknown>).choices;
  if (!Array.isArray(choices) || choices.length === 0) return null;
  const reason = (choices[0] as Record<string, unknown>).finish_reason;
  return typeof reason === 'string' ? reason : null;
}

function extractModel(payload: unknown): string | null {
  if (!payload || typeof payload !== 'object') return null;
  const model = (payload as Record<string, unknown>).model;
  return typeof model === 'string' ? model : null;
}

export const openRouterService = new OpenRouterService();
export const isModelAllowed = assertModelAllowed;
export { DEFAULT_MAX_TOKENS };
