import type { MediaKind } from '@prisma/client';
import { ERROR_CODES, type MediaKind as MediaKindDTO } from '@orbit/shared';
import { fileTypeFromBuffer } from 'file-type';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { prisma } from '../lib/prisma.js';
import { storageService } from './storage.service.js';

interface AllowedType {
  mime: string;
  ext: string;
  kind: MediaKindDTO;
}

/**
 * Allow-list approach: a file must match BOTH its declared MIME type and its
 * sniffed magic bytes, and its extension must agree. Anything else is refused,
 * which blocks renamed executables and HTML/SVG payloads.
 */
const IMAGE_TYPES: AllowedType[] = [
  { mime: 'image/png', ext: 'png', kind: 'IMAGE' },
  { mime: 'image/jpeg', ext: 'jpg', kind: 'IMAGE' },
  { mime: 'image/webp', ext: 'webp', kind: 'IMAGE' },
];

const GIF_TYPE: AllowedType = { mime: 'image/gif', ext: 'gif', kind: 'GIF' };

const VIDEO_TYPES: AllowedType[] = [
  { mime: 'video/mp4', ext: 'mp4', kind: 'VIDEO' },
  { mime: 'video/webm', ext: 'webm', kind: 'VIDEO' },
];

const AUDIO_TYPES: AllowedType[] = [
  { mime: 'audio/mpeg', ext: 'mp3', kind: 'AUDIO' },
];

const ICON_TYPES: AllowedType[] = [
  { mime: 'image/x-icon', ext: 'ico', kind: 'ICON' },
  { mime: 'image/vnd.microsoft.icon', ext: 'ico', kind: 'ICON' },
];

const CATEGORY_RULES: Array<{ label: string; types: AllowedType[]; maxBytes: number }> = [
  { label: 'image', types: [...IMAGE_TYPES, GIF_TYPE, ...ICON_TYPES], maxBytes: env.MAX_IMAGE_UPLOAD_BYTES },
  { label: 'video', types: VIDEO_TYPES, maxBytes: env.MAX_VIDEO_UPLOAD_BYTES },
  { label: 'audio', types: AUDIO_TYPES, maxBytes: env.MAX_AUDIO_UPLOAD_BYTES },
];

export interface UploadedFile {
  buffer: Buffer;
  originalName: string;
  declaredMime: string;
}

function normalizeDeclaredMime(mime: string): string {
  // Browsers are inconsistent about these two.
  if (mime === 'image/jpg' || mime === 'image/pjpeg') return 'image/jpeg';
  if (mime === 'audio/mp3' || mime === 'audio/x-mpeg' || mime === 'audio/mpeg3') return 'audio/mpeg';
  return mime.toLowerCase().split(';')[0]!.trim();
}

async function resolveType(file: UploadedFile, category: string): Promise<AllowedType> {
  const rule = CATEGORY_RULES.find((r) => r.label === category);
  if (!rule) throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Unknown upload category.');

  if (file.buffer.byteLength === 0) {
    throw new AppError(ERROR_CODES.UPLOAD_REJECTED, 'The file is empty.');
  }
  if (file.buffer.byteLength > rule.maxBytes) {
    throw new AppError(
      ERROR_CODES.PAYLOAD_TOO_LARGE,
      `That ${rule.label} is too large. The limit is ${Math.floor(rule.maxBytes / (1024 * 1024))} MB.`,
    );
  }

  const declared = normalizeDeclaredMime(file.declaredMime);
  const sniffed = await fileTypeFromBuffer(file.buffer);
  const sniffedMime = sniffed?.mime ?? 'application/octet-stream';
  const ext = path.extname(file.originalName).replace('.', '').toLowerCase();

  const allowed = rule.types;
  const byDeclared = allowed.find((t) => t.mime === declared);
  const bySniffed = allowed.find((t) => t.mime === sniffedMime);

  if (!bySniffed) {
    throw new AppError(
      ERROR_CODES.UPLOAD_REJECTED,
      `That file is not a supported ${rule.label}. Allowed: ${allowed.map((t) => t.ext).join(', ')}.`,
    );
  }
  if (!byDeclared) {
    throw new AppError(
      ERROR_CODES.UPLOAD_REJECTED,
      'The file content does not match its declared type.',
    );
  }
  if (byDeclared.mime !== bySniffed.mime) {
    throw new AppError(
      ERROR_CODES.UPLOAD_REJECTED,
      'The file extension and its actual contents do not match.',
    );
  }
  if (ext !== bySniffed.ext && !(ext === 'jpeg' && bySniffed.ext === 'jpg')) {
    throw new AppError(ERROR_CODES.UPLOAD_REJECTED, `Expected a .${bySniffed.ext} file.`);
  }

  return bySniffed;
}

function buildKey(kind: MediaKindDTO, ext: string): string {
  const now = new Date();
  const folder = `${now.getUTCFullYear()}/${String(now.getUTCMonth() + 1).padStart(2, '0')}`;
  return `${kind.toLowerCase()}/${folder}/${randomBytes(16).toString('hex')}.${ext}`;
}

class MediaService {
  async upload(
    file: UploadedFile,
    category: 'image' | 'video' | 'audio',
    altText = '',
  ): Promise<{ id: string; url: string; kind: MediaKind; mimeType: string; size: number }> {
    const type = await resolveType(file, category);
    const key = buildKey(type.kind, type.ext);

    // Binary never touches the database — only the object key and metadata.
    const stored = await storageService.put(key, file.buffer, type.mime);

    try {
      const record = await prisma.media.create({
        data: {
          kind: type.kind as MediaKind,
          mimeType: type.mime,
          url: stored.url,
          storageKey: stored.key,
          filename: sanitizeFilename(file.originalName),
          size: stored.size,
          altText: altText.slice(0, 240),
        },
        select: { id: true, url: true, kind: true, mimeType: true, size: true },
      });
      return record;
    } catch (err) {
      // Don't leave an orphaned object behind if the DB write fails.
      await storageService.delete(key).catch(() => undefined);
      throw err;
    }
  }

  async list(kind?: MediaKindDTO) {
    return prisma.media.findMany({
      where: kind ? { kind: kind as MediaKind } : undefined,
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }

  async get(id: string) {
    return prisma.media.findUnique({ where: { id } });
  }

  async remove(id: string): Promise<{ storageKey: string }> {
    const record = await prisma.media.findUnique({ where: { id } });
    if (!record) throw new AppError(ERROR_CODES.NOT_FOUND, 'Media not found.');

    await prisma.media.delete({ where: { id } });
    // Settings referencing it fall back to the static colour automatically.
    await storageService.delete(record.storageKey).catch(() => undefined);
    return { storageKey: record.storageKey };
  }
}

function sanitizeFilename(name: string): string {
  return path
    .basename(name)
    .replace(/[^A-Za-z0-9._-]/g, '_')
    .slice(0, 120) || 'upload';
}

export const mediaService = new MediaService();
