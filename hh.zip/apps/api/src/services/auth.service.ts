import type { Request, Response } from 'express';
import { ERROR_CODES } from '@orbit/shared';
import { env } from '../config/env.js';
import {
  AUTH_COOKIE_NAMES,
  cookieOptions,
  csrfCookieOptions,
  deriveCsrfToken,
  generateCsrfSecret,
  generateSessionToken,
  resetExpiry,
  sessionExpiry,
  sha256,
} from '../lib/crypto.js';
import { AppError } from '../lib/errors.js';
import { prisma } from '../lib/prisma.js';

export interface AuthContext {
  sessionId: string;
  userId: string;
  tokenHash: string;
  role: 'USER' | 'ADMIN';
  status: 'ACTIVE' | 'SUSPENDED' | 'BANNED';
  email: string;
  username: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthContext;
    }
  }
}

export async function createSession(
  res: Response,
  userId: string,
  meta: { userAgent: string; ip: string },
): Promise<{ sessionId: string; csrfToken: string }> {
  const token = generateSessionToken();
  const tokenHash = sha256(token);

  const session = await prisma.session.create({
    data: {
      userId,
      tokenHash,
      csrfSecret: generateCsrfSecret(),
      userAgent: meta.userAgent.slice(0, 300),
      ip: meta.ip.slice(0, 64),
      expiresAt: sessionExpiry(),
    },
    select: { id: true },
  });

  res.cookie(AUTH_COOKIE_NAMES.session, token, {
    ...cookieOptions,
    expires: sessionExpiry(),
  });
  const csrfToken = deriveCsrfToken(tokenHash);
  res.cookie(AUTH_COOKIE_NAMES.csrf, csrfToken, {
    ...csrfCookieOptions,
    expires: sessionExpiry(),
  });

  await prisma.user.update({ where: { id: userId }, data: { lastLoginAt: new Date() } });

  return { sessionId: session.id, csrfToken };
}

export async function resolveSession(token: string | undefined): Promise<AuthContext | null> {
  if (!token) return null;
  const tokenHash = sha256(token);

  const session = await prisma.session.findUnique({
    where: { tokenHash },
    include: { user: true },
  });
  if (!session) return null;

  if (session.expiresAt.getTime() <= Date.now()) {
    await prisma.session.delete({ where: { id: session.id } }).catch(() => undefined);
    return null;
  }

  if (session.user.status === 'BANNED') return null;

  // Throttled write: at most one touch per 5 minutes per session.
  if (Date.now() - session.lastUsedAt.getTime() > 5 * 60 * 1000) {
    await prisma.session
      .update({ where: { id: session.id }, data: { lastUsedAt: new Date() } })
      .catch(() => undefined);
  }

  return {
    sessionId: session.id,
    userId: session.userId,
    tokenHash,
    role: session.user.role,
    status: session.user.status,
    email: session.user.email,
    username: session.user.username,
  };
}

export function readSessionToken(req: Request): string | undefined {
  const fromCookie = (req.cookies as Record<string, string> | undefined)?.[
    AUTH_COOKIE_NAMES.session
  ];
  if (fromCookie) return fromCookie;
  const header = req.get('authorization');
  if (header?.toLowerCase().startsWith('bearer ')) return header.slice(7).trim();
  return undefined;
}

export function expectedCsrfToken(tokenHash: string): string {
  return deriveCsrfToken(tokenHash);
}

export async function destroySession(req: Request, res: Response): Promise<void> {
  const token = readSessionToken(req);
  if (token) {
    await prisma.session.deleteMany({ where: { tokenHash: sha256(token) } });
  }
  clearAuthCookies(res);
}

export async function destroyAllSessions(userId: string): Promise<void> {
  await prisma.session.deleteMany({ where: { userId } });
}

export function clearAuthCookies(res: Response): void {
  res.clearCookie(AUTH_COOKIE_NAMES.session, { ...cookieOptions });
  res.clearCookie(AUTH_COOKIE_NAMES.csrf, { ...csrfCookieOptions });
}

export function assertAccountUsable(status: 'ACTIVE' | 'SUSPENDED' | 'BANNED'): void {
  if (status === 'SUSPENDED') {
    throw new AppError(
      ERROR_CODES.ACCOUNT_SUSPENDED,
      'This account is suspended. Contact an administrator.',
    );
  }
  if (status === 'BANNED') {
    throw new AppError(ERROR_CODES.ACCOUNT_BANNED, 'This account has been banned.');
  }
}

export async function createPasswordResetToken(userId: string): Promise<string> {
  const token = generateSessionToken();
  // One live reset token per user keeps the table small and unambiguous.
  await prisma.passwordReset.deleteMany({ where: { userId, usedAt: null } });
  await prisma.passwordReset.create({
    data: { userId, tokenHash: sha256(token), expiresAt: resetExpiry() },
  });
  return token;
}

export async function consumePasswordResetToken(token: string): Promise<string> {
  const record = await prisma.passwordReset.findUnique({
    where: { tokenHash: sha256(token) },
  });
  if (!record || record.usedAt || record.expiresAt.getTime() <= Date.now()) {
    throw new AppError(ERROR_CODES.INVALID_TOKEN);
  }
  await prisma.passwordReset.update({
    where: { id: record.id },
    data: { usedAt: new Date() },
  });
  return record.userId;
}

export async function purgeExpired(): Promise<void> {
  const now = new Date();
  await Promise.all([
    prisma.session.deleteMany({ where: { expiresAt: { lte: now } } }),
    prisma.passwordReset.deleteMany({ where: { expiresAt: { lte: now } } }),
  ]);
}

export const sessionTtlMs = env.SESSION_TTL_DAYS * 24 * 60 * 60 * 1000;
