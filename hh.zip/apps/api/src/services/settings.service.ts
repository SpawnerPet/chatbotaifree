import type { SiteSettings } from '@prisma/client';
import {
  DEFAULT_CHAT_WELCOME,
  DEFAULT_LANDING_DESCRIPTION,
  DEFAULT_LANDING_TITLE,
  DEFAULT_SITE_NAME,
  DEFAULT_SITE_TAGLINE,
  type PublicMedia,
  type PublicSettings,
} from '@orbit/shared';
import { AppError } from '../lib/errors.js';
import { prisma } from '../lib/prisma.js';

const SETTINGS_ID = 'default';

export const DEFAULT_CHAT_PROMPTS = [
  'Explain a hard concept with a concrete analogy.',
  'Review this code and point out what would break first.',
  'Help me turn a rough idea into a plan I can actually follow.',
];

export const DEFAULT_CHAT_WELCOME_TEXT = DEFAULT_CHAT_WELCOME;
const DEFAULT_LANDING_TITLE_TEXT = DEFAULT_LANDING_TITLE;
export const DEFAULT_LANDING_DESCRIPTION_TEXT = DEFAULT_LANDING_DESCRIPTION;
const DEFAULT_SITE_TAGLINE_TEXT = DEFAULT_SITE_TAGLINE;
const DEFAULT_SITE_NAME_TEXT = DEFAULT_SITE_NAME;

/** Reads the singleton row, creating it with shipped defaults on first use. */
export async function getSettingsRow(): Promise<SiteSettings> {
  const existing = await prisma.siteSettings.findUnique({ where: { id: SETTINGS_ID } });
  if (existing) return existing;
  return prisma.siteSettings.create({
    data: {
      id: SETTINGS_ID,
      siteName: DEFAULT_SITE_NAME_TEXT,
      siteTagline: DEFAULT_SITE_TAGLINE_TEXT,
      landingTitle: DEFAULT_LANDING_TITLE_TEXT,
      landingDescription: DEFAULT_LANDING_DESCRIPTION_TEXT,
      chatWelcomeMessage: DEFAULT_CHAT_WELCOME_TEXT,
      chatEmptyPrompts: DEFAULT_CHAT_PROMPTS,
    },
  });
}

function toStringArray(value: unknown): string[] {
  if (Array.isArray(value)) {
    return value.filter((v): v is string => typeof v === 'string').slice(0, 6);
  }
  return [];
}

export function toPublicSettings(row: SiteSettings, media: { url: string } | null): PublicSettings {
  return {
    siteName: row.siteName,
    siteTagline: row.siteTagline,
    logoUrl: row.logoUrl,
    faviconUrl: row.faviconUrl,

    loginTitle: row.loginTitle,
    loginSubtitle: row.loginSubtitle,

    landingTitle: row.landingTitle,
    landingDescription: row.landingDescription,
    primaryCtaText: row.primaryCtaText,
    secondaryCtaText: row.secondaryCtaText,
    footerText: row.footerText,

    chatWelcomeMessage: row.chatWelcomeMessage,
    chatEmptyPrompts: toStringArray(row.chatEmptyPrompts),

    accentColor: row.accentColor,
    backgroundColor: row.backgroundColor,
    textColor: row.textColor,
    borderColor: row.borderColor,
    buttonStyle: row.buttonStyle as PublicSettings['buttonStyle'],
    fontChoice: row.fontChoice as PublicSettings['fontChoice'],
    defaultTheme: row.defaultTheme as PublicSettings['defaultTheme'],

    backgroundType: row.backgroundType,
    backgroundMediaId: row.backgroundMediaId,
    backgroundUrl: media?.url ?? null,
    backgroundPosterUrl: media?.url ?? null,
    backgroundOverlayOpacity: row.backgroundOverlayOpacity,
    backgroundParallax: row.backgroundParallax,

    musicEnabled: row.musicEnabled,
    musicUrl: row.musicUrl,
    musicVolume: row.musicVolume,
    musicAutoplay: row.musicAutoplay,

    supportEmail: row.supportEmail,
    customCss: row.customCss,

    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function getPublicSettings(): Promise<PublicSettings> {
  const row = await getSettingsRow();
  const media = row.backgroundMediaId
    ? await prisma.media.findUnique({
        where: { id: row.backgroundMediaId },
        select: { url: true },
      })
    : null;
  return toPublicSettings(row, media);
}

export async function updateSettings(
  input: Record<string, unknown>,
): Promise<{ row: SiteSettings; changed: string[] }> {
  await getSettingsRow();

  const data: Record<string, unknown> = {};
  const changed: string[] = [];

  for (const [key, value] of Object.entries(input)) {
    if (value === undefined) continue;
    data[key] = value;
    changed.push(key);
  }

  if (changed.length === 0) {
    throw new AppError('VALIDATION_ERROR', 'Nothing to update.');
  }

  if (data.backgroundMediaId !== undefined && data.backgroundMediaId !== null) {
    const id = String(data.backgroundMediaId);
    const media = await prisma.media.findUnique({ where: { id }, select: { kind: true } });
    if (!media) throw new AppError('NOT_FOUND', 'That media item does not exist.');
    if (media.kind !== 'IMAGE' && media.kind !== 'GIF' && media.kind !== 'VIDEO') {
      throw new AppError('VALIDATION_ERROR', 'Background media must be an image, GIF or video.');
    }
    const type = media.kind === 'GIF' ? 'GIF' : media.kind === 'VIDEO' ? 'VIDEO' : 'IMAGE';
    data.backgroundType = type;
  }

  if (data.backgroundType !== undefined && data.backgroundType !== 'STATIC_COLOR') {
    if (data.backgroundType === 'GIF') data.backgroundMediaId = null;
  }

  const row = (await prisma.siteSettings.update({
    where: { id: SETTINGS_ID },
    data: data as never,
  })) as SiteSettings;

  return { row, changed };
}

export function toPublicMedia(row: {
  id: string;
  kind: MediaKindDTOAlias;
  mimeType: string;
  url: string;
  filename: string;
  size: number;
  width: number | null;
  height: number | null;
  altText: string;
  createdAt: Date;
}): PublicMedia {
  return {
    id: row.id,
    kind: row.kind,
    mimeType: row.mimeType,
    url: row.url,
    filename: row.filename,
    size: row.size,
    width: row.width,
    height: row.height,
    altText: row.altText,
    createdAt: row.createdAt.toISOString(),
  };
}

type MediaKindDTOAlias = PublicMedia['kind'];
