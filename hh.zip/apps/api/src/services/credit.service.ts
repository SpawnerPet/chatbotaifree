import { Prisma, type CreditTransactionType } from '@prisma/client';
import { ERROR_CODES } from '@orbit/shared';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { prisma } from '../lib/prisma.js';

export interface LedgerEntry {
  amount: number;
  type: CreditTransactionType;
  description: string;
  createdById?: string | null;
}

/**
 * Internal credit ledger.
 *
 * Every balance change goes through `applyDelta`, which performs a single
 * conditional UPDATE inside a transaction. The `WHERE credits >= cost` guard
 * makes the check-and-decrement atomic at the database level, so concurrent
 * requests can never drive a balance below zero or oversell credits.
 */
class CreditService {
  async getBalance(userId: string): Promise<number> {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { credits: true },
    });
    if (!user) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');
    return user.credits;
  }

  /**
   * Atomically apply a delta. Throws INSUFFICIENT_CREDITS if the resulting
   * balance would go below zero. Always writes a ledger row.
   */
  async applyDelta(
    userId: string,
    entry: LedgerEntry,
    options: { allowNegative?: boolean; allowInsufficient?: boolean } = {},
  ): Promise<{ balanceBefore: number; balanceAfter: number; transactionId: string }> {
    const amount = Math.trunc(entry.amount);
    if (!Number.isFinite(amount) || amount === 0) {
      throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'Credit amount must be a non-zero integer.');
    }

    return prisma.$transaction(async (tx) => {
      const result = await tx.$queryRaw<Array<{ credits: number }>>`
        UPDATE "users"
           SET "credits" = "credits" + ${amount}, "updatedAt" = NOW()
         WHERE "id" = ${userId}
           ${options.allowInsufficient || amount > 0
             ? Prisma.sql``
             : Prisma.sql`AND "credits" + ${amount} >= 0`}
        RETURNING "credits"
      `;

      const row = result[0];
      if (!row) {
        // Distinguish "no such user" from "not enough credits".
        const exists = await tx.user.findUnique({
          where: { id: userId },
          select: { id: true },
        });
        if (!exists) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');
        throw new AppError(
          ERROR_CODES.INSUFFICIENT_CREDITS,
          'Insufficient credits. Ask an administrator for more.',
        );
      }

      const balanceAfter = row.credits;
      const balanceBefore = balanceAfter - amount;

      const created = await tx.creditTransaction.create({
        data: {
          userId,
          amount,
          type: entry.type,
          balanceBefore,
          balanceAfter,
          description: entry.description,
          createdById: entry.createdById ?? null,
        },
        select: { id: true },
      });

      return { balanceBefore, balanceAfter, transactionId: created.id };
    });
  }

  /** Pre-flight check so we never call the AI provider with an empty balance. */
  async assertCanAfford(userId: string, cost: number): Promise<number> {
    const balance = await this.getBalance(userId);
    if (balance < cost) {
      throw new AppError(
        ERROR_CODES.INSUFFICIENT_CREDITS,
        'Insufficient credits. Ask an administrator for more.',
      );
    }
    return balance;
  }

  /** Charge for one AI request. Returns the new balance. */
  async chargeChat(userId: string, description: string): Promise<number> {
    const cost = env.CHAT_COST_CREDITS;
    if (cost <= 0) {
      // Free deployment mode: no charge, but still record the usage event.
      return this.getBalance(userId);
    }
    const { balanceAfter } = await this.applyDelta(userId, {
      amount: -cost,
      type: 'CHAT_USAGE',
      description,
    });
    return balanceAfter;
  }

  /**
   * Give the credit back when the provider call produced nothing usable.
   * Idempotent per requestId — a second refund is a no-op.
   */
  async refundChat(userId: string, requestId: string, description: string): Promise<number> {
    const cost = env.CHAT_COST_CREDITS;
    if (cost <= 0) return this.getBalance(userId);

    return prisma.$transaction(async (tx) => {
      const already = await tx.aiRequest.findUnique({
        where: { id: requestId },
        select: { refundedCredits: true },
      });
      if (already && already.refundedCredits > 0) {
        const user = await tx.user.findUnique({
          where: { id: userId },
          select: { credits: true },
        });
        return user?.credits ?? 0;
      }

      const result = await tx.$queryRaw<Array<{ credits: number }>>`
        UPDATE "users" SET "credits" = "credits" + ${cost}, "updatedAt" = NOW()
        WHERE "id" = ${userId}
        RETURNING "credits"
      `;
      const balanceAfter = result[0]?.credits ?? 0;

      await tx.creditTransaction.create({
        data: {
          userId,
          amount: cost,
          type: 'REFUND',
          balanceBefore: balanceAfter - cost,
          balanceAfter,
          description,
        },
      });

      await tx.aiRequest.update({
        where: { id: requestId },
        data: { refundedCredits: cost },
      });

      return balanceAfter;
    });
  }

  async grantSignupBonus(userId: string, amount: number): Promise<number> {
    if (amount <= 0) return this.getBalance(userId);
    const { balanceAfter } = await this.applyDelta(userId, {
      amount,
      type: 'SIGNUP_BONUS',
      description: 'Welcome bonus',
    });
    return balanceAfter;
  }

  async history(userId: string, page: number, pageSize: number) {
    const [items, total] = await Promise.all([
      prisma.creditTransaction.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { createdBy: { select: { username: true } } },
      }),
      prisma.creditTransaction.count({ where: { userId } }),
    ]);
    return { items, total };
  }
}

export const creditService = new CreditService();
