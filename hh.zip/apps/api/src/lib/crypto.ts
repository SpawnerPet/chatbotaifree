import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { env } from '../config/env.js';

const SESSION_COOKIE = 'orbit.sid';
const CSRF_COOKIE = 'orbit.csrf';

export const AUTH_COOKIE_NAMES = { session: SESSION_COOKIE, csrf: CSRF_COOKIE } as const;

export function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

/** Opaque, high-entropy session token. Only its hash is persisted. */
export function generateSessionToken(): string {
  return randomBytes(32).toString('base64url');
}

export function generateCsrfSecret(): string {
  return randomBytes(24).toString('base64url');
}

/**
 * The CSRF token handed to the browser is derived (HMAC) from the session's
 * stored secret, so a stolen cookie value alone is not enough and the token
 * can be re-derived to verify without extra storage.
 */
export function deriveCsrfToken(sessionTokenHash: string): string {
  return createHash('sha256')
    .update(`${sessionTokenHash}.${env.CSRF_SECRET}`)
    .digest('base64url')
    .slice(0, 43);
}

export function safeEqual(a: string, b: string): boolean {
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return timingSafeEqual(bufA, bufB);
}

export function sessionExpiry(from: Date = new Date()): Date {
  return new Date(from.getTime() + env.SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);
}

export function resetExpiry(from: Date = new Date()): Date {
  return new Date(from.getTime() + env.PASSWORD_RESET_TTL_MINUTES * 60 * 1000);
}

export function newId(): string {
  return randomUUID();
}

export const cookieOptions = {
  httpOnly: true as const,
  secure: env.isProd,
  sameSite: 'lax' as const,
  path: '/',
};

/** Readable by JS on purpose — the SPA echoes it back in the X-CSRF-Token header. */
export const csrfCookieOptions = {
  httpOnly: false as const,
  secure: env.isProd,
  sameSite: 'lax' as const,
  path: '/',
};
