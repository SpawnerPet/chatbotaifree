import { PrismaClient } from '@prisma/client';
import { env } from '../config/env.js';

declare global {
   
  var __orbitPrisma: PrismaClient | undefined;
}


export const prisma =
  globalThis.__orbitPrisma ??
  new PrismaClient({
    log: env.LOG_LEVEL === 'debug' ? ['warn', 'error', 'query'] : ['warn', 'error'],
  });

if (!env.isProd) {
  globalThis.__orbitPrisma = prisma;
}

export type Tx = Parameters<Parameters<PrismaClient['$transaction']>[0]>[0];

export async function disconnectPrisma(): Promise<void> {
  await prisma.$disconnect();
}
