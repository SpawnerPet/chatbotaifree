import type {
  AuditLog,
  Conversation,
  CreditTransaction,
  Message,
  Session,
  User,
} from '@prisma/client';
import type {
  AuditLogDTO,
  ConversationDTO,
  CreditTransactionDTO,
  MessageDTO,
  SessionDTO,
  UserDTO,
} from '@orbit/shared';

export function toUserDTO(user: User): UserDTO {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    avatar: user.avatar,
    role: user.role,
    status: user.status,
    credits: user.credits,
    createdAt: user.createdAt.toISOString(),
    updatedAt: user.updatedAt.toISOString(),
    lastLoginAt: user.lastLoginAt?.toISOString() ?? null,
  };
}

export function toSessionDTO(session: Session, currentSessionId?: string): SessionDTO {
  return {
    id: session.id,
    userAgent: session.userAgent,
    ip: session.ip,
    createdAt: session.createdAt.toISOString(),
    lastUsedAt: session.lastUsedAt.toISOString(),
    expiresAt: session.expiresAt.toISOString(),
    current: session.id === currentSessionId,
  };
}

export function toMessageDTO(message: Message): MessageDTO {
  return {
    id: message.id,
    conversationId: message.conversationId,
    role: message.role,
    content: message.content,
    model: message.model,
    createdAt: message.createdAt.toISOString(),
    updatedAt: message.updatedAt.toISOString(),
    cost: message.cost,
  };
}

export function toConversationDTO(
  conversation: Conversation,
  messageCount: number,
  lastMessagePreview: string | null,
): ConversationDTO {
  return {
    id: conversation.id,
    title: conversation.title,
    createdAt: conversation.createdAt.toISOString(),
    updatedAt: conversation.updatedAt.toISOString(),
    messageCount,
    lastMessagePreview,
    model: conversation.model,
  };
}

type CreditTransactionWithActor = CreditTransaction & {
  createdBy?: { username: string } | null;
};

export function toCreditTransactionDTO(tx: CreditTransactionWithActor): CreditTransactionDTO {
  return {
    id: tx.id,
    userId: tx.userId,
    amount: tx.amount,
    type: tx.type,
    balanceBefore: tx.balanceBefore,
    balanceAfter: tx.balanceAfter,
    description: tx.description,
    createdAt: tx.createdAt.toISOString(),
    createdBy: tx.createdBy ? tx.createdBy.username : null,
  };
}

export function toAuditLogDTO(log: AuditLog & {
  admin: { username: string };
  targetUser: { username: string } | null;
}): AuditLogDTO {
  return {
    id: log.id,
    adminId: log.adminId,
    adminUsername: log.admin.username,
    action: log.action,
    targetUserId: log.targetUserId,
    targetUsername: log.targetUser?.username ?? null,
    metadata: log.metadata,
    createdAt: log.createdAt.toISOString(),
  };
}
