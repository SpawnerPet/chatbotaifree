import { defaultMessageForCode, ERROR_CODES, httpStatusForCode } from '@orbit/shared';

/**
 * The only error type that reaches the client. Anything else is collapsed to
 * INTERNAL_ERROR in the error handler, so stack traces and driver messages
 * never leave the process.
 */
export class AppError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details?: unknown;
  readonly expose: boolean;

  constructor(code: string, message?: string, details?: unknown, statusOverride?: number) {
    super(message ?? defaultMessageForCode(code));
    this.name = 'AppError';
    this.code = code;
    this.status = statusOverride ?? httpStatusForCode(code);
    this.details = details;
    this.expose = true;
  }
}

export const badRequest = (msg: string, details?: unknown) =>
  new AppError(ERROR_CODES.VALIDATION_ERROR, msg, details);

export const unauthorized = (msg?: string) => new AppError(ERROR_CODES.UNAUTHORIZED, msg);
export const forbidden = (msg?: string) => new AppError(ERROR_CODES.FORBIDDEN, msg);
export const notFound = (msg?: string) => new AppError(ERROR_CODES.NOT_FOUND, msg);
export const conflict = (code: string, msg?: string) => new AppError(code, msg);

export const isAppError = (err: unknown): err is AppError => err instanceof AppError;
