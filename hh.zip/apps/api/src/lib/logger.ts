import { env } from '../config/env.js';

type Level = 'silent' | 'error' | 'warn' | 'info' | 'debug';

const ORDER: Record<Level, number> = { silent: 0, error: 1, warn: 2, info: 3, debug: 4 };
const threshold = ORDER[env.LOG_LEVEL];

const SECRET_PATTERNS = [
  /sk-[A-Za-z0-9_-]{8,}/g,
  /Bearer\s+[A-Za-z0-9._-]{8,}/gi,
];

/**
 * Defence in depth: even if a secret is accidentally passed in, it is scrubbed
 * before it can reach a log sink.
 */
export function redact(value: unknown): unknown {
  if (typeof value === 'string') {
    let out = value;
    for (const pattern of SECRET_PATTERNS) out = out.replace(pattern, '[redacted]');
    return out;
  }
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === 'object') {
    const record = value as Record<string, unknown>;
    const out: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(record)) {
      out[key] = /(secret|token|password|apikey|api_key|authorization|cookie)/i.test(key)
        ? '[redacted]'
        : redact(val);
    }
    return out;
  }
  return value;
}

function emit(level: Exclude<Level, 'silent'>, message: string, meta?: unknown) {
  if (ORDER[level] > threshold) return;
  const line = {
    ts: new Date().toISOString(),
    level,
    msg: message,
    ...(meta !== undefined ? { meta: redact(meta) } : {}),
  };
  const out = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log;
  out(JSON.stringify(line));
}

export const logger = {
  debug: (msg: string, meta?: unknown) => emit('debug', msg, meta),
  info: (msg: string, meta?: unknown) => emit('info', msg, meta),
  warn: (msg: string, meta?: unknown) => emit('warn', msg, meta),
  error: (msg: string, meta?: unknown) => emit('error', msg, meta),
};
