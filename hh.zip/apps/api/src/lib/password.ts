import bcrypt from 'bcryptjs';

const ROUNDS = 12;

export function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, ROUNDS);
}

export function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

/**
 * Burn roughly the same CPU as a real verification when the account does not
 * exist, so response timing does not reveal whether an email is registered.
 */
const DUMMY_HASH = bcrypt.hashSync('orbit-timing-equalizer', ROUNDS);

export async function fakeVerify(): Promise<void> {
  await bcrypt.compare('orbit-timing-equalizer', DUMMY_HASH);
}
