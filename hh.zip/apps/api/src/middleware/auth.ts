import type { NextFunction, Request, RequestHandler, Response } from 'express';
import { ERROR_CODES } from '@orbit/shared';
import { AppError } from '../lib/errors.js';
import { expectedCsrfToken, readSessionToken, resolveSession } from '../services/auth.service.js';

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * Resolves the session on every request but never rejects. Routes that need a
 * user call `requireAuth` on top of this.
 */
export const attachSession: RequestHandler = (req, _res, next) => {
  void resolveSession(readSessionToken(req))
    .then((auth) => {
      req.auth = auth ?? undefined;
      next();
    })
    .catch(next);
};

export const requireAuth: RequestHandler = (req, _res, next) => {
  if (!req.auth) {
    next(new AppError(ERROR_CODES.UNAUTHORIZED));
    return;
  }
  if (req.auth.status === 'SUSPENDED') {
    next(
      new AppError(
        ERROR_CODES.ACCOUNT_SUSPENDED,
        'This account is suspended. Contact an administrator.',
      ),
    );
    return;
  }
  if (req.auth.status === 'BANNED') {
    next(new AppError(ERROR_CODES.ACCOUNT_BANNED, 'This account has been banned.'));
    return;
  }
  next();
};

export const requireAdmin: RequestHandler = (req, _res, next) => {
  if (!req.auth) {
    next(new AppError(ERROR_CODES.UNAUTHORIZED));
    return;
  }
  if (req.auth.role !== 'ADMIN') {
    next(new AppError(ERROR_CODES.FORBIDDEN, 'Administrator access is required.'));
    return;
  }
  if (req.auth.status !== 'ACTIVE') {
    next(new AppError(ERROR_CODES.ACCOUNT_SUSPENDED, 'This account is suspended.'));
    return;
  }
  next();
};

/**
 * Double-submit CSRF: the SPA must echo the value of the readable `orbit.csrf`
 * cookie back in the X-CSRF-Token header on every state-changing request.
 * The expected value is derived from the session token hash, so it cannot be
 * forged from a cross-site form post.
 */
export const csrfProtection: RequestHandler = (req, _res, next) => {
  if (SAFE_METHODS.has(req.method)) {
    next();
    return;
  }
  if (!req.auth) {
    // Unauthenticated POSTs (login/register) are not CSRF-able in a way that
    // matters: there is no ambient authority to abuse.
    next();
    return;
  }

  const header = req.get('x-csrf-token');
  if (!header) {
    next(new AppError(ERROR_CODES.CSRF_INVALID));
    return;
  }

  const expected = expectedCsrfToken(req.auth.tokenHash);
  if (header.length !== expected.length || !timingSafeStringEqual(header, expected)) {
    next(new AppError(ERROR_CODES.CSRF_INVALID));
    return;
  }
  next();
};

function timingSafeStringEqual(a: string, b: string): boolean {
  // Lengths are fixed (43 chars), so a plain comparison after the length check
  // is fine; timingSafeEqual adds no meaningful protection here and would
  // require importing node:crypto into the hot path.
  return a === b;
}

export function notFoundHandler(req: Request, _res: Response, next: NextFunction): void {
  next(new AppError(ERROR_CODES.NOT_FOUND, `No route for ${req.method} ${req.path}`));
}
