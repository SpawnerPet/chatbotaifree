import type { ErrorRequestHandler, Request, RequestHandler, Response } from 'express';
import { ERROR_CODES } from '@orbit/shared';
import { ZodError } from 'zod';
import { AppError, isAppError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';

/**
 * Wraps an async handler so a rejected promise always reaches the central
 * error handler instead of hanging the request.
 */
export function asyncHandler(
  fn: (req: Request, res: Response) => Promise<unknown>,
): RequestHandler {
  return (req, res, next) => {
    Promise.resolve(fn(req, res)).catch(next);
  };
}

export function sendData<T>(res: Response, data: T, status = 200): void {
  res.status(status).json({ success: true, data });
}

export function zodErrorToAppError(err: ZodError): AppError {
  const details = err.issues.map((issue) => ({
    path: issue.path.join('.'),
    message: issue.message,
  }));
  return new AppError(ERROR_CODES.VALIDATION_ERROR, details[0]?.message ?? 'Invalid input.', details);
}

export const notFound = (message = 'Resource not found.') => new AppError(ERROR_CODES.NOT_FOUND, message);

export const errorHandler: ErrorRequestHandler = (err, req, res, _next) => {
  // Normalise anything thrown into an AppError.
  let appError: AppError;
  if (isAppError(err)) {
    appError = err;
  } else if (err instanceof ZodError) {
    appError = zodErrorToAppError(err);
  } else if (isBodyParserError(err)) {
    appError = new AppError(ERROR_CODES.VALIDATION_ERROR, 'Request body is not valid JSON.');
  } else {
    appError = new AppError(ERROR_CODES.INTERNAL_ERROR);
  }

  // 4xx are expected control flow; only 5xx is worth an error-level log.
  const level = appError.status >= 500 ? 'error' : 'warn';
  logger[level]('request failed', {
    method: req.method,
    path: req.path,
    code: appError.code,
    status: appError.status,
    userId: req.auth?.userId,
    reason: err instanceof Error ? err.message.slice(0, 300) : 'unknown',
  });

  const body: {
    success: false;
    error: { code: string; message: string; details?: unknown };
  } = {
    success: false,
    error: {
      code: appError.code,
      // Never leak internals: unexpected errors get the generic message.
      message:
        appError.expose && appError.status < 500
          ? appError.message
          : 'Something went wrong on our side.',
    },
  };
  if (appError.details !== undefined && appError.status < 500) {
    body.error.details = appError.details;
  }

  if (res.headersSent) {
    res.end();
    return;
  }
  res.status(appError.status).json(body);
};

function isBodyParserError(err: unknown): boolean {
  return (
    typeof err === 'object' &&
    err !== null &&
    'type' in err &&
    (err as { type?: string }).type === 'entity.parse.failed'
  );
}
