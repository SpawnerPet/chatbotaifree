import type { NextFunction, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { ERROR_CODES } from '@orbit/shared';
import { AppError } from '../lib/errors.js';
import { env } from '../config/env.js';

function base(windowMs: number, limit: number, message: string) {
  return {
    windowMs,
    limit,
    standardHeaders: true,
    legacyHeaders: false,
    // Tests must not be throttled by earlier cases.
    skip: () => env.isTest,
    handler: (_req: Request, _res: Response, next: NextFunction) => {
      next(new AppError(ERROR_CODES.RATE_LIMITED, message));
    },
  };
}

/** Broad ceiling for the whole API surface. */
export const globalLimiter = rateLimit(base(60_000, 600, 'Too many requests. Slow down.'));

/** Brute-force protection on credential endpoints. */
export const loginLimiter = rateLimit(
  base(15 * 60_000, 10, 'Too many sign-in attempts. Try again in a few minutes.'),
);

export const registerLimiter = rateLimit(
  base(60 * 60_000, 5, 'Too many accounts created from this network.'),
);

export const passwordResetLimiter = rateLimit(
  base(60 * 60_000, 5, 'Too many password reset requests.'),
);

/** Protects the AI budget: a user cannot spam generations. */
export const chatLimiter = rateLimit(
  base(60_000, 30, 'You are sending messages too quickly.'),
);

export const writeLimiter = rateLimit(base(60_000, 120, 'Too many changes too quickly.'));
