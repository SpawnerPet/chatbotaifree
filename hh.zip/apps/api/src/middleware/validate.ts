import type { RequestHandler } from 'express';
import type { ZodTypeAny, z } from 'zod';
import { AppError } from '../lib/errors.js';

type Source = 'body' | 'query' | 'params';

function schemaOf(input: unknown): ZodTypeAny | null {
  if (
    typeof input === 'object' &&
    input !== null &&
    'safeParse' in input &&
    typeof (input as { safeParse?: unknown }).safeParse === 'function'
  ) {
    return input as ZodTypeAny;
  }
  return null;
}

/**
 * Replaces the raw request segment with the parsed (coerced, stripped) value,
 * so downstream handlers only ever see validated data.
 */
export function validate(schema: ZodTypeAny, source: Source = 'body'): RequestHandler {
  return (req, _res, next) => {
    const target = schemaOf(schema);
    if (!target) {
      next(new AppError('INTERNAL_ERROR', 'Invalid validator supplied.'));
      return;
    }
    const result = target.safeParse(req[source]);
    if (!result.success) {
      const issue = result.error.issues[0];
      next(
        new AppError(
          'VALIDATION_ERROR',
          issue?.message ?? 'Invalid input.',
          result.error.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
        ),
      );
      return;
    }
    // req.query/req.params are getter-only on Express 5; assign defensively.
    if (source === 'query') {
      Object.defineProperty(req, 'query', { value: result.data, writable: true, configurable: true });
    } else {
      (req as unknown as Record<string, unknown>)[source] = result.data;
    }
    next();
  };
}

export type Infer<T extends ZodTypeAny> = z.infer<T>;
