import { createServer } from 'node:http';
import { createApp, prepareStorage } from './app.js';
import { env } from './config/env.js';
import { logger } from './lib/logger.js';
import { disconnectPrisma, prisma } from './lib/prisma.js';
import { purgeExpired } from './services/auth.service.js';
import { getSettingsRow } from './services/settings.service.js';

async function main(): Promise<void> {
  await prisma.$connect();
  await prepareStorage();
  await getSettingsRow();

  const app = createApp();
  const server = createServer(app);

  // Long-lived SSE connections must not be reaped by the default 5s timeout.
  server.headersTimeout = 0;
  server.requestTimeout = 0;
  server.keepAliveTimeout = 65_000;

  await new Promise<void>((resolve) => {
    server.listen(env.PORT, () => resolve());
  });

  logger.info('orbit api listening', {
    port: env.PORT,
    env: env.NODE_ENV,
    aiConfigured: env.OPENROUTER_API_KEY.length > 0,
    storage: env.STORAGE_PROVIDER,
  });

  const cleanup = async (signal: string) => {
    logger.info('shutting down', { signal });
    server.close();
    await disconnectPrisma().catch(() => undefined);
    process.exit(0);
  };

  process.on('SIGTERM', () => void cleanup('SIGTERM'));
  process.on('SIGINT', () => void cleanup('SIGINT'));

  // Housekeeping: drop expired sessions and reset tokens hourly.
  const sweeper = setInterval(() => {
    void purgeExpired().catch((err) => logger.error('session sweep failed', { error: String(err) }));
  }, 60 * 60 * 1000);
  sweeper.unref();
}

main().catch((err) => {
  logger.error('fatal startup error', { error: err instanceof Error ? err.message : String(err) });
  process.exit(1);
});
