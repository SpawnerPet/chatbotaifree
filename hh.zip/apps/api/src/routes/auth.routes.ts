import { Router } from 'express';
import {
  changePasswordSchema,
  forgotPasswordSchema,
  idParamSchema,
  loginSchema,
  registerSchema,
  resetPasswordSchema,
} from '@orbit/shared';
import * as controller from '../controllers/auth.controller.js';
import { requireAuth } from '../middleware/auth.js';
import {
  loginLimiter,
  passwordResetLimiter,
  registerLimiter,
  writeLimiter,
} from '../middleware/rate-limit.js';
import { asyncHandler } from '../middleware/error-handler.js';
import { validate } from '../middleware/validate.js';

export const authRouter = Router();

authRouter.post(
  '/register',
  registerLimiter,
  validate(registerSchema),
  asyncHandler(controller.register),
);

authRouter.post('/login', loginLimiter, validate(loginSchema), asyncHandler(controller.login));

authRouter.post('/logout', asyncHandler(controller.logout));

authRouter.get('/me', requireAuth, asyncHandler(controller.me));

authRouter.post(
  '/forgot-password',
  passwordResetLimiter,
  validate(forgotPasswordSchema),
  asyncHandler(controller.forgotPassword),
);

authRouter.post(
  '/reset-password',
  passwordResetLimiter,
  validate(resetPasswordSchema),
  asyncHandler(controller.resetPassword),
);

authRouter.post(
  '/change-password',
  requireAuth,
  writeLimiter,
  validate(changePasswordSchema),
  asyncHandler(controller.changePassword),
);

authRouter.get('/sessions', requireAuth, asyncHandler(controller.listSessions));

authRouter.delete(
  '/sessions/:id',
  requireAuth,
  writeLimiter,
  validate(idParamSchema, 'params'),
  asyncHandler(controller.revokeSession),
);

authRouter.post(
  '/sessions/revoke-others',
  requireAuth,
  writeLimiter,
  asyncHandler(controller.revokeOtherSessions),
);
