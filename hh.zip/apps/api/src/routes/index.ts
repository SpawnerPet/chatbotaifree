import { Router } from 'express';
import {
  adjustCreditsSchema,
  chatRequestSchema,
  adminUserParamsSchema,
  createConversationSchema,
  editMessageSchema,
  idParamSchema,
  listAdminUsersSchema,
  listAuditLogsSchema,
  listConversationsSchema,
  listMessagesSchema,
  regenerateSchema,
  setUserRoleSchema,
  setUserStatusSchema,
  updateConversationSchema,
} from '@orbit/shared';
import { publicEnvSummary } from '../config/env.js';
import * as adminController from '../controllers/admin.controller.js';
import * as chatController from '../controllers/chat.controller.js';
import * as conversationController from '../controllers/conversation.controller.js';
import * as mediaController from '../controllers/media.controller.js';
import * as settingsController from '../controllers/settings.controller.js';
import { requireAdmin, requireAuth } from '../middleware/auth.js';
import { asyncHandler } from '../middleware/error-handler.js';
import { chatLimiter, writeLimiter } from '../middleware/rate-limit.js';
import { validate } from '../middleware/validate.js';
import { prisma } from '../lib/prisma.js';
import { openRouterService } from '../services/openrouter.service.js';
import { openRouterKeyPool } from '../services/openrouter-keys.service.js';
import { getPublicSettings } from '../services/settings.service.js';

export const apiRouter = Router();

// ───────────────────────────── Health ─────────────────────────────

apiRouter.get('/health', (_req, res) => {
  res.json({
    success: true,
    data: { status: 'ok', uptimeSeconds: Math.round(process.uptime()), ...publicEnvSummary() },
  });
});

/**
 * Liveness probe for the AI provider. Intentionally returns only three fields —
 * the API key is never part of any response.
 */
apiRouter.get(
  '/health/openrouter',
  asyncHandler(async (_req, res) => {
    const health = await openRouterService.health();
    res.json({ success: true, data: health });
  }),
);

apiRouter.get(
  '/health/database',
  asyncHandler(async (_req, res) => {
    const started = Date.now();
    await prisma.$queryRaw`SELECT 1`;
    res.json({ success: true, data: { status: 'ok', latencyMs: Date.now() - started } });
  }),
);

// ───────────────────────────── Settings (public) ─────────────────────────────

apiRouter.get(
  '/settings',
  asyncHandler(async (_req, res) => {
    res.json({ success: true, data: await getPublicSettings() });
  }),
);

apiRouter.get(
  '/models',
  requireAuth,
  asyncHandler(async (_req, res) => {
    await settingsController.getModels(_req, res);
  }),
);

// ───────────────────────────── Conversations ─────────────────────────────

apiRouter.get(
  '/conversations',
  requireAuth,
  validate(listConversationsSchema, 'query'),
  asyncHandler(conversationController.listConversations),
);

apiRouter.post(
  '/conversations',
  requireAuth,
  validate(createConversationSchema),
  asyncHandler(conversationController.createConversation),
);

apiRouter.get(
  '/conversations/:id',
  requireAuth,
  validate(idParamSchema, 'params'),
  validate(listMessagesSchema, 'query'),
  asyncHandler(conversationController.getConversation),
);

apiRouter.patch(
  '/conversations/:id',
  requireAuth,
  writeLimiter,
  validate(idParamSchema, 'params'),
  validate(updateConversationSchema),
  asyncHandler(conversationController.updateConversation),
);

apiRouter.delete(
  '/conversations/:id',
  requireAuth,
  writeLimiter,
  validate(idParamSchema, 'params'),
  asyncHandler(conversationController.deleteConversation),
);

// ───────────────────────────── Messages ─────────────────────────────

apiRouter.patch(
  '/messages/:id',
  requireAuth,
  writeLimiter,
  validate(idParamSchema, 'params'),
  validate(editMessageSchema),
  asyncHandler(conversationController.editMessage),
);

apiRouter.delete(
  '/messages/:id',
  requireAuth,
  writeLimiter,
  validate(idParamSchema, 'params'),
  asyncHandler(conversationController.deleteMessage),
);

// ───────────────────────────── Chat ─────────────────────────────

apiRouter.post(
  '/chat',
  requireAuth,
  chatLimiter,
  validate(chatRequestSchema),
  asyncHandler(chatController.chatOnce),
);

apiRouter.post(
  '/chat/stream',
  requireAuth,
  chatLimiter,
  validate(chatRequestSchema),
  asyncHandler(chatController.streamChat),
);

apiRouter.post(
  '/chat/regenerate',
  requireAuth,
  chatLimiter,
  validate(regenerateSchema),
  asyncHandler(chatController.regenerate),
);

// ───────────────────────────── Admin ─────────────────────────────

const adminRouter = Router();
adminRouter.use(requireAuth, requireAdmin);

adminRouter.get('/stats', asyncHandler(adminController.getStats));

adminRouter.get(
  '/users',
  validate(listAdminUsersSchema, 'query'),
  asyncHandler(adminController.listUsers),
);

adminRouter.get(
  '/users/:id',
  validate(adminUserParamsSchema, 'params'),
  asyncHandler(adminController.getUser),
);

adminRouter.post(
  '/users/:id/credits',
  writeLimiter,
  validate(adminUserParamsSchema, 'params'),
  validate(adjustCreditsSchema),
  asyncHandler(adminController.adjustCredits),
);

adminRouter.patch(
  '/users/:id/status',
  writeLimiter,
  validate(adminUserParamsSchema, 'params'),
  validate(setUserStatusSchema),
  asyncHandler(adminController.setUserStatus),
);

adminRouter.patch(
  '/users/:id/role',
  writeLimiter,
  validate(adminUserParamsSchema, 'params'),
  validate(setUserRoleSchema),
  asyncHandler(adminController.setUserRole),
);

adminRouter.get(
  '/audit-logs',
  validate(listAuditLogsSchema, 'query'),
  asyncHandler(adminController.listAuditLogs),
);

adminRouter.get(
  '/ai-keys',
  asyncHandler(async (_req, res) => {
    // Labels only — the pool never exposes a key, not even to an admin.
    res.json({
      success: true,
      data: {
        keys: openRouterKeyPool.status(),
        rotations: openRouterKeyPool.rotationCount,
      },
    });
  }),
);

adminRouter.get(
  '/media',
  asyncHandler(mediaController.listMedia),
);

adminRouter.post(
  '/media',
  mediaController.rawUploadBody,
  asyncHandler(mediaController.uploadMedia),
);

adminRouter.delete(
  '/media/:id',
  writeLimiter,
  validate(idParamSchema, 'params'),
  asyncHandler(mediaController.deleteMedia),
);

adminRouter.patch(
  '/settings',
  writeLimiter,
  asyncHandler(settingsController.patchSettings),
);

apiRouter.use('/admin', adminRouter);
