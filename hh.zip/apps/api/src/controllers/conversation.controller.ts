import type { Prisma } from '@prisma/client';
import {
  ERROR_CODES,
  type ConversationDetailDTO,
  type ListConversationsInput,
  type ListMessagesInput,
  type Paginated,
} from '@orbit/shared';
import type { Request, Response } from 'express';
import { AppError } from '../lib/errors.js';
import { toConversationDTO, toMessageDTO } from '../lib/presenters.js';
import { prisma } from '../lib/prisma.js';

const PREVIEW_CHARS = 140;

/**
 * One query for the sidebar: conversations with their message count and a
 * preview, paginated and optionally filtered by a debounced search term.
 */
export async function listConversations(req: Request, res: Response): Promise<void> {
  const { page, pageSize, search } = req.query as unknown as ListConversationsInput;
  const userId = req.auth!.userId;

  const where: Prisma.ConversationWhereInput = {
    userId,
    ...(search
      ? {
          OR: [
            { title: { contains: search, mode: 'insensitive' } },
            {
              messages: {
                some: { content: { contains: search, mode: 'insensitive' } },
              },
            },
          ],
        }
      : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.conversation.findMany({
      where,
      orderBy: { updatedAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        _count: { select: { messages: true } },
        messages: { orderBy: { createdAt: 'desc' }, take: 1, select: { content: true } },
      },
    }),
    prisma.conversation.count({ where }),
  ]);

  const items: Paginated<ReturnType<typeof toConversationDTO>> = {
    items: rows.map((row) => {
      const last = row.messages[0]?.content ?? null;
      return toConversationDTO(
        row,
        row._count.messages,
        last ? last.replace(/\s+/g, ' ').slice(0, PREVIEW_CHARS) : null,
      );
    }),
    page,
    pageSize,
    total,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };

  res.json({ success: true, data: items });
}

export async function createConversation(req: Request, res: Response): Promise<void> {
  const { title } = req.body as { title?: string };
  const userId = req.auth!.userId;
  const conversation = await prisma.conversation.create({
    data: { userId, title: title?.trim() || 'New conversation' },
  });
  res
    .status(201)
    .json({ success: true, data: toConversationDTO(conversation, 0, null) });
}

async function ownedConversation(id: string, userId: string) {
  const conversation = await prisma.conversation.findFirst({ where: { id, userId } });
  if (!conversation) throw new AppError(ERROR_CODES.NOT_FOUND, 'Conversation not found.');
  return conversation;
}

export async function getConversation(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const userId = req.auth!.userId;
  const { limit, cursor } = req.query as unknown as ListMessagesInput;

  const conversation = await ownedConversation(id, userId);

  const messages = await prisma.message.findMany({
    where: { conversationId: id },
    orderBy: { createdAt: 'asc' },
    take: limit,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
  });

  const count = await prisma.message.count({ where: { conversationId: id } });
  const last = messages[messages.length - 1]?.content ?? null;

  const payload: ConversationDetailDTO = {
    ...toConversationDTO(
      conversation,
      count,
      last ? last.replace(/\s+/g, ' ').slice(0, PREVIEW_CHARS) : null,
    ),
    messages: messages.map(toMessageDTO),
  };

  res.json({ success: true, data: payload });
}

export async function updateConversation(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const userId = req.auth!.userId;
  const { title } = req.body as { title: string };

  await ownedConversation(id, userId);
  const conversation = await prisma.conversation.update({
    where: { id },
    data: { title },
  });
  res.json({ success: true, data: toConversationDTO(conversation, 0, null) });
}

export async function deleteConversation(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const userId = req.auth!.userId;
  await ownedConversation(id, userId);
  // Messages cascade at the database level.
  await prisma.conversation.delete({ where: { id } });
  res.json({ success: true, data: { deleted: true } });
}

/**
 * Edits a user message and truncates everything after it, so the next
 * regenerate produces a coherent branch.
 */
export async function editMessage(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const userId = req.auth!.userId;
  const { content } = req.body as { content: string };

  const message = await prisma.message.findFirst({
    where: { id, role: 'USER', conversation: { userId } },
    select: { id: true, conversationId: true, createdAt: true },
  });
  if (!message) throw new AppError(ERROR_CODES.NOT_FOUND, 'Message not found.');

  const [, updated] = await prisma.$transaction([
    prisma.message.deleteMany({
      where: { conversationId: message.conversationId, createdAt: { gt: message.createdAt } },
    }),
    prisma.message.update({ where: { id }, data: { content } }),
  ]);

  res.json({ success: true, data: toMessageDTO(updated) });
}

export async function deleteMessage(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const userId = req.auth!.userId;
  const message = await prisma.message.findFirst({
    where: { id, conversation: { userId } },
    select: { id: true },
  });
  if (!message) throw new AppError(ERROR_CODES.NOT_FOUND, 'Message not found.');
  await prisma.message.delete({ where: { id } });
  res.json({ success: true, data: { deleted: true } });
}
