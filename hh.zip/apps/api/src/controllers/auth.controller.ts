import { ERROR_CODES } from '@orbit/shared';
import type { Request, Response } from 'express';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { toSessionDTO, toUserDTO } from '../lib/presenters.js';
import { fakeVerify, hashPassword, verifyPassword } from '../lib/password.js';
import { prisma } from '../lib/prisma.js';
import {
  assertAccountUsable,
  consumePasswordResetToken,
  createPasswordResetToken,
  createSession,
  destroyAllSessions,
  destroySession,
} from '../services/auth.service.js';
import { creditService } from '../services/credit.service.js';
import type {
  ChangePasswordInput,
  ForgotPasswordInput,
  LoginInput,
  RegisterInput,
  ResetPasswordInput,
} from '@orbit/shared';
import { logger } from '../lib/logger.js';

function clientMeta(req: Request) {
  return {
    userAgent: req.get('user-agent') ?? 'unknown',
    ip: req.ip ?? 'unknown',
  };
}

export async function register(req: Request, res: Response): Promise<void> {
  const { email, username, password } = req.body as RegisterInput;

  const [emailTaken, usernameTaken] = await Promise.all([
    prisma.user.findUnique({ where: { emailLower: email }, select: { id: true } }),
    prisma.user.findUnique({ where: { username }, select: { id: true } }),
  ]);
  if (emailTaken) throw new AppError(ERROR_CODES.EMAIL_TAKEN);
  if (usernameTaken) throw new AppError(ERROR_CODES.USERNAME_TAKEN);

  const passwordHash = await hashPassword(password);

  // First account ever becomes the administrator — a safe bootstrap that
  // never relies on a hard-coded credential.
  const isFirstUser = (await prisma.user.count()) === 0;

  const user = await prisma.user.create({
    data: {
      email,
      emailLower: email,
      username,
      passwordHash,
      role: isFirstUser ? 'ADMIN' : 'USER',
    },
  });

  await creditService.grantSignupBonus(user.id, env.SIGNUP_BONUS_CREDITS);
  const withCredits = await prisma.user.findUniqueOrThrow({ where: { id: user.id } });

  await createSession(res, user.id, clientMeta(req));
  res.status(201).json({ success: true, data: toUserDTO(withCredits) });
}

export async function login(req: Request, res: Response): Promise<void> {
  const { email, password } = req.body as LoginInput;

  const user = await prisma.user.findUnique({ where: { emailLower: email } });
  if (!user) {
    // Equalise timing so a missing account is not detectable.
    await fakeVerify();
    throw new AppError(ERROR_CODES.INVALID_CREDENTIALS);
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) throw new AppError(ERROR_CODES.INVALID_CREDENTIALS);

  assertAccountUsable(user.status);

  await createSession(res, user.id, clientMeta(req));
  res.json({ success: true, data: toUserDTO(user) });
}

export async function logout(req: Request, res: Response): Promise<void> {
  await destroySession(req, res);
  res.json({ success: true, data: { loggedOut: true } });
}

export async function me(req: Request, res: Response): Promise<void> {
  if (!req.auth) throw new AppError(ERROR_CODES.UNAUTHORIZED);
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.auth.userId } });
  res.json({ success: true, data: toUserDTO(user) });
}

export async function forgotPassword(req: Request, res: Response): Promise<void> {
  const { email } = req.body as ForgotPasswordInput;
  const user = await prisma.user.findUnique({ where: { emailLower: email } });

  if (user && user.status !== 'BANNED') {
    const token = await createPasswordResetToken(user.id);
    // Always the same response, so this endpoint cannot enumerate accounts.
    if (!env.isProd) {
      logger.info('password reset token issued (development only)', { userId: user.id });
    }
    if (!env.isProd) {
      res.setHeader('x-dev-reset-token', token);
    }
  }

  res.json({
    success: true,
    data: {
      message: 'If an account exists for that email, a reset link is on its way.',
    },
  });
}

export async function resetPassword(req: Request, res: Response): Promise<void> {
  const { token, password } = req.body as ResetPasswordInput;
  const userId = await consumePasswordResetToken(token);

  const passwordHash = await hashPassword(password);
  await prisma.user.update({ where: { id: userId }, data: { passwordHash } });

  // A password change invalidates every existing session.
  await destroyAllSessions(userId);

  res.json({ success: true, data: { reset: true } });
}

export async function changePassword(req: Request, res: Response): Promise<void> {
  if (!req.auth) throw new AppError(ERROR_CODES.UNAUTHORIZED);
  const { currentPassword, newPassword } = req.body as ChangePasswordInput;

  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.auth.userId } });
  const valid = await verifyPassword(currentPassword, user.passwordHash);
  if (!valid) throw new AppError(ERROR_CODES.INVALID_CREDENTIALS, 'Current password is incorrect.');

  const passwordHash = await hashPassword(newPassword);
  await prisma.user.update({ where: { id: user.id }, data: { passwordHash } });
  await destroyAllSessions(user.id);

  // Re-establish the current session so the user is not logged out of this tab.
  await createSession(res, user.id, clientMeta(req));

  res.json({ success: true, data: { changed: true, otherSessionsRevoked: true } });
}

export async function listSessions(req: Request, res: Response): Promise<void> {
  if (!req.auth) throw new AppError(ERROR_CODES.UNAUTHORIZED);
  const sessions = await prisma.session.findMany({
    where: { userId: req.auth.userId, expiresAt: { gt: new Date() } },
    orderBy: { lastUsedAt: 'desc' },
  });
  res.json({
    success: true,
    data: sessions.map((s) => toSessionDTO(s, req.auth!.sessionId)),
  });
}

export async function revokeSession(req: Request, res: Response): Promise<void> {
  if (!req.auth) throw new AppError(ERROR_CODES.UNAUTHORIZED);
  const id = String(req.params.id ?? '');
  const session = await prisma.session.findUnique({ where: { id } });
  if (!session || session.userId !== req.auth.userId) {
    throw new AppError(ERROR_CODES.NOT_FOUND, 'Session not found.');
  }
  await prisma.session.delete({ where: { id } });
  res.json({ success: true, data: { revoked: true } });
}

export async function revokeOtherSessions(req: Request, res: Response): Promise<void> {
  if (!req.auth) throw new AppError(ERROR_CODES.UNAUTHORIZED);
  const { count } = await prisma.session.deleteMany({
    where: { userId: req.auth.userId, NOT: { id: req.auth.sessionId } },
  });
  res.json({ success: true, data: { revoked: count } });
}
