import type { Prisma } from '@prisma/client';
import {
  ERROR_CODES,
  type AdminStats,
  type AdminUserDetailDTO,
  type AdjustCreditsInput,
  type ListAdminUsersInput,
  type ListAuditLogsInput,
  type Paginated,
  type SetUserRoleInput,
  type SetUserStatusInput,
} from '@orbit/shared';
import type { Request, Response } from 'express';
import { AppError } from '../lib/errors.js';
import { toAuditLogDTO, toCreditTransactionDTO, toUserDTO } from '../lib/presenters.js';
import { prisma } from '../lib/prisma.js';
import { recordAudit } from '../services/audit.service.js';
import { creditService } from '../services/credit.service.js';

const DAY = 24 * 60 * 60 * 1000;

export async function getStats(_req: Request, res: Response): Promise<void> {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * DAY);

  const [
    totalUsers,
    activeUsers,
    suspendedUsers,
    bannedUsers,
    admins,
    newLast7Days,
    outstandingCredits,
    grantedAgg,
    consumedAgg,
    refundedAgg,
    conversations,
    messages,
    assistantMessages,
    requestGroups,
    lastRequest,
  ] = await Promise.all([
    prisma.user.count(),
    prisma.user.count({ where: { status: 'ACTIVE' } }),
    prisma.user.count({ where: { status: 'SUSPENDED' } }),
    prisma.user.count({ where: { status: 'BANNED' } }),
    prisma.user.count({ where: { role: 'ADMIN' } }),
    prisma.user.count({ where: { createdAt: { gte: weekAgo } } }),
    prisma.user.aggregate({ _sum: { credits: true } }),
    prisma.creditTransaction.aggregate({
      where: { amount: { gt: 0 } },
      _sum: { amount: true },
    }),
    prisma.creditTransaction.aggregate({
      where: { type: 'CHAT_USAGE' },
      _sum: { amount: true },
    }),
    prisma.creditTransaction.aggregate({
      where: { type: 'REFUND' },
      _sum: { amount: true },
    }),
    prisma.conversation.count(),
    prisma.message.count(),
    prisma.message.count({ where: { role: 'ASSISTANT' } }),
    prisma.aiRequest.groupBy({ by: ['status'], _count: { _all: true } }),
    prisma.aiRequest.findFirst({ orderBy: { createdAt: 'desc' }, select: { createdAt: true } }),
  ]);

  const byStatus = Object.fromEntries(requestGroups.map((g) => [g.status, g._count._all]));
  const succeeded = byStatus.SUCCEEDED ?? 0;
  const failed = byStatus.FAILED ?? 0;
  const aborted = byStatus.ABORTED ?? 0;

  const stats: AdminStats = {
    users: {
      total: totalUsers,
      active: activeUsers,
      suspended: suspendedUsers,
      banned: bannedUsers,
      admins,
      newLast7Days,
      activeLast7Days: activeUsers,
    },
    credits: {
      outstanding: outstandingCredits._sum.credits ?? 0,
      granted: grantedAgg._sum.amount ?? 0,
      consumed: Math.abs(consumedAgg._sum.amount ?? 0),
      refunded: refundedAgg._sum.amount ?? 0,
    },
    chat: { conversations, messages, assistantMessages },
    requests: {
      total: succeeded + failed + aborted,
      succeeded,
      failed,
      aborted,
      refunded: refundedAgg._sum.amount ?? 0,
    },
    lastRequestAt: lastRequest?.createdAt.toISOString() ?? null,
  };

  res.json({ success: true, data: stats });
}

export async function listUsers(req: Request, res: Response): Promise<void> {
  const { page, pageSize, search, role, status, sort, order } =
    req.query as unknown as ListAdminUsersInput;

  const where: Prisma.UserWhereInput = {
    ...(role ? { role } : {}),
    ...(status ? { status } : {}),
    ...(search
      ? {
          OR: [
            { email: { contains: search, mode: 'insensitive' } },
            { username: { contains: search, mode: 'insensitive' } },
          ],
        }
      : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.user.findMany({
      where,
      orderBy: { [sort]: order },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.user.count({ where }),
  ]);

  const payload: Paginated<ReturnType<typeof toUserDTO>> = {
    items: rows.map(toUserDTO),
    page,
    pageSize,
    total,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
  res.json({ success: true, data: payload });
}

export async function getUser(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');

  const [transactions, conversationCount, messageCount, sessionCount, auditLogs, requests] =
    await Promise.all([
      prisma.creditTransaction.findMany({
        where: { userId: id },
        orderBy: { createdAt: 'desc' },
        take: 50,
        include: { createdBy: { select: { username: true } } },
      }),
      prisma.conversation.count({ where: { userId: id } }),
      prisma.message.count({ where: { conversation: { userId: id } } }),
      prisma.session.count({ where: { userId: id } }),
      prisma.auditLog.findMany({
        where: { targetUserId: id },
        orderBy: { createdAt: 'desc' },
        take: 50,
        include: {
          admin: { select: { username: true } },
          targetUser: { select: { username: true } },
        },
      }),
      prisma.aiRequest.groupBy({
        by: ['status'],
        where: { userId: id },
        _count: { _all: true },
      }),
    ]);

  const byStatus = Object.fromEntries(requests.map((r) => [r.status, r._count._all]));

  const payload: AdminUserDetailDTO = {
    user: toUserDTO(user),
    creditTransactions: transactions.map(toCreditTransactionDTO),
    conversationCount,
    messageCount,
    sessionCount,
    auditLogs: auditLogs.map(toAuditLogDTO),
    stats: {
      requests: (byStatus.SUCCEEDED ?? 0) + (byStatus.FAILED ?? 0) + (byStatus.ABORTED ?? 0),
      succeeded: byStatus.SUCCEEDED ?? 0,
      failed: (byStatus.FAILED ?? 0) + (byStatus.ABORTED ?? 0),
    },
  };

  res.json({ success: true, data: payload });
}

/** Add (positive) or remove (negative) credits, with a ledger row and an audit entry. */
export async function adjustCredits(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const { amount, reason } = req.body as AdjustCreditsInput;
  const adminId = req.auth!.userId;

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');

  const type = amount > 0 ? 'ADMIN_ADD' : 'ADMIN_REMOVE';

  let result;
  try {
    result = await creditService.applyDelta(id, {
      amount,
      type,
      description: reason,
      createdById: adminId,
    });
  } catch (err) {
    if (err instanceof AppError && err.code === ERROR_CODES.INSUFFICIENT_CREDITS) {
      throw new AppError(
        ERROR_CODES.VALIDATION_ERROR,
        `Cannot remove ${Math.abs(amount)} credits — the user only has ${user.credits}.`,
      );
    }
    throw err;
  }

  await recordAudit({
    adminId,
    action: amount > 0 ? 'ADMIN_ADD_CREDIT' : 'ADMIN_REMOVE_CREDIT',
    targetUserId: id,
    metadata: { amount, reason, balanceAfter: result.balanceAfter },
  });

  const updated = await prisma.user.findUniqueOrThrow({ where: { id } });
  res.json({
    success: true,
    data: { user: toUserDTO(updated), balanceBefore: result.balanceBefore, balanceAfter: result.balanceAfter },
  });
}

export async function setUserStatus(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const { status, reason } = req.body as SetUserStatusInput;
  const adminId = req.auth!.userId;

  if (id === adminId && status !== 'ACTIVE') {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'You cannot suspend your own account.');
  }

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');

  const updated = await prisma.user.update({ where: { id }, data: { status } });

  if (status !== 'ACTIVE') {
    // A suspended or banned user must lose access immediately.
    await prisma.session.deleteMany({ where: { userId: id } });
  }

  const action =
    status === 'SUSPENDED' ? 'SUSPEND_USER' : status === 'BANNED' ? 'BAN_USER' : 'ACTIVATE_USER';

  await recordAudit({
    adminId,
    action,
    targetUserId: id,
    metadata: { from: user.status, to: status, reason: reason ?? null },
  });

  res.json({ success: true, data: toUserDTO(updated) });
}

export async function setUserRole(req: Request, res: Response): Promise<void> {
  const id = String(req.params.id);
  const { role, reason } = req.body as SetUserRoleInput;
  const adminId = req.auth!.userId;

  if (id === adminId && role !== 'ADMIN') {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'You cannot remove your own administrator role.');
  }

  const user = await prisma.user.findUnique({ where: { id } });
  if (!user) throw new AppError(ERROR_CODES.NOT_FOUND, 'User not found.');

  if (user.role === 'ADMIN' && role !== 'ADMIN') {
    const admins = await prisma.user.count({ where: { role: 'ADMIN' } });
    if (admins <= 1) {
      throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'At least one administrator must remain.');
    }
  }

  const updated = await prisma.user.update({ where: { id }, data: { role } });

  await recordAudit({
    adminId,
    action: 'CHANGE_ROLE',
    targetUserId: id,
    metadata: { from: user.role, to: role, reason: reason ?? null },
  });

  res.json({ success: true, data: toUserDTO(updated) });
}

export async function listAuditLogs(req: Request, res: Response): Promise<void> {
  const { page, pageSize, action, adminId, targetUserId } =
    req.query as unknown as ListAuditLogsInput;

  const where: Prisma.AuditLogWhereInput = {
    ...(action ? { action } : {}),
    ...(adminId ? { adminId } : {}),
    ...(targetUserId ? { targetUserId } : {}),
  };

  const [rows, total] = await Promise.all([
    prisma.auditLog.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: {
        admin: { select: { username: true } },
        targetUser: { select: { username: true } },
      },
    }),
    prisma.auditLog.count({ where }),
  ]);

  const payload: Paginated<ReturnType<typeof toAuditLogDTO>> = {
    items: rows.map(toAuditLogDTO),
    page,
    pageSize,
    total,
    totalPages: Math.max(1, Math.ceil(total / pageSize)),
  };
  res.json({ success: true, data: payload });
}
