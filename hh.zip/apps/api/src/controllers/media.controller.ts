import { ERROR_CODES } from '@orbit/shared';
import type { Request, Response } from 'express';
import express from 'express';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { recordAudit } from '../services/audit.service.js';
import { mediaService } from '../services/media.service.js';
import { toPublicMedia } from '../services/settings.service.js';

const CATEGORIES = new Set(['image', 'video', 'audio']);

/**
 * Raw binary body parser for the upload endpoint.
 *
 * The client POSTs the file bytes with the real Content-Type. The declared type
 * is only a hint — media.service re-validates it against the file's magic
 * bytes — so this stays safe without a multipart parser.
 */
export const rawUploadBody = express.raw({
  type: () => true,
  limit: Math.max(env.MAX_VIDEO_UPLOAD_BYTES, env.MAX_AUDIO_UPLOAD_BYTES) + 64 * 1024,
});

function safeFilename(value: string | undefined): string {
  if (!value) return 'upload';
  // Strip any path component; the storage layer sanitises again.
  return value.split(/[\\/]/).pop()?.slice(0, 120) || 'upload';
}

export async function uploadMedia(req: Request, res: Response): Promise<void> {
  const adminId = req.auth!.userId;
  const category = String(req.query.category ?? 'image');

  if (!CATEGORIES.has(category)) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'category must be image, video or audio.');
  }

  const body = req.body;
  if (!Buffer.isBuffer(body) || body.length === 0) {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'No file was uploaded.');
  }

  const record = await mediaService.upload(
    {
      buffer: body,
      originalName: safeFilename(
        typeof req.query.filename === 'string' ? req.query.filename : undefined,
      ),
      declaredMime: req.get('content-type') ?? 'application/octet-stream',
    },
    category as 'image' | 'video' | 'audio',
    typeof req.query.altText === 'string' ? req.query.altText.slice(0, 240) : '',
  );

  await recordAudit({
    adminId,
    action: 'UPLOAD_MEDIA',
    metadata: {
      mediaId: record.id,
      kind: record.kind,
      size: record.size,
      mimeType: record.mimeType,
    },
  });

  const full = await mediaService.get(record.id);
  res.status(201).json({ success: true, data: toPublicMedia(full!) });
}

export async function listMedia(req: Request, res: Response): Promise<void> {
  const kind = req.query.kind;
  const rows = await mediaService.list(
    typeof kind === 'string' && kind.length > 0 ? (kind as never) : undefined,
  );
  res.json({ success: true, data: rows.map(toPublicMedia) });
}

export async function deleteMedia(req: Request, res: Response): Promise<void> {
  const adminId = req.auth!.userId;
  const id = String(req.params.id);

  const before = await mediaService.get(id);
  await mediaService.remove(id);

  await recordAudit({
    adminId,
    action: 'DELETE_MEDIA',
    metadata: { mediaId: id, kind: before?.kind ?? null, filename: before?.filename ?? null },
  });

  res.json({ success: true, data: { deleted: true } });
}
