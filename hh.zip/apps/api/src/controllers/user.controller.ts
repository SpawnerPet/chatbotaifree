import { ERROR_CODES, type UpdateProfileInput } from '@orbit/shared';
import type { Request, Response } from 'express';
import { AppError } from '../lib/errors.js';
import { toCreditTransactionDTO, toUserDTO } from '../lib/presenters.js';
import { prisma } from '../lib/prisma.js';
import { creditService } from '../services/credit.service.js';

export async function getProfile(req: Request, res: Response): Promise<void> {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: req.auth!.userId } });
  res.json({ success: true, data: toUserDTO(user) });
}

export async function updateProfile(req: Request, res: Response): Promise<void> {
  const { username, avatarUrl } = req.body as UpdateProfileInput;
  const userId = req.auth!.userId;

  if (username) {
    const taken = await prisma.user.findFirst({
      where: { username, NOT: { id: userId } },
      select: { id: true },
    });
    if (taken) throw new AppError(ERROR_CODES.USERNAME_TAKEN);
  }

  const user = await prisma.user.update({
    where: { id: userId },
    data: {
      ...(username ? { username } : {}),
      ...(avatarUrl !== undefined ? { avatar: avatarUrl } : {}),
    },
  });

  res.json({ success: true, data: toUserDTO(user) });
}

export async function getCreditHistory(req: Request, res: Response): Promise<void> {
  const page = Number(req.query.page ?? 1) || 1;
  const pageSize = Math.min(50, Number(req.query.pageSize ?? 20) || 20);
  const { items, total } = await creditService.history(req.auth!.userId, page, pageSize);

  res.json({
    success: true,
    data: {
      items: items.map(toCreditTransactionDTO),
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    },
  });
}

export async function getUsageSummary(req: Request, res: Response): Promise<void> {
  const userId = req.auth!.userId;
  const [requests, spent, conversations, messages] = await Promise.all([
    prisma.aiRequest.groupBy({
      by: ['status'],
      where: { userId },
      _count: { _all: true },
    }),
    prisma.creditTransaction.aggregate({
      where: { userId, type: 'CHAT_USAGE' },
      _sum: { amount: true },
    }),
    prisma.conversation.count({ where: { userId } }),
    prisma.message.count({ where: { conversation: { userId } } }),
  ]);

  res.json({
    success: true,
    data: {
      requestsByStatus: Object.fromEntries(requests.map((r) => [r.status, r._count._all])),
      creditsSpent: Math.abs(spent._sum.amount ?? 0),
      conversations,
      messages,
    },
  });
}
