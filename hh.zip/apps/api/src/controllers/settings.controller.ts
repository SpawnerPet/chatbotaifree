import { settingsSchema } from '@orbit/shared';
import type { Request, Response } from 'express';
import { recordAudit } from '../services/audit.service.js';
import { getPublicSettings, updateSettings } from '../services/settings.service.js';

export async function getSettings(_req: Request, res: Response): Promise<void> {
  const settings = await getPublicSettings();
  // Public branding is cacheable; the admin panel busts it with its own calls.
  res.setHeader('Cache-Control', 'no-store');
  res.json({ success: true, data: settings });
}

export async function patchSettings(req: Request, res: Response): Promise<void> {
  const adminId = req.auth!.userId;
  const input = settingsSchema.parse(req.body);

  const { changed } = await updateSettings(input as Record<string, unknown>);

  await recordAudit({
    adminId,
    action: 'UPDATE_SITE_SETTINGS',
    metadata: { changed },
  });

  const settings = await getPublicSettings();
  res.json({ success: true, data: settings });
}

export async function getModels(_req: Request, res: Response): Promise<void> {
  const { env } = await import('../config/env.js');
  res.json({
    success: true,
    data: {
      models: env.allowedModels.map((id) => ({
        id,
        label: id,
        isDefault: id === env.OPENROUTER_MODEL,
      })),
      defaultModel: env.OPENROUTER_MODEL,
    },
  });
}
