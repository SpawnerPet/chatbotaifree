import { type Message } from '@prisma/client';
import {
  ERROR_CODES,
  STREAM_EVENTS,
  type ChatRequestInput,
  type RegenerateInput,
  type StreamEvent,
} from '@orbit/shared';
import type { Request, Response } from 'express';
import { env } from '../config/env.js';
import { AppError } from '../lib/errors.js';
import { logger } from '../lib/logger.js';
import { toMessageDTO } from '../lib/presenters.js';
import { prisma } from '../lib/prisma.js';
import { creditService } from '../services/credit.service.js';
import { isModelAllowed, openRouterService, type ChatMessage } from '../services/openrouter.service.js';

const MAX_HISTORY_MESSAGES = 40;
const MAX_CONTEXT_CHARS = 120_000;
const TITLE_MAX = 60;

function titleFrom(text: string): string {
  const line = text.replace(/\s+/g, ' ').trim();
  if (line.length <= TITLE_MAX) return line || 'New conversation';
  return `${line.slice(0, TITLE_MAX - 1).trimEnd()}…`;
}

function resolveModel(requested: string | undefined): string {
  const model = requested && requested.length > 0 ? requested : env.OPENROUTER_MODEL;
  try {
    isModelAllowed(model);
  } catch {
    throw new AppError(ERROR_CODES.VALIDATION_ERROR, 'That model is not available on this deployment.');
  }
  return model;
}

/** Builds the upstream context, newest-first trimmed to a sane token budget. */
function buildContext(history: Message[]): ChatMessage[] {
  const picked: ChatMessage[] = [];
  let chars = 0;

  for (let i = history.length - 1; i >= 0; i -= 1) {
    const message = history[i]!;
    if (message.role === 'SYSTEM') continue;
    const content = message.content;
    if (chars + content.length > MAX_CONTEXT_CHARS) break;
    chars += content.length;
    picked.unshift({ role: message.role === 'ASSISTANT' ? 'assistant' : 'user', content });
  }
  return picked.slice(-MAX_HISTORY_MESSAGES);
}

interface RunOptions {
  conversationId: string;
  model: string;
  history: Message[];
  /** Called with the persisted assistant message once the stream completes. */
  onDone: (message: Message, creditsRemaining: number) => void;
  onError: (err: AppError, creditsRemaining: number, refunded: boolean) => void;
  onAborted: (creditsRemaining: number, refunded: boolean) => void;
}

/**
 * Shared engine for the initial send, regenerate and retry paths.
 *
 * Credit contract:
 *  1. Refuse before contacting the provider if the balance is too low.
 *  2. Charge atomically, then call the provider.
 *  3. Refund in full if the call produced no usable completion.
 */
async function runCompletion(res: Response, options: RunOptions): Promise<void> {
  const { conversationId, model, history, onDone, onError, onAborted } = options;
  const userId = res.req.auth!.userId;

  const headers: Record<string, string> = {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  };
  res.writeHead(200, headers);
  res.flushHeaders?.();

  const send = (event: StreamEvent) => {
    if (res.writableEnded) return;
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  const cost = env.CHAT_COST_CREDITS;

  // 1. Pre-flight — no provider call without credits.
  let creditsRemaining: number;
  try {
    creditsRemaining = await creditService.assertCanAfford(userId, cost);
  } catch (err) {
    const appError = err instanceof AppError ? err : new AppError(ERROR_CODES.INTERNAL_ERROR);
    send({
      event: STREAM_EVENTS.ERROR,
      code: appError.code,
      message: appError.message,
      refunded: false,
      creditsRemaining: 0,
    });
    res.end();
    return;
  }

  // 2. Reserve the credit and open an audit row for this request.
  const request = await prisma.aiRequest.create({
    data: {
      userId,
      conversationId,
      model,
      status: 'PENDING',
      promptChars: history.reduce((sum, m) => sum + m.content.length, 0),
      chargedCredits: cost,
    },
    select: { id: true },
  });

  try {
    creditsRemaining = await creditService.chargeChat(
      userId,
      `AI request (${model})`,
    );
  } catch (err) {
    await prisma.aiRequest
      .update({
        where: { id: request.id },
        data: {
          status: 'FAILED',
          errorCode: err instanceof AppError ? err.code : 'UNKNOWN',
          completedAt: new Date(),
        },
      })
      .catch(() => undefined);
    const appError = err instanceof AppError ? err : new AppError(ERROR_CODES.INTERNAL_ERROR);
    send({
      event: STREAM_EVENTS.ERROR,
      code: appError.code,
      message: appError.message,
      refunded: false,
      creditsRemaining: 0,
    });
    res.end();
    return;
  }

  const assistantMessageId = `pending_${request.id}`;
  send({
    event: STREAM_EVENTS.META,
    conversationId,
    userMessageId: history[history.length - 1]?.id ?? '',
    assistantMessageId,
    model,
    creditsRemaining,
  });

  const controller = new AbortController();
  const onClientDisconnect = () => controller.abort();
  res.req.on('aborted', onClientDisconnect);
  res.on('close', () => {
    if (!res.writableEnded) controller.abort();
  });

  let content = '';
  const started = Date.now();

  try {
    const handle = openRouterService.stream(
      {
        model,
        messages: buildContext(history),
        signal: controller.signal,
      },
      (chunk) => {
        content += chunk.text;
        send({ event: STREAM_EVENTS.DELTA, text: chunk.text });
      },
    );

    const result = await handle.done;

    if (!content.trim()) {
      throw new AppError(
        ERROR_CODES.AI_PROVIDER_ERROR,
        'The AI provider returned an empty answer. You were not charged.',
      );
    }

    const assistantMessage = await prisma.message.create({
      data: {
        conversationId,
        role: 'ASSISTANT',
        content,
        model: result.model,
        cost,
        requestId: request.id,
      },
    });

    await prisma.aiRequest.update({
      where: { id: request.id },
      data: {
        status: 'SUCCEEDED',
        completionChars: content.length,
        durationMs: Date.now() - started,
        finishReason: result.finishReason,
        completedAt: new Date(),
      },
    });

    await prisma.conversation.update({
      where: { id: conversationId },
      data: { updatedAt: new Date(), model: result.model },
    });

    send({
      event: STREAM_EVENTS.DONE,
      conversationId,
      assistantMessageId: assistantMessage.id,
      model: result.model,
      creditsRemaining,
      finishReason: result.finishReason,
      durationMs: result.durationMs,
    });
    onDone(assistantMessage, creditsRemaining);
  } catch (err) {
    const aborted = controller.signal.aborted || (err instanceof AppError && err.code === ERROR_CODES.ABORTED);
    const appError = err instanceof AppError ? err : new AppError(ERROR_CODES.AI_PROVIDER_ERROR);

    // 3. Refund — the user got no answer.
    let balance = creditsRemaining;
    let refunded = false;
    try {
      balance = await creditService.refundChat(
        userId,
        request.id,
        `Refund: ${aborted ? 'request cancelled' : 'AI request failed'}`,
      );
      refunded = true;
    } catch (refundErr) {
      logger.error('credit refund failed', { requestId: request.id, error: String(refundErr) });
    }

    await prisma.aiRequest
      .update({
        where: { id: request.id },
        data: {
          status: aborted ? 'ABORTED' : 'FAILED',
          errorCode: appError.code,
          durationMs: Date.now() - started,
          completedAt: new Date(),
          completionChars: content.length,
        },
      })
      .catch(() => undefined);

    if (aborted) {
      send({
        event: STREAM_EVENTS.ABORTED,
        message: 'Generation stopped. Your credit was refunded.',
        refunded,
        creditsRemaining: balance,
      });
      onAborted(balance, refunded);
    } else {
      logger.warn('ai request failed', { requestId: request.id, code: appError.code });
      send({
        event: STREAM_EVENTS.ERROR,
        code: appError.code,
        message: appError.message,
        refunded,
        creditsRemaining: balance,
      });
      onError(appError, balance, refunded);
    }
  } finally {
    res.req.off('aborted', onClientDisconnect);
    if (!res.writableEnded) res.end();
  }
}

export async function streamChat(req: Request, res: Response): Promise<void> {
  const { conversationId: maybeId, message, model: requestedModel } = req.body as ChatRequestInput;
  const userId = req.auth!.userId;
  const model = resolveModel(requestedModel);

  let conversationId = maybeId;
  if (conversationId) {
    const owned = await prisma.conversation.findFirst({
      where: { id: conversationId, userId },
      select: { id: true },
    });
    if (!owned) throw new AppError(ERROR_CODES.NOT_FOUND, 'Conversation not found.');
  } else {
    const created = await prisma.conversation.create({
      data: { userId, title: titleFrom(message), model },
      select: { id: true },
    });
    conversationId = created.id;
  }

  await prisma.message.create({
    data: { conversationId, role: 'USER', content: message },
  });

  const history = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
    take: MAX_HISTORY_MESSAGES + 1,
  });

  await runCompletion(res, {
    conversationId,
    model,
    history,
    onDone: () => undefined,
    onError: () => undefined,
    onAborted: () => undefined,
  });
}

/** Regenerates the assistant reply for a given user message. */
export async function regenerate(req: Request, res: Response): Promise<void> {
  const { conversationId, messageId, model: requestedModel } = req.body as RegenerateInput;
  const userId = req.auth!.userId;
  const model = resolveModel(requestedModel);

  const conversation = await prisma.conversation.findFirst({
    where: { id: conversationId, userId },
    select: { id: true },
  });
  if (!conversation) throw new AppError(ERROR_CODES.NOT_FOUND, 'Conversation not found.');

  const target = await prisma.message.findFirst({
    where: { id: messageId, conversationId, role: 'USER' },
    select: { id: true, createdAt: true },
  });
  if (!target) throw new AppError(ERROR_CODES.NOT_FOUND, 'Message not found.');

  // Drop the previous answer and anything after it, then replay.
  await prisma.message.deleteMany({
    where: { conversationId, createdAt: { gt: target.createdAt } },
  });

  const history = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
    take: MAX_HISTORY_MESSAGES + 1,
  });

  await runCompletion(res, {
    conversationId,
    model,
    history,
    onDone: () => undefined,
    onError: () => undefined,
    onAborted: () => undefined,
  });
}

/** Non-streaming variant used by integrations and simple clients. */
export async function chatOnce(req: Request, res: Response): Promise<void> {
  const { conversationId: maybeId, message, model: requestedModel } = req.body as ChatRequestInput;
  const userId = req.auth!.userId;
  const model = resolveModel(requestedModel);

  await creditService.assertCanAfford(userId, env.CHAT_COST_CREDITS);

  let conversationId = maybeId;
  if (conversationId) {
    const owned = await prisma.conversation.findFirst({
      where: { id: conversationId, userId },
      select: { id: true },
    });
    if (!owned) throw new AppError(ERROR_CODES.NOT_FOUND, 'Conversation not found.');
  } else {
    const created = await prisma.conversation.create({
      data: { userId, title: titleFrom(message), model },
      select: { id: true },
    });
    conversationId = created.id;
  }

  const request = await prisma.aiRequest.create({
    data: {
      userId,
      conversationId,
      model,
      status: 'PENDING',
      promptChars: message.length,
      chargedCredits: env.CHAT_COST_CREDITS,
    },
    select: { id: true },
  });

  const userMessage = await prisma.message.create({
    data: { conversationId, role: 'USER', content: message },
  });

  const history = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: 'asc' },
    take: MAX_HISTORY_MESSAGES + 1,
  });

  let creditsRemaining: number;
  try {
    creditsRemaining = await creditService.chargeChat(userId, `AI request (${model})`);
  } catch (err) {
    await prisma.aiRequest
      .update({
        where: { id: request.id },
        data: { status: 'FAILED', completedAt: new Date(), errorCode: 'CHARGE_FAILED' },
      })
      .catch(() => undefined);
    throw err;
  }

  try {
    const result = await openRouterService.complete({ model, messages: buildContext(history) });

    const assistantMessage = await prisma.message.create({
      data: {
        conversationId,
        role: 'ASSISTANT',
        content: result.content,
        model: result.model,
        cost: env.CHAT_COST_CREDITS,
        requestId: request.id,
      },
    });

    await prisma.aiRequest.update({
      where: { id: request.id },
      data: {
        status: 'SUCCEEDED',
        completionChars: result.content.length,
        durationMs: result.durationMs,
        finishReason: result.finishReason,
        completedAt: new Date(),
      },
    });

    res.json({
      success: true,
      data: {
        conversationId,
        userMessage: toMessageDTO(userMessage),
        assistantMessage: toMessageDTO(assistantMessage),
        creditsRemaining,
        model: result.model,
      },
    });
  } catch (err) {
    const appError = err instanceof AppError ? err : new AppError(ERROR_CODES.AI_PROVIDER_ERROR);
    let balance = creditsRemaining;
    try {
      balance = await creditService.refundChat(
        userId,
        request.id,
        'Refund: AI request failed',
      );
    } catch (refundErr) {
      logger.error('credit refund failed', { requestId: request.id, error: String(refundErr) });
    }
    logger.info('ai request failed and refunded', {
      requestId: request.id,
      code: appError.code,
      creditsRemaining: balance,
    });
    await prisma.aiRequest
      .update({
        where: { id: request.id },
        data: {
          status: 'FAILED',
          errorCode: appError.code,
          completedAt: new Date(),
        },
      })
      .catch(() => undefined);

    throw new AppError(appError.code, appError.message, undefined, appError.status);
  }
}

export async function listModels(_req: Request, res: Response): Promise<void> {
  res.json({
    success: true,
    data: {
      models: env.allowedModels.map((id) => ({
        id,
        label: id,
        isDefault: id === env.OPENROUTER_MODEL,
      })),
      defaultModel: env.OPENROUTER_MODEL,
    },
  });
}
