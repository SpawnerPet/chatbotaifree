import { config as loadDotenv } from 'dotenv';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';

const here = path.dirname(fileURLToPath(import.meta.url));
/** apps/api — works both from `src/` (tsx) and `dist/` (node). */
export const API_ROOT = path.resolve(here, '..', '..');
export const REPO_ROOT = path.resolve(API_ROOT, '..', '..');

// Root .env first, then apps/api/.env so per-app overrides still work.
loadDotenv({ path: path.join(REPO_ROOT, '.env') });
loadDotenv({ path: path.join(API_ROOT, '.env'), override: true });

const bool = (def: boolean) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === '' ? def : ['1', 'true', 'yes', 'on'].includes(v.toLowerCase())));

const int = (def: number, min: number, max: number) =>
  z
    .string()
    .optional()
    .transform((v) => (v === undefined || v === '' ? def : Number(v)))
    .pipe(z.number().int().min(min).max(max));

const schema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: int(4000, 1, 65535),
  LOG_LEVEL: z.enum(['silent', 'error', 'warn', 'info', 'debug']).default('info'),

  API_URL: z.string().default('http://localhost:4000'),
  WEB_URL: z.string().default('http://localhost:5173'),
  CORS_EXTRA_ORIGINS: z.string().default(''),

  DATABASE_URL: z.string().min(1, 'DATABASE_URL is required.'),

  SESSION_SECRET: z.string().min(16, 'SESSION_SECRET must be at least 16 characters.'),
  CSRF_SECRET: z.string().min(16, 'CSRF_SECRET must be at least 16 characters.'),
  SESSION_TTL_DAYS: int(14, 1, 365),
  PASSWORD_RESET_TTL_MINUTES: int(30, 5, 1440),

  OPENROUTER_API_KEY: z.string().default(''),
  /**
   * Optional pool of extra keys, comma separated. When the primary key is
   * rate limited, out of quota or rejected, the service automatically falls
   * back to the next healthy key instead of failing the user's request.
   */
  OPENROUTER_API_KEYS: z.string().default(''),
  /** How long a key is benched after a 429/402 before it is retried. */
  OPENROUTER_KEY_COOLDOWN_SECONDS: int(300, 10, 86_400),
  /** Consecutive failures after which a key is parked for the process lifetime. */
  OPENROUTER_KEY_MAX_FAILURES: int(3, 1, 20),
  OPENROUTER_MODEL: z.string().default('openrouter/free'),
  OPENROUTER_BASE_URL: z.string().default('https://openrouter.ai/api/v1'),
  OPENROUTER_TIMEOUT_MS: int(120_000, 1_000, 600_000),
  OPENROUTER_STREAM_TIMEOUT_MS: int(180_000, 1_000, 900_000),
  OPENROUTER_MAX_RETRIES: int(2, 0, 5),
  OPENROUTER_ALLOWED_MODELS: z.string().default(''),

  SIGNUP_BONUS_CREDITS: int(100, 0, 1_000_000),
  CHAT_COST_CREDITS: int(1, 0, 1_000),

  ADMIN_EMAIL: z.string().default(''),
  ADMIN_PASSWORD: z.string().default(''),
  ADMIN_USERNAME: z.string().default('admin'),

  STORAGE_PROVIDER: z.enum(['local', 's3']).default('local'),
  STORAGE_LOCAL_DIR: z.string().default('var/uploads'),
  STORAGE_PUBLIC_BASE_URL: z.string().default(''),

  S3_ENDPOINT: z.string().default(''),
  S3_REGION: z.string().default('auto'),
  S3_BUCKET: z.string().default(''),
  S3_ACCESS_KEY_ID: z.string().default(''),
  S3_SECRET_ACCESS_KEY: z.string().default(''),
  S3_FORCE_PATH_STYLE: bool(true),

  MAX_IMAGE_UPLOAD_BYTES: int(5 * 1024 * 1024, 1024, 100 * 1024 * 1024),
  MAX_VIDEO_UPLOAD_BYTES: int(25 * 1024 * 1024, 1024, 500 * 1024 * 1024),
  MAX_AUDIO_UPLOAD_BYTES: int(10 * 1024 * 1024, 1024, 200 * 1024 * 1024),
});

const parsed = schema.safeParse(process.env);

if (!parsed.success) {
  const issues = parsed.error.issues
    .map((i) => `  • ${i.path.join('.') || '(root)'}: ${i.message}`)
    .join('\n');
  // Deliberately prints only variable NAMES, never values.
  throw new Error(`Invalid environment configuration:\n${issues}`);
}

const raw = parsed.data;

const isProd = raw.NODE_ENV === 'production';

const extraOrigins = raw.CORS_EXTRA_ORIGINS.split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const allowedModels = raw.OPENROUTER_ALLOWED_MODELS.split(',')
  .map((s) => s.trim())
  .filter(Boolean);

const models = allowedModels.length > 0 ? allowedModels : [raw.OPENROUTER_MODEL];

/**
 * Effective key pool: the primary key first, then any extras, de-duplicated and
 * never empty. Order matters — it is the rotation order.
 */
const keyPool = Array.from(
  new Set(
    [raw.OPENROUTER_API_KEY, ...raw.OPENROUTER_API_KEYS.split(',')]
      .map((k) => k.trim())
      .filter((k) => k.length > 0),
  ),
);

export const env = {
  ...raw,
  isProd,
  isTest: raw.NODE_ENV === 'test',
  corsOrigins: [raw.WEB_URL, ...extraOrigins].filter(Boolean),
  allowedModels: Array.from(new Set([raw.OPENROUTER_MODEL, ...models])),
  openRouterKeyPool: keyPool,
  storageLocalPath: path.isAbsolute(raw.STORAGE_LOCAL_DIR)
    ? raw.STORAGE_LOCAL_DIR
    : path.join(API_ROOT, raw.STORAGE_LOCAL_DIR),
  storagePublicBaseUrl:
    raw.STORAGE_PUBLIC_BASE_URL || `${raw.API_URL.replace(/\/+$/, '')}/media`,
  maxBodyJsonBytes: '1mb',
} as const;

export type Env = typeof env;

/** Never include secrets in this object. Used by /api/health. */
export function publicEnvSummary() {
  return {
    nodeEnv: env.NODE_ENV,
    port: env.PORT,
    aiProvider: 'openrouter',
    model: env.OPENROUTER_MODEL,
    aiConfigured: env.openRouterKeyPool.length > 0,
    aiKeyCount: env.openRouterKeyPool.length,
    storageProvider: env.STORAGE_PROVIDER,
    allowedModels: env.allowedModels,
    chatCostCredits: env.CHAT_COST_CREDITS,
    signupBonusCredits: env.SIGNUP_BONUS_CREDITS,
  };
}
