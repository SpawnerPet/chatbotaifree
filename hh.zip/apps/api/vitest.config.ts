import { defineConfig } from 'vitest/config';

const TEST_DATABASE_URL =
  process.env.TEST_DATABASE_URL ??
  'postgresql://orbit:orbit_dev_pw@127.0.0.1:5432/orbit_test?schema=public';

export default defineConfig({
  test: {
    environment: 'node',
    globalSetup: ['./test/global-setup.ts'],
    setupFiles: ['./test/setup.ts'],
    include: ['test/**/*.test.ts'],

    /**
     * `test.env` is applied by the worker BEFORE any module in src/ is
     * imported. That matters: config/env.ts validates process.env exactly once
     * at module load, and ESM hoists imports above top-level statements — so
     * assigning process.env inside a setup file would be too late and the suite
     * would silently run against the development database.
     */
    env: {
      NODE_ENV: 'test',
      LOG_LEVEL: 'silent',
      DATABASE_URL: TEST_DATABASE_URL,
      TEST_DATABASE_URL,
      SESSION_SECRET: 'test-session-secret-0123456789abcdefghij',
      CSRF_SECRET: 'test-csrf-secret-0123456789abcdefghijklmno',
      OPENROUTER_API_KEY: 'sk-or-v1-test-key-not-a-real-credential',
      OPENROUTER_BASE_URL: 'http://127.0.0.1:4599/v1',
      OPENROUTER_MODEL: 'openrouter/free',
      OPENROUTER_ALLOWED_MODELS: 'openrouter/free',
      OPENROUTER_MAX_RETRIES: '1',
      OPENROUTER_TIMEOUT_MS: '4000',
      OPENROUTER_STREAM_TIMEOUT_MS: '4000',
      SIGNUP_BONUS_CREDITS: '100',
      CHAT_COST_CREDITS: '1',
      STORAGE_PROVIDER: 'local',
      STORAGE_LOCAL_DIR: 'var/test-uploads',
      WEB_URL: 'http://localhost:5173',
      API_URL: 'http://localhost:4000',
    },

    // The mock provider and the shared Prisma client are module-level
    // singletons, so files must run sequentially in a single process.
    fileParallelism: false,
    pool: 'forks',
    poolOptions: { forks: { singleFork: true } },
    testTimeout: 30_000,
    hookTimeout: 60_000,
    teardownTimeout: 15_000,
  },
});
