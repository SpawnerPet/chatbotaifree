#!/usr/bin/env node
/**
 * Runs a command with the root .env loaded into process.env.
 *
 * Prisma (and most CLIs) only look for .env next to themselves, while this
 * project keeps a single source of truth at the repository root. This wrapper
 * removes the need to duplicate DATABASE_URL — and therefore secrets — into
 * apps/api/.env.
 *
 * Usage: node scripts/with-env.mjs <command> [args...]
 *   node scripts/with-env.mjs prisma migrate dev
 *   node scripts/with-env.mjs npx tsx prisma/seed.ts
 */
import { spawn } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const apiRoot = path.resolve(here, '..');
const rootEnv = path.resolve(apiRoot, '..', '..', '.env');
const localEnv = path.join(apiRoot, '.env');

/** Minimal .env parser — no dependency, no interpolation, no expansion. */
function parseEnvFile(file) {
  if (!existsSync(file)) return {};
  const out = {};
  for (const rawLine of readFileSync(file, 'utf8').split('\n')) {
    const line = rawLine.trim();
    if (line.length === 0 || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    if (
      (value.startsWith('"') && value.endsWith('"')) ||
      (value.startsWith("'") && value.endsWith("'"))
    ) {
      value = value.slice(1, -1);
    }
    out[key] = value;
  }
  return out;
}

const [command, ...args] = process.argv.slice(2);
if (!command) {
  console.error('Usage: node scripts/with-env.mjs <command> [args...]');
  process.exit(1);
}

// Real environment variables always win over .env files.
const env = { ...parseEnvFile(rootEnv), ...parseEnvFile(localEnv), ...process.env };

const child = spawn(command, args, { stdio: 'inherit', env, shell: process.platform === 'win32' });
child.on('error', (err) => {
  console.error(`Failed to start "${command}":`, err.message);
  process.exit(1);
});
child.on('exit', (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  else process.exit(code ?? 0);
});
