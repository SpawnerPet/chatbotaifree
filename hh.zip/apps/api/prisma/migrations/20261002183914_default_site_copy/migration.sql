-- AlterTable
ALTER TABLE "site_settings" ALTER COLUMN "landingDescription" SET DEFAULT 'Orbit is a focused chat workspace: real streaming answers, code you can copy, and a history that stays yours.',
ALTER COLUMN "chatWelcomeMessage" SET DEFAULT 'Ask anything. I will keep it focused, and show my work.',
ALTER COLUMN "chatEmptyPrompts" SET DEFAULT '["Explain a hard concept with a concrete analogy.", "Review this code and point out what would break first.", "Help me turn a rough idea into a plan I can actually follow."]';
