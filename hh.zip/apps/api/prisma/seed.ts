/**
 * Idempotent bootstrap.
 *
 * - Creates the singleton settings row with shipped defaults.
 * - Creates/updates the admin account from ADMIN_EMAIL / ADMIN_PASSWORD.
 *   No credential is ever hard-coded: if those variables are absent and no
 *   admin exists, the script explains how to promote an account instead.
 */
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { env } from '../src/config/env.js';
import {
  DEFAULT_CHAT_PROMPTS,
  DEFAULT_LANDING_DESCRIPTION_TEXT as DEFAULT_LANDING_DESCRIPTION,
  DEFAULT_CHAT_WELCOME_TEXT as DEFAULT_CHAT_WELCOME,
} from '../src/services/settings.service.js';

const prisma = new PrismaClient();

function isWeakEnough(value: string): boolean {
  return value.length < 12;
}

async function main(): Promise<void> {
  // upsert + a backfill: a row created by an older build may be missing copy
  // that now ships as a column default.
  const settings = await prisma.siteSettings.upsert({
    where: { id: 'default' },
    update: {},
    create: { id: 'default', chatEmptyPrompts: DEFAULT_CHAT_PROMPTS },
  });
  const backfill: Record<string, unknown> = {};
  if (settings.landingDescription.trim().length === 0) {
    backfill.landingDescription = DEFAULT_LANDING_DESCRIPTION;
  }
  if (settings.chatWelcomeMessage.trim().length === 0) {
    backfill.chatWelcomeMessage = DEFAULT_CHAT_WELCOME;
  }
  const prompts = settings.chatEmptyPrompts;
  const promptsEmpty =
    Array.isArray(prompts) ? prompts.length === 0 : String(prompts ?? '').trim() === '' ||
      String(prompts).trim() === '[]';
  if (promptsEmpty) backfill.chatEmptyPrompts = DEFAULT_CHAT_PROMPTS;
  if (Object.keys(backfill).length > 0) {
    await prisma.siteSettings.update({ where: { id: 'default' }, data: backfill });
    console.log('✓ filled in empty site copy from the shipped defaults');
  }
  console.log('✓ site settings ready');

  const email = env.ADMIN_EMAIL.trim().toLowerCase();
  const password = env.ADMIN_PASSWORD;
  const username = env.ADMIN_USERNAME.trim() || 'admin';

  const existingAdminCount = await prisma.user.count({ where: { role: 'ADMIN' } });

  if (!email || !password) {
    if (existingAdminCount > 0) {
      console.log('• ADMIN_EMAIL / ADMIN_PASSWORD not set — an administrator already exists.');
    } else {
      console.log(
        [
          '',
          '⚠  No administrator exists yet.',
          '   Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ characters) in your .env and re-run:',
          '       npm run db:seed',
          '   Alternatively, register the first account — it is promoted to ADMIN automatically.',
          '',
        ].join('\n'),
      );
    }
    return;
  }

  if (isWeakEnough(password)) {
    throw new Error('ADMIN_PASSWORD must be at least 12 characters long.');
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const user = await prisma.user.upsert({
    where: { emailLower: email },
    update: { role: 'ADMIN', status: 'ACTIVE', passwordHash },
    create: {
      email,
      emailLower: email,
      username,
      passwordHash,
      role: 'ADMIN',
      status: 'ACTIVE',
      credits: env.SIGNUP_BONUS_CREDITS,
    },
    select: { id: true, email: true, role: true },
  });

  await prisma.creditTransaction.create({
    data: {
      userId: user.id,
      amount: env.SIGNUP_BONUS_CREDITS,
      type: 'BONUS',
      balanceBefore: 0,
      balanceAfter: env.SIGNUP_BONUS_CREDITS,
      description: 'Administrator bootstrap credits',
    },
  });

  console.log(`✓ administrator ready: ${user.email} (${user.role})`);
}

main()
  .catch((err) => {
    console.error('✗ seed failed:', err instanceof Error ? err.message : err);
    process.exitCode = 1;
  })
  .finally(() => {
    void prisma.$disconnect();
  });
