import type { UserDTO } from '@orbit/shared';
import { createContext } from 'react';

export interface AuthContextValue {
  user: UserDTO | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login(email: string, password: string): Promise<UserDTO>;
  register(email: string, username: string, password: string): Promise<UserDTO>;
  logout(): Promise<void>;
  refresh(): Promise<void>;
  setUser(user: UserDTO | null): void;
  /** Credit balance kept in sync with the server after each chat turn. */
  credits: number;
  setCredits(credits: number): void;
}

export const AuthContext = createContext<AuthContextValue | null>(null);
