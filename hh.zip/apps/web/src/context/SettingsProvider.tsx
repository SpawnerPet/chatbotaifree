import type { PublicSettings } from '@orbit/shared';
import { useQuery } from '@tanstack/react-query';
import { useEffect, useMemo, type ReactNode } from 'react';
import { api, assetUrl } from '../lib/api';
import {
  SettingsContext,
  THEME_STORAGE_KEY,
  type SettingsContextValue,
} from './SettingsContext';

const FALLBACK: PublicSettings = {
  siteName: 'Orbit AI',
  siteTagline: 'A calm place to think with a model.',
  logoUrl: '',
  faviconUrl: '',
  loginTitle: 'Welcome back',
  loginSubtitle: 'Sign in to continue your conversations.',
  landingTitle: 'A quieter way to work with an AI.',
  landingDescription:
    'Orbit is a focused chat workspace: real streaming answers, code you can copy, and a history that stays yours.',
  primaryCtaText: 'Start chatting',
  secondaryCtaText: 'Sign in',
  footerText: '',
  chatWelcomeMessage: 'Ask anything. I will keep it focused, and show my work.',
  chatEmptyPrompts: [],
  accentColor: '#c96442',
  backgroundColor: '#12110f',
  textColor: '#ecebe7',
  borderColor: '#2a2825',
  buttonStyle: 'solid',
  fontChoice: 'inter',
  defaultTheme: 'dark',
  backgroundType: 'STATIC_COLOR',
  backgroundMediaId: null,
  backgroundUrl: null,
  backgroundPosterUrl: null,
  backgroundOverlayOpacity: 0,
  backgroundParallax: false,
  musicEnabled: false,
  musicUrl: '',
  musicVolume: 0.35,
  musicAutoplay: false,
  supportEmail: '',
  customCss: '',
  updatedAt: new Date(0).toISOString(),
};



/** Maps the admin's font choice onto a real font stack. */
function fontStack(choice: PublicSettings['fontChoice']): string {
  switch (choice) {
    case 'serif':
      return "'Newsreader', ui-serif, Georgia, Cambria, 'Times New Roman', serif";
    case 'mono':
      return "'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace";
    case 'grotesk':
      return "'Inter Tight', 'Inter', ui-sans-serif, system-ui, sans-serif";
    case 'system':
      return "ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
    case 'inter':
    default:
      return "'Inter', ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif";
  }
}



export function SettingsProvider({ children }: { children: ReactNode }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['settings'],
    queryFn: () => api<PublicSettings>('/settings'),
    staleTime: 60_000,
    retry: 1,
  });

  const settings = useMemo(() => (data ?? FALLBACK), [data]);

  // Apply the admin's branding to the document as CSS custom properties.
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--orbit-accent', settings.accentColor);
    root.style.setProperty('--orbit-bg', settings.backgroundColor);
    root.style.setProperty('--orbit-fg', settings.textColor);
    root.style.setProperty('--orbit-border', settings.borderColor);
    root.style.setProperty('--orbit-overlay', String(settings.backgroundOverlayOpacity));
    root.style.setProperty('--orbit-font', fontStack(settings.fontChoice));
    root.style.fontFamily = 'var(--orbit-font)';

    const favicon = assetUrl(settings.faviconUrl);
    if (favicon) {
      let link = document.getElementById('app-favicon') as HTMLLinkElement | null;
      if (!link) {
        link = document.createElement('link');
        link.id = 'app-favicon';
        link.rel = 'icon';
        document.head.appendChild(link);
      }
      link.href = favicon;
    }
    document.title = settings.siteName;
  }, [settings]);

  // Admin-configured CSS, injected last so it can win over the design system.
  useEffect(() => {
    const id = 'orbit-custom-css';
    document.getElementById(id)?.remove();
    if (settings.customCss.trim().length === 0) return;
    const style = document.createElement('style');
    style.id = id;
    style.textContent = settings.customCss;
    document.head.appendChild(style);
    return () => {
      document.getElementById(id)?.remove();
    };
  }, [settings.customCss]);

  // Dark / light / system.
  useEffect(() => {
    const root = document.documentElement;
    const stored = localStorage.getItem(THEME_STORAGE_KEY);
    const mode = stored ?? settings.defaultTheme;
    const media = window.matchMedia('(prefers-color-scheme: light)');

    const apply = () => {
      const resolved = mode === 'system' ? (media.matches ? 'light' : 'dark') : mode;
      root.dataset.theme = resolved;
      root.classList.toggle('dark', resolved === 'dark');
    };

    apply();
    media.addEventListener('change', apply);
    return () => media.removeEventListener('change', apply);
  }, [settings.defaultTheme]);

  const value = useMemo<SettingsContextValue>(
    () => ({
      settings,
      isLoading,
      isError,
      logo: assetUrl(settings.logoUrl),
      favicon: assetUrl(settings.faviconUrl),
      background:
        settings.backgroundType === 'STATIC_COLOR' ? null : assetUrl(settings.backgroundUrl),
      music: settings.musicEnabled ? assetUrl(settings.musicUrl) : null,
    }),
    [settings, isLoading, isError],
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}


export { FALLBACK as FALLBACK_SETTINGS };
