import type { PublicSettings } from '@orbit/shared';
import { createContext } from 'react';

export interface SettingsContextValue {
  settings: PublicSettings;
  isLoading: boolean;
  isError: boolean;
  logo: string | null;
  favicon: string | null;
  background: string | null;
  music: string | null;
}

export const SettingsContext = createContext<SettingsContextValue | null>(null);

/** localStorage key for the visitor's explicit theme choice. */
export const THEME_STORAGE_KEY = 'orbit.theme';
