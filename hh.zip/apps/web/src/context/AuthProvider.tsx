import type { UserDTO } from '@orbit/shared';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useMemo, type ReactNode } from 'react';
import { api, ApiError } from '../lib/api';
import { AuthContext, type AuthContextValue } from './AuthContext';

/**
 * Session state for the whole app.
 *
 * The session itself lives in an httpOnly cookie the browser sends
 * automatically; React only caches the resulting profile.
 */
export function AuthProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => api<UserDTO>('/auth/me'),
    retry: false,
    staleTime: 30_000,
  });

  const setUser = useCallback(
    (user: UserDTO | null) => {
      queryClient.setQueryData(['me'], user);
    },
    [queryClient],
  );

  const loginMutation = useMutation({
    mutationFn: (input: { email: string; password: string }) =>
      api<UserDTO>('/auth/login', { method: 'POST', body: input }),
  });

  const registerMutation = useMutation({
    mutationFn: (input: { email: string; username: string; password: string }) =>
      api<UserDTO>('/auth/register', { method: 'POST', body: input }),
  });

  const login = useCallback(
    async (email: string, password: string) => {
      const user = await loginMutation.mutateAsync({ email, password });
      setUser(user);
      return user;
    },
    [loginMutation, setUser],
  );

  const register = useCallback(
    async (email: string, username: string, password: string) => {
      const user = await registerMutation.mutateAsync({ email, username, password });
      setUser(user);
      return user;
    },
    [registerMutation, setUser],
  );

  const logout = useCallback(async () => {
    try {
      await api<unknown>('/auth/logout', { method: 'POST' });
    } catch (err) {
      // A failed logout should still clear the client state.
      if (!(err instanceof ApiError)) throw err;
    }
    setUser(null);
    queryClient.clear();
  }, [setUser, queryClient]);

  const refresh = useCallback(async () => {
    await queryClient.invalidateQueries({ queryKey: ['me'] });
  }, [queryClient]);

  const value = useMemo<AuthContextValue>(() => {
    const user = data ?? null;
    return {
      user,
      isLoading,
      isAuthenticated: Boolean(user),
      isAdmin: user?.role === 'ADMIN',
      login,
      register,
      logout,
      refresh,
      setUser,
      credits: user?.credits ?? 0,
      setCredits(credits: number) {
        queryClient.setQueryData<UserDTO>(['me'], (prev) =>
          prev ? { ...prev, credits } : prev,
        );
      },
    };
  }, [data, isLoading, login, register, logout, refresh, setUser, queryClient]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
