import { createContext } from 'react';

export type ToastKind = 'success' | 'error' | 'info';

export interface ToastContextValue {
  toast(input: { kind?: ToastKind; title: string; description?: string }): void;
  success(title: string, description?: string): void;
  error(title: string, description?: string): void;
  info(title: string, description?: string): void;
}

export const ToastContext = createContext<ToastContextValue | null>(null);
