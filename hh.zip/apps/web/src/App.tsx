import { Suspense, lazy, type ReactNode } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { BackgroundLayer } from './components/layout/BackgroundLayer';
import { ErrorBoundary } from './components/ui/ErrorBoundary';
import { Spinner } from './components/ui';
import { AuthProvider } from './context/AuthProvider';
import { useAuth } from './hooks/useAuth';
import { SettingsProvider } from './context/SettingsProvider';
import { ToastProvider } from './context/ToastProvider';
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { ChatPage } from './pages/ChatPage';
import { AdminLayout } from './pages/admin/AdminLayout';

// Admin screens are split out of the main bundle: most visitors never load them.
const SettingsPage = lazy(() =>
  import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })),
);
const AdminDashboardPage = lazy(() =>
  import('./pages/admin/AdminDashboardPage').then((m) => ({ default: m.AdminDashboardPage })),
);
const AdminUsersPage = lazy(() =>
  import('./pages/admin/AdminUsersPage').then((m) => ({ default: m.AdminUsersPage })),
);
const AdminUserDetailPage = lazy(() =>
  import('./pages/admin/AdminUsersPage').then((m) => ({ default: m.AdminUserDetailPage })),
);
const AdminMediaPage = lazy(() =>
  import('./pages/admin/AdminMediaPage').then((m) => ({ default: m.AdminMediaPage })),
);
const AdminCustomizationPage = lazy(() =>
  import('./pages/admin/AdminCustomizationPage').then((m) => ({
    default: m.AdminCustomizationPage,
  })),
);
const AdminAuditPage = lazy(() =>
  import('./pages/admin/AdminAuditPage').then((m) => ({ default: m.AdminAuditPage })),
);

function FullPageLoader() {
  return (
    <div className="flex min-h-full items-center justify-center p-8">
      <Spinner label="Loading…" />
    </div>
  );
}

/** Blocks a route until the session is known, then enforces the requirement. */
function Protected({ children, adminOnly = false }: { children: ReactNode; adminOnly?: boolean }) {
  const { isLoading, isAuthenticated, isAdmin } = useAuth();
  const location = useLocation();

  if (isLoading) return <FullPageLoader />;

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location.pathname + location.search }} />;
  }
  if (adminOnly && !isAdmin) {
    return <Navigate to="/chat" replace />;
  }
  return <>{children}</>;
}

function GuestOnly({ children }: { children: ReactNode }) {
  const { isLoading, isAuthenticated } = useAuth();
  if (isLoading) return <FullPageLoader />;
  if (isAuthenticated) return <Navigate to="/chat" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <ErrorBoundary resetKey="/">
            <LandingPage />
          </ErrorBoundary>
        }
      />
      <Route
        path="/login"
        element={
          <ErrorBoundary resetKey="/login">
            <GuestOnly>
              <LoginPage />
            </GuestOnly>
          </ErrorBoundary>
        }
      />
      <Route
        path="/register"
        element={
          <ErrorBoundary resetKey="/register">
            <GuestOnly>
              <RegisterPage />
            </GuestOnly>
          </ErrorBoundary>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <ErrorBoundary resetKey="/forgot-password">
            <GuestOnly>
              <ForgotPasswordPage />
            </GuestOnly>
          </ErrorBoundary>
        }
      />
      <Route
        path="/reset-password"
        element={
          <ErrorBoundary resetKey="/reset-password">
            <ResetPasswordPage />
          </ErrorBoundary>
        }
      />
      <Route
        path="/privacy"
        element={
          <ErrorBoundary resetKey="/privacy">
            <LandingPage />
          </ErrorBoundary>
        }
      />

      <Route
        path="/chat"
        element={
          <Protected>
            <ErrorBoundary resetKey="/chat">
              <ChatPage />
            </ErrorBoundary>
          </Protected>
        }
      />
      <Route
        path="/chat/:id"
        element={
          <Protected>
            <ErrorBoundary resetKey="chat-detail">
              <ChatPage />
            </ErrorBoundary>
          </Protected>
        }
      />
      <Route
        path="/settings"
        element={
          <Protected>
            <ErrorBoundary resetKey="/settings">
              <Suspense fallback={<FullPageLoader />}>
                <SettingsPage />
              </Suspense>
            </ErrorBoundary>
          </Protected>
        }
      />

      <Route
        path="/admin"
        element={
          <Protected adminOnly>
            <ErrorBoundary resetKey="admin">
              <Suspense fallback={<FullPageLoader />}>
                <AdminLayout />
              </Suspense>
            </ErrorBoundary>
          </Protected>
        }
      >
        <Route
          index
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminDashboardPage />
            </Suspense>
          }
        />
        <Route
          path="users"
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminUsersPage />
            </Suspense>
          }
        />
        <Route
          path="users/:id"
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminUserDetailPage />
            </Suspense>
          }
        />
        <Route
          path="media"
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminMediaPage />
            </Suspense>
          }
        />
        <Route
          path="customization"
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminCustomizationPage />
            </Suspense>
          }
        />
        <Route
          path="audit"
          element={
            <Suspense fallback={<FullPageLoader />}>
              <AdminAuditPage />
            </Suspense>
          }
        />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <SettingsProvider>
          <ToastProvider>
            <AuthProvider>
              <BackgroundLayer />
              <a
                href="#main"
                className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-md focus:border focus:border-[var(--orbit-border)] focus:bg-[var(--orbit-surface)] focus:px-3 focus:py-2 focus:text-sm"
              >
                Skip to content
              </a>
              <div className="min-h-full">
                <AppRoutes />
              </div>
            </AuthProvider>
          </ToastProvider>
        </SettingsProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
