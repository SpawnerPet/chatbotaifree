import type { ApiFailure } from '@orbit/shared';

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.details = details;
  }

  get isAuthError(): boolean {
    return this.status === 401;
  }
}

/**
 * Base URL of the API. Empty string means "same origin", which is what the
 * production build uses (the SPA and the API are served from one host or
 * proxied). Vite proxies /api in development.
 */
const BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/+$/, '');

function readCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match?.[1] ? decodeURIComponent(match[1]) : null;
}

export const CSRF_COOKIE = 'orbit.csrf';

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  body?: unknown;
  signal?: AbortSignal;
  /** Set false for endpoints that are safe without CSRF (public POSTs). */
  csrf?: boolean;
  headers?: Record<string, string>;
}

const MUTATING = new Set(['POST', 'PATCH', 'PUT', 'DELETE']);

/**
 * Single entry point for every network call.
 *
 * - `credentials: 'include'` so the httpOnly session cookie travels.
 * - Echoes the double-submit CSRF token on mutating requests.
 * - Normalises the { success, data | error } envelope into data or ApiError.
 */
export async function api<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const method = options.method ?? 'GET';
  const headers: Record<string, string> = { Accept: 'application/json', ...options.headers };

  let body: BodyInit | undefined;
  if (options.body !== undefined) {
    if (options.body instanceof FormData) {
      body = options.body;
    } else if (options.body instanceof Blob) {
      // Raw uploads (media library): keep the caller's real Content-Type so
      // the server can validate the declared type against the file's bytes.
      body = options.body;
      headers['Content-Type'] ??= options.body.type || 'application/octet-stream';
    } else {
      // Default to JSON only when the caller did not set a type.
      headers['Content-Type'] ??= 'application/json';
      body = JSON.stringify(options.body);
    }
  }

  if (MUTATING.has(method) && options.csrf !== false) {
    const token = readCookie(CSRF_COOKIE);
    if (token) headers['X-CSRF-Token'] = token;
  }

  let response: Response;
  try {
    response = await fetch(`${BASE}/api${path}`, {
      method,
      headers,
      body,
      credentials: 'include',
      signal: options.signal,
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === 'AbortError') throw err;
    throw new ApiError(0, 'NETWORK_ERROR', 'Could not reach the server. Check your connection.');
  }

  if (response.status === 204) return undefined as T;

  const text = await response.text();
  let payload: unknown = null;
  if (text.length > 0) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!response.ok || !payload || (payload as { success?: boolean }).success !== true) {
    const failure = payload as ApiFailure | null;
    const error = failure?.error;
    throw new ApiError(
      response.status,
      error?.code ?? 'UNKNOWN',
      error?.message ?? `Request failed (${response.status}).`,
      error?.details,
    );
  }

  return (payload as { data: T }).data;
}

/** Absolute URL for a media/settings asset path. */
export function assetUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  if (/^https?:\/\//i.test(path)) return path;
  return `${BASE}${path.startsWith('/') ? '' : '/'}${path}`;
}
