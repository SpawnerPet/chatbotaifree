import { ArrowRight, Check, Copy, Gauge, Layers, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useSettings } from '../hooks/useSettings';
import { Logo } from '../components/layout/Logo';
import { MusicPlayer } from '../components/layout/MusicPlayer';
import { ThemeToggle } from '../components/layout/ThemeToggle';

const FEATURES = [
  {
    icon: Gauge,
    title: 'Answers that stream in',
    body: 'Tokens arrive as they are produced. Stop mid-sentence and nothing is half-charged.',
  },
  {
    icon: Copy,
    title: 'Code you can actually use',
    body: 'Every block is highlighted, labelled and one click from your clipboard.',
  },
  {
    icon: Layers,
    title: 'A history that stays yours',
    body: 'Search, rename, branch and delete. Nothing leaves your account without your say-so.',
  },
  {
    icon: ShieldCheck,
    title: 'Honest metering',
    body: 'Credits are charged per successful answer and refunded in full when a request fails.',
  },
];

const STEPS = [
  { title: 'Create an account', body: 'You start with a welcome balance of credits.' },
  { title: 'Ask a question', body: 'Pick a model, type, and watch it work.' },
  { title: 'Come back to it', body: 'Every conversation is saved and searchable.' },
];

function ChatPreview() {
  const [copied, setCopied] = useState(false);
  const snippet = `def fib(n: int) -> int:
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a`;

  return (
    <div className="card overflow-hidden">
      <div className="flex items-center gap-1.5 border-b border-[var(--orbit-border)] px-4 py-2.5">
        <span className="h-2.5 w-2.5 rounded-full bg-[var(--orbit-border)]" aria-hidden />
        <span className="h-2.5 w-2.5 rounded-full bg-[var(--orbit-border)]" aria-hidden />
        <span className="h-2.5 w-2.5 rounded-full bg-[var(--orbit-border)]" aria-hidden />
        <span className="orbit-faint ml-2 truncate text-xs">A quieter way to work</span>
      </div>

      <div className="space-y-4 p-4 sm:p-5">
        <div className="flex justify-end">
          <p className="orbit-surface-strong max-w-[80%] rounded-[var(--radius-lg)] rounded-tr-sm border border-[var(--orbit-border)] px-3.5 py-2 text-sm">
            Write me a fast Fibonacci in Python.
          </p>
        </div>

        <div className="flex gap-3">
          <span
            className="mt-1 h-6 w-6 shrink-0 rounded-full border border-[var(--orbit-border)]"
            aria-hidden
          >
            <span className="block h-2 w-2 translate-x-2 translate-y-2 rounded-full bg-[var(--orbit-accent)]" />
          </span>
          <div className="min-w-0 flex-1 space-y-2">
            <p className="text-sm leading-relaxed">
              Here is an iterative version — constant memory, no recursion limit:
            </p>
            <div className="code-block">
              <div className="flex items-center justify-between border-b border-[var(--orbit-border)] px-3 py-1.5">
                <span className="orbit-faint font-mono text-[11px] uppercase tracking-wider">
                  python
                </span>
                <button
                  type="button"
                  onClick={() => {
                    void navigator.clipboard?.writeText(snippet).catch(() => undefined);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 1800);
                  }}
                  className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1.5 text-xs"
                >
                  {copied ? <Check className="h-3.5 w-3.5" aria-hidden /> : <Copy className="h-3.5 w-3.5" aria-hidden />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <pre className="overflow-x-auto px-4 py-3">
                <code className="font-mono text-[13px] leading-relaxed">{snippet}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LandingPage() {
  const { settings } = useSettings();
  const { isAuthenticated, isAdmin } = useAuth();

  const primaryHref = isAuthenticated ? '/chat' : '/register';
  const secondaryHref = isAuthenticated ? '/settings' : '/login';

  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-30 border-b border-[var(--orbit-border)] bg-[color-mix(in_oklab,var(--orbit-bg)_86%,transparent)] backdrop-blur-sm">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-[var(--space-page)] py-3">
          <Logo />
          <div className="flex items-center gap-1.5">
            <MusicPlayer />
            <ThemeToggle />
            <Link to={secondaryHref} className="btn btn-ghost btn-sm hidden sm:inline-flex">
              {isAuthenticated ? 'Settings' : settings.secondaryCtaText || 'Sign in'}
            </Link>
            {!isAuthenticated && (
              <Link to="/register" className="btn btn-solid btn-sm">
                {settings.primaryCtaText}
              </Link>
            )}
            {isAuthenticated && (
              <Link to={primaryHref} className="btn btn-solid btn-sm">
                Open chat
              </Link>
            )}
          </div>
        </div>
      </header>

      <main id="main">
        {/* Hero ------------------------------------------------------- */}
        <section className="mx-auto max-w-6xl px-[var(--space-page)] pb-16 pt-16 sm:pb-24 sm:pt-24">
          <div className="max-w-2xl">
            <p className="orbit-faint text-sm font-medium uppercase tracking-[0.14em]">
              {settings.siteTagline}
            </p>
            <h1 className="mt-4 text-balance text-4xl leading-[1.08] sm:text-5xl lg:text-[3.4rem]">
              {settings.landingTitle}
            </h1>
            <p className="orbit-muted mt-5 max-w-xl text-pretty text-base leading-relaxed sm:text-lg">
              {settings.landingDescription}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to={primaryHref} className="btn btn-solid">
                {settings.primaryCtaText}
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
              {!isAuthenticated && (
                <Link to={secondaryHref} className="btn btn-outline">
                  {settings.secondaryCtaText || 'Sign in'}
                </Link>
              )}
              {isAdmin && (
                <Link to="/admin" className="btn btn-ghost">
                  Admin dashboard
                </Link>
              )}
            </div>
          </div>
        </section>

        {/* Chat preview ----------------------------------------------- */}
        <section className="mx-auto max-w-6xl px-[var(--space-page)] pb-16 sm:pb-24">
          <ChatPreview />
        </section>

        {/* Features --------------------------------------------------- */}
        <section className="border-t border-[var(--orbit-border)] py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-[var(--space-page)]">
            <h2 className="text-2xl sm:text-3xl">Built to stay out of the way</h2>
            <div className="mt-10 grid gap-x-8 gap-y-10 sm:grid-cols-2">
              {FEATURES.map((feature) => (
                <div key={feature.title} className="flex gap-3.5">
                  <span className="orbit-surface mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-md border border-[var(--orbit-border)]">
                    <feature.icon className="h-4 w-4" aria-hidden />
                  </span>
                  <div>
                    <h3 className="text-base font-medium">{feature.title}</h3>
                    <p className="orbit-muted mt-1 text-sm leading-relaxed">{feature.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works ----------------------------------------------- */}
        <section className="border-t border-[var(--orbit-border)] py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-[var(--space-page)]">
            <h2 className="text-2xl sm:text-3xl">How it works</h2>
            <ol className="mt-10 grid gap-8 sm:grid-cols-3">
              {STEPS.map((step, index) => (
                <li key={step.title}>
                  <span className="orbit-faint font-mono text-xs">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <h3 className="mt-2 text-base font-medium">{step.title}</h3>
                  <p className="orbit-muted mt-1 text-sm leading-relaxed">{step.body}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        {/* CTA -------------------------------------------------------- */}
        <section className="border-t border-[var(--orbit-border)] py-16 sm:py-24">
          <div className="mx-auto max-w-6xl px-[var(--space-page)]">
            <div className="card flex flex-col items-start justify-between gap-6 p-8 sm:flex-row sm:items-center sm:p-10">
              <div>
                <h2 className="text-2xl">Ready when you are</h2>
                <p className="orbit-muted mt-2 max-w-md text-sm leading-relaxed">
                  {settings.landingDescription}
                </p>
              </div>
              <Link to={primaryHref} className="btn btn-solid shrink-0">
                {settings.primaryCtaText}
                <ArrowRight className="h-4 w-4" aria-hidden />
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-[var(--orbit-border)]">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-[var(--space-page)] py-8 sm:flex-row">
          <Logo />
          <div className="orbit-faint flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-xs">
            {settings.footerText && <span>{settings.footerText}</span>}
            <Link to="/privacy" className="hover:text-[var(--orbit-fg)]">
              Privacy
            </Link>
            {settings.supportEmail && (
              <a href={`mailto:${settings.supportEmail}`} className="hover:text-[var(--orbit-fg)]">
                {settings.supportEmail}
              </a>
            )}
          </div>
        </div>
      </footer>
    </div>
  );
}
