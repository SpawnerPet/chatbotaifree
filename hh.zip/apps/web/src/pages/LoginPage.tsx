import { useState, type FormEvent } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useSettings } from '../hooks/useSettings';
import { useToast } from '../hooks/useToast';
import { Field, Input } from '../components/ui';
import { AuthForm, AuthLayout } from './AuthLayout';
import { useAuthError } from '../hooks/useAuthError';

export function LoginPage() {
  const { login } = useAuth();
  const { settings } = useSettings();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const toError = useAuthError();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const from = (location.state as { from?: string } | null)?.from ?? '/chat';

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const user = await login(email.trim(), password);
      toast.success(`Welcome back, ${user.username}`);
      navigate(user.role === 'ADMIN' && from === '/chat' ? '/chat' : from, { replace: true });
    } catch (err) {
      setError(toError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      title={settings.loginTitle}
      subtitle={settings.loginSubtitle}
      footer={
        <p>
          No account yet?{' '}
          <Link to="/register" className="text-[var(--orbit-accent)] hover:underline">
            Create one
          </Link>
        </p>
      }
    >
      <AuthForm onSubmit={submit} error={error} submitLabel="Sign in" loading={loading}>
        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
        </Field>

        <Field label="Password" htmlFor="password">
          <Input
            id="password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>

        <div className="flex justify-end">
          <Link
            to="/forgot-password"
            className="orbit-faint text-xs hover:text-[var(--orbit-fg)] hover:underline"
          >
            Forgot your password?
          </Link>
        </div>
      </AuthForm>
    </AuthLayout>
  );
}
