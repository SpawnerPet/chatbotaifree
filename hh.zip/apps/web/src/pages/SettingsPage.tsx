import { useQuery } from '@tanstack/react-query';
import type { CreditTransactionDTO, Paginated, SessionDTO, UserDTO } from '@orbit/shared';
import { KeyRound, LogOut, Monitor, Moon, Sun, Trash2, User as UserIcon } from 'lucide-react';
import { useCallback, useRef, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/layout/Logo';
import { MusicPlayer } from '../components/layout/MusicPlayer';
import { ThemeToggle } from '../components/layout/ThemeToggle';
import { Badge, Button, Card, EmptyState, Field, Input, Skeleton } from '../components/ui';
import { Modal } from '../components/ui/Modal';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { api } from '../lib/api';
import { THEME_STORAGE_KEY } from '../context/SettingsContext';
import { cn, formatDateTime, formatRelative, initials } from '../lib/utils';

type ThemeMode = 'system' | 'light' | 'dark';

export function SettingsPage() {
  const { user, setUser, logout, isAdmin } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const [theme, setTheme] = useState<ThemeMode>(
    () => (localStorage.getItem(THEME_STORAGE_KEY) as ThemeMode | null) ?? 'system',
  );
  const [username, setUsername] = useState(user?.username ?? '');
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar ?? '');
  const [savingProfile, setSavingProfile] = useState(false);

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [changingPassword, setChangingPassword] = useState(false);

  const [confirmRevoke, setConfirmRevoke] = useState<SessionDTO | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const creditsQuery = useQuery({
    queryKey: ['credits'],
    queryFn: () => api<Paginated<CreditTransactionDTO>>('/user/credits?page=1&pageSize=20'),
  });

  const usageQuery = useQuery({
    queryKey: ['usage'],
    queryFn: () =>
      api<{
        requestsByStatus: Record<string, number>;
        creditsSpent: number;
        conversations: number;
        messages: number;
      }>('/user/usage'),
  });

  const sessionsQuery = useQuery({
    queryKey: ['sessions'],
    queryFn: () => api<SessionDTO[]>('/auth/sessions'),
  });

  const applyTheme = useCallback((mode: ThemeMode) => {
    setTheme(mode);
    if (mode === 'system') {
      localStorage.removeItem(THEME_STORAGE_KEY);
      const resolved = window.matchMedia('(prefers-color-scheme: light)').matches
        ? 'light'
        : 'dark';
      document.documentElement.dataset.theme = resolved;
      document.documentElement.classList.toggle('dark', resolved === 'dark');
    } else {
      localStorage.setItem(THEME_STORAGE_KEY, mode);
      document.documentElement.dataset.theme = mode;
      document.documentElement.classList.toggle('dark', mode === 'dark');
    }
  }, []);

  const saveProfile = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSavingProfile(true);
    try {
      const updated = await api<UserDTO>('/user/profile', {
        method: 'PATCH',
        body: { username: username.trim(), avatarUrl: avatarUrl.trim() },
      });
      setUser(updated);
      toast.success('Profile updated');
    } catch (err) {
      toast.error('Could not save', err instanceof Error ? err.message : undefined);
    } finally {
      setSavingProfile(false);
    }
  };

  const changePassword = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setPasswordError(null);
    if (newPassword !== confirmPassword) {
      setPasswordError('The two passwords do not match.');
      return;
    }
    setChangingPassword(true);
    try {
      await api('/auth/change-password', {
        method: 'POST',
        body: { currentPassword, newPassword },
      });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      toast.success('Password changed', 'Other sessions were signed out.');
    } catch (err) {
      setPasswordError(err instanceof Error ? err.message : 'Could not change your password.');
    } finally {
      setChangingPassword(false);
    }
  };

  const revoke = async (sessionId: string) => {
    try {
      await api(`/auth/sessions/${sessionId}`, { method: 'DELETE' });
      setConfirmRevoke(null);
      await sessionsQuery.refetch();
      toast.success('Session revoked');
    } catch {
      toast.error('Could not revoke the session');
    }
  };

  const revokeOthers = async () => {
    try {
      const result = await api<{ revoked: number }>('/auth/sessions/revoke-others', {
        method: 'POST',
      });
      await sessionsQuery.refetch();
      toast.success(`Signed out ${result.revoked} other session(s)`);
    } catch {
      toast.error('Could not revoke sessions');
    }
  };

  const deleteAccount = async () => {
    setDeleteError(null);
    try {
      await logout();
      navigate('/', { replace: true });
      toast.info('Signed out', 'Contact support to have your data removed permanently.');
    } catch {
      setDeleteError('Could not complete the request. Please contact support.');
    }
  };

  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-30 border-b border-[var(--orbit-border)] bg-[color-mix(in_oklab,var(--orbit-bg)_86%,transparent)] backdrop-blur-sm">
        <div className="mx-auto flex max-w-3xl items-center justify-between gap-4 px-[var(--space-page)] py-3">
          <Logo />
          <div className="flex items-center gap-1.5">
            <MusicPlayer />
            <ThemeToggle />
            <Button
              variant="ghost"
              size="sm"
              icon={<LogOut className="h-4 w-4" aria-hidden />}
              onClick={async () => {
                await logout();
                navigate('/', { replace: true });
              }}
            >
              Sign out
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-6 px-[var(--space-page)] py-8">
        <div>
          <h1 className="text-2xl">Settings</h1>
          <p className="orbit-muted mt-1 text-sm">Manage your account, appearance and usage.</p>
        </div>

        {/* Account -------------------------------------------------- */}
        <Card className="p-5">
          <h2 className="text-base font-medium">Account</h2>
          <div className="mt-4 flex items-center gap-4">
            <span
              className="orbit-surface-strong flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full border border-[var(--orbit-border)] text-base font-semibold"
              aria-hidden
            >
              {user?.avatar ? (
                <img src={user.avatar} alt="" className="h-full w-full object-cover" />
              ) : (
                initials(user?.username ?? '?')
              )}
            </span>
            <div className="min-w-0">
              <p className="truncate font-medium">{user?.username}</p>
              <p className="orbit-muted truncate text-sm">{user?.email}</p>
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                {user?.role === 'ADMIN' && <Badge tone="accent">Administrator</Badge>}
                <Badge>{user?.credits} credits</Badge>
                <span className="orbit-faint text-xs">
                  Joined {user ? formatDateTime(user.createdAt) : ''}
                </span>
              </div>
            </div>
          </div>

          {isAdmin && (
            <Button
              variant="outline"
              size="sm"
              className="mt-4"
              onClick={() => navigate('/admin')}
            >
              Open admin dashboard
            </Button>
          )}
        </Card>

        {/* Profile -------------------------------------------------- */}
        <Card className="p-5">
          <h2 className="text-base font-medium">Profile</h2>
          <form onSubmit={saveProfile} className="mt-4 space-y-4">
            <Field label="Username" htmlFor="username">
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                minLength={3}
                maxLength={32}
                pattern="[A-Za-z0-9_]+"
                required
              />
            </Field>
            <Field
              label="Avatar URL"
              htmlFor="avatar"
              hint="Paste a link to an image, or upload one from the admin media library."
            >
              <div className="flex gap-2">
                <Input
                  id="avatar"
                  value={avatarUrl}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  placeholder="https://…"
                />
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif"
                  className="hidden"
                  onChange={() => {
                    toast.info(
                      'Uploads are managed by an administrator',
                      'Copy the media URL from Admin → Media into this field.',
                    );
                    if (fileRef.current) fileRef.current.value = '';
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => fileRef.current?.click()}
                  aria-label="Choose an avatar"
                >
                  <UserIcon className="h-4 w-4" aria-hidden />
                </Button>
              </div>
            </Field>
            <Button type="submit" loading={savingProfile}>
              Save profile
            </Button>
          </form>
        </Card>

        {/* Appearance ----------------------------------------------- */}
        <Card className="p-5">
          <h2 className="text-base font-medium">Appearance</h2>
          <p className="orbit-muted mt-1 text-sm">
            Branding, colours and fonts are managed centrally by an administrator.
          </p>
          <div
            className="mt-4 inline-flex rounded-[var(--radius-md)] border border-[var(--orbit-border)] p-1"
            role="group"
            aria-label="Theme"
          >
            {(
              [
                { id: 'system', label: 'System', icon: Monitor },
                { id: 'light', label: 'Light', icon: Sun },
                { id: 'dark', label: 'Dark', icon: Moon },
              ] as const
            ).map((option) => (
              <button
                key={option.id}
                type="button"
                onClick={() => applyTheme(option.id)}
                aria-pressed={theme === option.id}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-[var(--radius-sm)] px-3 py-1.5 text-sm transition-colors',
                  theme === option.id
                    ? 'orbit-surface-strong font-medium'
                    : 'orbit-muted hover:text-[var(--orbit-fg)]',
                )}
              >
                <option.icon className="h-3.5 w-3.5" aria-hidden />
                {option.label}
              </button>
            ))}
          </div>
        </Card>

        {/* Usage ---------------------------------------------------- */}
        <Card className="p-5">
          <h2 className="text-base font-medium">Usage</h2>
          {usageQuery.isLoading ? (
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4" aria-hidden>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-16" />
              ))}
            </div>
          ) : usageQuery.data ? (
            <dl className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { label: 'Credits spent', value: usageQuery.data.creditsSpent },
                { label: 'Conversations', value: usageQuery.data.conversations },
                { label: 'Messages', value: usageQuery.data.messages },
                {
                  label: 'Requests',
                  value: Object.values(usageQuery.data.requestsByStatus).reduce((a, b) => a + b, 0),
                },
              ].map((stat) => (
                <div key={stat.label} className="orbit-surface rounded-[var(--radius-md)] border border-[var(--orbit-border)] p-3">
                  <dt className="orbit-faint text-xs">{stat.label}</dt>
                  <dd className="mt-1 text-lg font-medium tabular-nums">{stat.value}</dd>
                </div>
              ))}
            </dl>
          ) : null}

          <h3 className="mt-6 text-sm font-medium">Credit history</h3>
          {creditsQuery.isLoading ? (
            <div className="mt-3 space-y-2" aria-hidden>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10" />
              ))}
            </div>
          ) : (creditsQuery.data?.items.length ?? 0) === 0 ? (
            <EmptyState title="No credit activity yet" className="py-8" />
          ) : (
            <ul className="mt-3 divide-y divide-[var(--orbit-border)]">
              {creditsQuery.data?.items.map((tx) => (
                <li key={tx.id} className="flex items-center justify-between gap-3 py-2.5">
                  <div className="min-w-0">
                    <p className="truncate text-sm">{tx.description || tx.type}</p>
                    <p className="orbit-faint text-xs">
                      {formatRelative(tx.createdAt)} · balance {tx.balanceBefore} → {tx.balanceAfter}
                      {tx.createdBy ? ` · by ${tx.createdBy}` : ''}
                    </p>
                  </div>
                  <span
                    className={cn(
                      'shrink-0 text-sm font-medium tabular-nums',
                      tx.amount > 0 ? 'text-emerald-600' : 'text-red-500',
                    )}
                  >
                    {tx.amount > 0 ? '+' : ''}
                    {tx.amount}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Security ------------------------------------------------- */}
        <Card className="p-5">
          <h2 className="flex items-center gap-2 text-base font-medium">
            <KeyRound className="h-4 w-4" aria-hidden />
            Security
          </h2>
          <form onSubmit={changePassword} className="mt-4 space-y-4">
            <Field label="Current password" htmlFor="currentPassword">
              <Input
                id="currentPassword"
                type="password"
                autoComplete="current-password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field
                label="New password"
                htmlFor="newPassword"
                hint="At least 8 characters, with a letter and a number."
              >
                <Input
                  id="newPassword"
                  type="password"
                  autoComplete="new-password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </Field>
              <Field label="Confirm new password" htmlFor="confirmPassword">
                <Input
                  id="confirmPassword"
                  type="password"
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </Field>
            </div>
            {passwordError && (
              <p role="alert" className="text-sm text-red-500">
                {passwordError}
              </p>
            )}
            <Button type="submit" loading={changingPassword}>
              Change password
            </Button>
          </form>

          <h3 className="mt-8 text-sm font-medium">Active sessions</h3>
          {sessionsQuery.isLoading ? (
            <div className="mt-3 space-y-2" aria-hidden>
              {Array.from({ length: 2 }).map((_, i) => (
                <Skeleton key={i} className="h-14" />
              ))}
            </div>
          ) : (
            <ul className="mt-3 space-y-2">
              {sessionsQuery.data?.map((session) => (
                <li
                  key={session.id}
                  className="flex items-center justify-between gap-3 rounded-[var(--radius-md)] border border-[var(--orbit-border)] p-3"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm">
                      {session.userAgent === 'unknown' ? 'Unknown device' : session.userAgent.slice(0, 70)}
                    </p>
                    <p className="orbit-faint text-xs">
                      {session.ip} · last used {formatRelative(session.lastUsedAt)}
                    </p>
                  </div>
                  {session.current ? (
                    <Badge tone="success">This device</Badge>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setConfirmRevoke(session)}
                      aria-label="Revoke session"
                      icon={<Trash2 className="h-3.5 w-3.5" aria-hidden />}
                    />
                  )}
                </li>
              ))}
            </ul>
          )}

          {(sessionsQuery.data?.length ?? 0) > 1 && (
            <Button variant="outline" size="sm" className="mt-3" onClick={() => void revokeOthers()}>
              Sign out other devices
            </Button>
          )}
        </Card>

        {/* Danger zone ---------------------------------------------- */}
        <Card className="border-red-500/30 p-5">
          <h2 className="text-base font-medium text-red-500">Account removal</h2>
          <p className="orbit-muted mt-1 text-sm leading-relaxed">
            Your conversations and messages are tied to this account. Contact support to have
            everything deleted permanently.
          </p>
          {deleteError && (
            <p role="alert" className="mt-2 text-sm text-red-500">
              {deleteError}
            </p>
          )}
          <Button variant="danger" size="sm" className="mt-4" onClick={() => void deleteAccount()}>
            Sign out and contact support
          </Button>
        </Card>
      </main>

      <Modal
        open={Boolean(confirmRevoke)}
        onClose={() => setConfirmRevoke(null)}
        title="Revoke this session?"
        description="That device will be signed out immediately."
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirmRevoke(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => confirmRevoke && void revoke(confirmRevoke.id)}
            >
              Revoke session
            </Button>
          </>
        }
      >
        <p className="orbit-muted text-sm">
          {confirmRevoke?.userAgent} · {confirmRevoke?.ip}
        </p>
      </Modal>
    </div>
  );
}
