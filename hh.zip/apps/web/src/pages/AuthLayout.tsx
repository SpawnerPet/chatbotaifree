import type { FormEvent, ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../components/layout/Logo';
import { ThemeToggle } from '../components/layout/ThemeToggle';
import { useSettings } from '../hooks/useSettings';

/** Shared shell for sign-in / sign-up / reset screens. */
export function AuthLayout({
  title,
  subtitle,
  children,
  footer,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const { settings } = useSettings();

  return (
    <div className="flex min-h-full flex-col">
      <header className="flex items-center justify-between gap-4 px-[var(--space-page)] py-4">
        <Link to="/" aria-label="Home">
          <Logo />
        </Link>
        <ThemeToggle />
      </header>

      <main className="flex flex-1 items-center justify-center px-[var(--space-page)] py-10">
        <div className="w-full max-w-sm">
          <div className="mb-6">
            <h1 className="text-2xl leading-tight">{title}</h1>
            {subtitle && <p className="orbit-muted mt-2 text-sm leading-relaxed">{subtitle}</p>}
          </div>
          {children}
          {footer && <div className="orbit-muted mt-6 text-sm">{footer}</div>}
        </div>
      </main>

      <footer className="orbit-faint px-[var(--space-page)] py-6 text-center text-xs">
        {settings.footerText || `© ${new Date().getFullYear()} ${settings.siteName}`}
      </footer>
    </div>
  );
}

interface AuthFormProps {
  onSubmit(event: FormEvent<HTMLFormElement>): void;
  error: string | null;
  children: ReactNode;
  submitLabel: string;
  loading: boolean;
  footer?: ReactNode;
}

export function AuthForm({
  onSubmit,
  error,
  children,
  submitLabel,
  loading,
  footer,
}: AuthFormProps) {
  return (
    <form onSubmit={onSubmit} noValidate className="space-y-4">
      {children}

      {error && (
        <p
          role="alert"
          className="rounded-md border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-500"
        >
          {error}
        </p>
      )}

      <button type="submit" className="btn btn-solid w-full" disabled={loading}>
        {loading ? 'Working…' : submitLabel}
      </button>

      {footer}
    </form>
  );
}


