import { useQuery } from '@tanstack/react-query';
import { KeyRound, RefreshCw } from 'lucide-react';
import { Badge, Card, ErrorState, Skeleton } from '../../components/ui';
import { api } from '../../lib/api';
import { cn, formatRelative } from '../../lib/utils';

interface KeyStatus {
  position: number;
  label: string;
  state: 'active' | 'cooldown' | 'parked';
  consecutiveFailures: number;
  cooldownUntil: string | null;
  cooldownRemainingSeconds: number;
  lastUsedAt: string | null;
  lastError: string | null;
  totalUses: number;
  totalFailures: number;
}

const STATE_TONE = {
  active: 'success',
  cooldown: 'warning',
  parked: 'danger',
} as const;

const STATE_COPY = {
  active: 'In rotation',
  cooldown: 'Benched — quota or rate limit',
  parked: 'Parked — repeated failures',
} as const;

/**
 * Health of the provider key pool. The server only ever sends a masked label
 * such as "key #1 ····a1b2", so this panel can never leak a credential.
 */
export function AiKeysPanel() {
  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['admin', 'ai-keys'],
    queryFn: () => api<{ keys: KeyStatus[]; rotations: number }>('/admin/ai-keys'),
    refetchInterval: 15_000,
  });

  if (isError) {
    return (
      <Card>
        <ErrorState
          title="Could not load key health"
          message="Check that the API is reachable and that the session is still an administrator."
          onRetry={() => void refetch()}
        />
      </Card>
    );
  }

  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="flex items-center gap-2 text-base font-medium">
            <KeyRound className="h-4 w-4" aria-hidden />
            Provider key pool
          </h2>
          <p className="orbit-muted mt-1 text-sm">
            When a key is rate limited, out of quota or rejected, the service
            benches it and the next request uses another key automatically.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refetch()}
          className="btn btn-ghost btn-icon shrink-0"
          aria-label="Refresh key pool status"
        >
          <RefreshCw className={cn('h-4 w-4', isLoading && 'animate-spin')} aria-hidden />
        </button>
      </div>

      {isLoading && !data ? (
        <div className="mt-4 space-y-2" aria-hidden>
          <Skeleton className="h-14" />
          <Skeleton className="h-14" />
        </div>
      ) : (data?.keys.length ?? 0) === 0 ? (
        <p className="orbit-faint mt-4 text-sm">
          No provider keys are configured. Set{' '}
          <code className="font-mono text-xs">OPENROUTER_API_KEY</code> on the server.
        </p>
      ) : (
        <>
          <p className="orbit-faint mt-4 text-xs">
            {data?.rotations ?? 0} rotation{(data?.rotations ?? 0) === 1 ? '' : 's'} this process
            · refreshes every 15s
          </p>
          <ul className="mt-3 space-y-2">
            {data?.keys.map((key) => (
              <li
                key={key.position}
                className="flex flex-wrap items-center justify-between gap-3 rounded-[var(--radius-md)] border border-[var(--orbit-border)] p-3"
              >
                <div className="min-w-0">
                  <p className="font-mono text-sm">{key.label}</p>
                  <p className="orbit-faint mt-0.5 text-xs">
                    {key.totalUses} use{key.totalUses === 1 ? '' : 's'} · {key.totalFailures}{' '}
                    failure{key.totalFailures === 1 ? '' : 's'}
                    {key.lastUsedAt ? ` · last used ${formatRelative(key.lastUsedAt)}` : ''}
                    {key.lastError ? ` · ${key.lastError}` : ''}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {key.state === 'cooldown' && key.cooldownRemainingSeconds > 0 && (
                    <span className="orbit-faint text-xs">
                      back in {key.cooldownRemainingSeconds}s
                    </span>
                  )}
                  <Badge tone={STATE_TONE[key.state]}>{STATE_COPY[key.state]}</Badge>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}
    </Card>
  );
}
