import { useQuery } from '@tanstack/react-query';
import type { AuditAction, AuditLogDTO, Paginated } from '@orbit/shared';
import { useState } from 'react';
import { Badge, Button, Card, EmptyState, Select, Skeleton } from '../../components/ui';
import { api } from '../../lib/api';
import { formatDateTime } from '../../lib/utils';

const ACTIONS: AuditAction[] = [
  'ADMIN_ADD_CREDIT',
  'ADMIN_REMOVE_CREDIT',
  'SUSPEND_USER',
  'ACTIVATE_USER',
  'BAN_USER',
  'CHANGE_ROLE',
  'UPDATE_SITE_SETTINGS',
  'UPLOAD_MEDIA',
  'DELETE_MEDIA',
  'MEDIA_REORDER',
  'ADMIN_LOGIN',
];

/** Audit metadata is stored as JSON; only render a block when it carries something. */
function hasMetadata(metadata: unknown): boolean {
  if (metadata && typeof metadata === 'object' && !Array.isArray(metadata)) {
    return Object.keys(metadata as Record<string, unknown>).length > 0;
  }
  return metadata !== null && metadata !== undefined;
}

export function AdminAuditPage() {
  const [action, setAction] = useState<'' | AuditAction>('');
  const [page, setPage] = useState(1);

  const logsQuery = useQuery({
    queryKey: ['admin', 'audit', action, page],
    queryFn: () => {
      const params = new URLSearchParams({ page: String(page), pageSize: '25' });
      if (action) params.set('action', action);
      return api<Paginated<AuditLogDTO>>(`/admin/audit-logs?${params.toString()}`);
    },
    placeholderData: (prev) => prev,
  });

  const items = logsQuery.data?.items ?? [];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl">Audit log</h1>
        <p className="orbit-muted mt-1 text-sm">
          Every privileged action, with the administrator who performed it.
        </p>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <label htmlFor="audit-action" className="text-sm">
            Action
          </label>
          <Select
            id="audit-action"
            value={action}
            onChange={(e) => {
              setAction(e.target.value as '' | AuditAction);
              setPage(1);
            }}
            className="w-auto"
          >
            <option value="">All actions</option>
            {ACTIONS.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </Select>
          {logsQuery.data && (
            <span className="orbit-faint text-sm">{logsQuery.data.total} entries</span>
          )}
        </div>
      </Card>

      {logsQuery.isLoading ? (
        <div className="space-y-2" aria-hidden>
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-14" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card>
          <EmptyState
            title="Nothing logged yet"
            description="Admin actions will appear here as soon as they happen."
          />
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <ul className="divide-y divide-[var(--orbit-border)]">
            {items.map((log) => (
              <li key={log.id} className="p-3.5">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={log.action.includes('REMOVE') || log.action.includes('BAN') ? 'danger' : 'accent'}>
                    {log.action}
                  </Badge>
                  <span className="text-sm">
                    by <span className="font-medium">{log.adminUsername}</span>
                  </span>
                  {log.targetUsername && (
                    <span className="orbit-muted text-sm">→ {log.targetUsername}</span>
                  )}
                  <span className="orbit-faint ml-auto text-xs">
                    {formatDateTime(log.createdAt)}
                  </span>
                </div>
                {hasMetadata(log.metadata) && (
                  <pre className="orbit-surface-strong mt-2 overflow-x-auto rounded-md p-2 text-[11px] leading-relaxed">
                    {JSON.stringify(log.metadata, null, 2)}
                  </pre>
                )}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {logsQuery.data && logsQuery.data.totalPages > 1 && (
        <nav className="flex items-center justify-between gap-3" aria-label="Pagination">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
            Previous
          </Button>
          <span className="orbit-muted text-sm">
            Page {page} of {logsQuery.data.totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            disabled={page >= logsQuery.data.totalPages}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </Button>
        </nav>
      )}
    </div>
  );
}
