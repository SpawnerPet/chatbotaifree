import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type {
  AdminUserDetailDTO,
  Paginated,
  UserDTO,
  UserRole,
  UserStatus,
} from '@orbit/shared';
import { Ban, CheckCircle2, Coins, Minus, Plus, Search, Shield, UserX } from 'lucide-react';
import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { Badge, Button, Card, EmptyState, Field, Input, Select, Skeleton } from '../../components/ui';
import { Modal } from '../../components/ui/Modal';
import { useAuth } from '../../hooks/useAuth';
import { useToast } from '../../hooks/useToast';
import { api, ApiError } from '../../lib/api';
import { useDebouncedValue } from '../../hooks/useDebouncedValue';
import { cn, formatDateTime, formatRelative } from '../../lib/utils';

const STATUS_TONE: Record<UserStatus, 'success' | 'warning' | 'danger'> = {
  ACTIVE: 'success',
  SUSPENDED: 'warning',
  BANNED: 'danger',
};

export function AdminUsersPage() {
  const queryClient = useQueryClient();
  const toast = useToast();
  const { user: me } = useAuth();

  const [search, setSearch] = useState('');
  const debounced = useDebouncedValue(search.trim(), 300);
  const [status, setStatus] = useState<'' | UserStatus>('');
  const [role, setRole] = useState<'' | UserRole>('');
  const [page, setPage] = useState(1);
  const [creditTarget, setCreditTarget] = useState<UserDTO | null>(null);
  const [statusTarget, setStatusTarget] = useState<{ user: UserDTO; next: UserStatus } | null>(
    null,
  );

  const onSearch = (value: string) => {
    setSearch(value);
    setPage(1);
  };

  const usersQuery = useQuery({
    queryKey: ['admin', 'users', debounced, status, role, page],
    queryFn: () => {
      const params = new URLSearchParams({ page: String(page), pageSize: '20' });
      if (debounced) params.set('search', debounced);
      if (status) params.set('status', status);
      if (role) params.set('role', role);
      return api<Paginated<UserDTO>>(`/admin/users?${params.toString()}`);
    },
    placeholderData: (prev) => prev,
  });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['admin', 'users'] });
    void queryClient.invalidateQueries({ queryKey: ['admin', 'stats'] });
  };

  const statusMutation = useMutation({
    mutationFn: (input: { id: string; status: UserStatus; reason?: string }) =>
      api<UserDTO>(`/admin/users/${input.id}/status`, {
        method: 'PATCH',
        body: { status: input.status, reason: input.reason },
      }),
    onSuccess: (updated) => {
      invalidate();
      setStatusTarget(null);
      toast.success(`Account ${updated.status.toLowerCase()}`);
    },
    onError: (err) =>
      toast.error('Could not update the account', err instanceof ApiError ? err.message : undefined),
  });

  const items = usersQuery.data?.items ?? [];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl">Users</h1>
        <p className="orbit-muted mt-1 text-sm">
          {usersQuery.data ? `${usersQuery.data.total} accounts` : 'Loading…'}
        </p>
      </div>

      <Card className="p-4">
        <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto]">
          <div className="relative">
            <Search className="orbit-faint pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2" aria-hidden />
            <label htmlFor="admin-user-search" className="sr-only">
              Search users
            </label>
            <Input
              id="admin-user-search"
              type="search"
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              placeholder="Search by email or username"
              className="pl-8"
            />
          </div>
          <label htmlFor="admin-status" className="sr-only">
            Filter by status
          </label>
          <Select
            id="admin-status"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value as '' | UserStatus);
              setPage(1);
            }}
            className="w-auto"
          >
            <option value="">All statuses</option>
            <option value="ACTIVE">Active</option>
            <option value="SUSPENDED">Suspended</option>
            <option value="BANNED">Banned</option>
          </Select>
          <label htmlFor="admin-role" className="sr-only">
            Filter by role
          </label>
          <Select
            id="admin-role"
            value={role}
            onChange={(e) => {
              setRole(e.target.value as '' | UserRole);
              setPage(1);
            }}
            className="w-auto"
          >
            <option value="">All roles</option>
            <option value="USER">User</option>
            <option value="ADMIN">Admin</option>
          </Select>
        </div>
      </Card>

      {usersQuery.isLoading ? (
        <div className="space-y-2" aria-hidden>
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-16" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card>
          <EmptyState
            title="No users match"
            description="Try a different search term or clear the filters."
          />
        </Card>
      ) : (
        <>
          {/* Desktop table ------------------------------------------- */}
          <Card className="hidden overflow-hidden md:block">
            <table className="w-full text-sm">
              <caption className="sr-only">User accounts</caption>
              <thead>
                <tr className="border-b border-[var(--orbit-border)] text-left">
                  <th scope="col" className="orbit-faint px-4 py-2.5 font-medium">User</th>
                  <th scope="col" className="orbit-faint px-4 py-2.5 font-medium">Role</th>
                  <th scope="col" className="orbit-faint px-4 py-2.5 font-medium">Status</th>
                  <th scope="col" className="orbit-faint px-4 py-2.5 text-right font-medium">Credits</th>
                  <th scope="col" className="orbit-faint px-4 py-2.5 font-medium">Last seen</th>
                  <th scope="col" className="orbit-faint px-4 py-2.5 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[var(--orbit-border)]">
                {items.map((user) => (
                  <tr key={user.id} className="hover:orbit-surface transition-colors">
                    <td className="px-4 py-3">
                      <Link to={`/admin/users/${user.id}`} className="font-medium hover:underline">
                        {user.username}
                      </Link>
                      <p className="orbit-faint text-xs">{user.email}</p>
                    </td>
                    <td className="px-4 py-3">
                      {user.role === 'ADMIN' ? (
                        <Badge tone="accent">
                          <Shield className="mr-1 h-3 w-3" aria-hidden />
                          Admin
                        </Badge>
                      ) : (
                        <Badge>User</Badge>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <Badge tone={STATUS_TONE[user.status]}>{user.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{user.credits}</td>
                    <td className="orbit-muted px-4 py-3 text-xs">
                      {formatRelative(user.lastLoginAt)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setCreditTarget(user)}
                          aria-label={`Adjust credits for ${user.username}`}
                          icon={<Coins className="h-3.5 w-3.5" aria-hidden />}
                        />
                        {user.id === me?.id ? (
                          <span className="orbit-faint px-2 text-xs">You</span>
                        ) : user.status === 'ACTIVE' ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setStatusTarget({ user, next: 'SUSPENDED' })}
                            aria-label={`Suspend ${user.username}`}
                            icon={<UserX className="h-3.5 w-3.5" aria-hidden />}
                          />
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setStatusTarget({ user, next: 'ACTIVE' })}
                            aria-label={`Activate ${user.username}`}
                            icon={<CheckCircle2 className="h-3.5 w-3.5" aria-hidden />}
                          />
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>

          {/* Mobile cards -------------------------------------------- */}
          <ul className="space-y-2 md:hidden">
            {items.map((user) => (
              <li key={user.id}>
                <Card className="p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <Link to={`/admin/users/${user.id}`} className="font-medium hover:underline">
                        {user.username}
                      </Link>
                      <p className="orbit-faint truncate text-xs">{user.email}</p>
                    </div>
                    <div className="flex shrink-0 flex-col items-end gap-1">
                      <Badge tone={STATUS_TONE[user.status]}>{user.status}</Badge>
                      <span className="text-sm font-medium tabular-nums">{user.credits} cr</span>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setCreditTarget(user)}
                      icon={<Coins className="h-3.5 w-3.5" aria-hidden />}
                    >
                      Credits
                    </Button>
                    {user.id !== me?.id &&
                      (user.status === 'ACTIVE' ? (
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => setStatusTarget({ user, next: 'SUSPENDED' })}
                        >
                          Suspend
                        </Button>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          className="flex-1"
                          onClick={() => setStatusTarget({ user, next: 'ACTIVE' })}
                        >
                          Activate
                        </Button>
                      ))}
                  </div>
                </Card>
              </li>
            ))}
          </ul>

          {usersQuery.data && usersQuery.data.totalPages > 1 && (
            <nav className="flex items-center justify-between gap-3" aria-label="Pagination">
              <Button
                variant="outline"
                size="sm"
                disabled={page <= 1}
                onClick={() => setPage((p) => Math.max(1, p - 1))}
              >
                Previous
              </Button>
              <span className="orbit-muted text-sm">
                Page {page} of {usersQuery.data.totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                disabled={page >= usersQuery.data.totalPages}
                onClick={() => setPage((p) => p + 1)}
              >
                Next
              </Button>
            </nav>
          )}
        </>
      )}

      <CreditModal
        user={creditTarget}
        onClose={() => setCreditTarget(null)}
        onDone={invalidate}
      />

      <Modal
        open={Boolean(statusTarget)}
        onClose={() => setStatusTarget(null)}
        title={
          statusTarget?.next === 'ACTIVE'
            ? `Reactivate ${statusTarget.user.username}?`
            : `Suspend ${statusTarget?.user.username}?`
        }
        description={
          statusTarget?.next === 'ACTIVE'
            ? 'The user will be able to sign in and chat again.'
            : 'All of their sessions are revoked immediately and chat is blocked.'
        }
        footer={
          <>
            <Button variant="ghost" onClick={() => setStatusTarget(null)}>
              Cancel
            </Button>
            <Button
              variant={statusTarget?.next === 'ACTIVE' ? 'solid' : 'danger'}
              loading={statusMutation.isPending}
              onClick={() =>
                statusTarget &&
                statusMutation.mutate({
                  id: statusTarget.user.id,
                  status: statusTarget.next,
                  reason: `Changed from admin dashboard`,
                })
              }
            >
              {statusTarget?.next === 'ACTIVE' ? 'Reactivate' : 'Suspend'}
            </Button>
          </>
        }
      >
        <p className="orbit-muted text-sm">
          This action is recorded in the audit log against your account.
        </p>
      </Modal>
    </div>
  );
}

function CreditModal({
  user,
  onClose,
  onDone,
}: {
  user: UserDTO | null;
  onClose(): void;
  onDone(): void;
}) {
  const toast = useToast();
  const [amount, setAmount] = useState('10');
  const [reason, setReason] = useState('');

  const mutation = useMutation({
    mutationFn: (input: { id: string; amount: number; reason: string }) =>
      api<{ user: UserDTO; balanceBefore: number; balanceAfter: number }>(
        `/admin/users/${input.id}/credits`,
        { method: 'POST', body: { amount: input.amount, reason: input.reason } },
      ),
    onSuccess: (result) => {
      toast.success(
        'Credits updated',
        `Balance is now ${result.balanceAfter} (was ${result.balanceBefore}).`,
      );
      onDone();
      onClose();
      setReason('');
      setAmount('10');
    },
    onError: (err) =>
      toast.error('Could not adjust credits', err instanceof ApiError ? err.message : undefined),
  });

  const parsed = Number(amount);
  const valid = Number.isInteger(parsed) && parsed !== 0 && reason.trim().length > 0;
  const wouldGoNegative = user ? parsed < 0 && user.credits + parsed < 0 : false;

  return (
    <Modal
      open={Boolean(user)}
      onClose={onClose}
      title={`Adjust credits for ${user?.username ?? ''}`}
      description={user ? `Current balance: ${user.credits} credits.` : undefined}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant={parsed < 0 ? 'danger' : 'solid'}
            disabled={!valid || wouldGoNegative}
            loading={mutation.isPending}
            onClick={() =>
              user && mutation.mutate({ id: user.id, amount: parsed, reason: reason.trim() })
            }
          >
            Apply
          </Button>
        </>
      }
    >
      <div className="space-y-4">
        <Field
          label="Amount"
          htmlFor="credit-amount"
          hint="Use a negative number to remove credits."
        >
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setAmount(String((Number(amount) || 0) - 10))}
              aria-label="Decrease by 10"
              icon={<Minus className="h-3.5 w-3.5" aria-hidden />}
            />
            <Input
              id="credit-amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-center tabular-nums"
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setAmount(String((Number(amount) || 0) + 10))}
              aria-label="Increase by 10"
              icon={<Plus className="h-3.5 w-3.5" aria-hidden />}
            />
          </div>
        </Field>

        <Field label="Reason" htmlFor="credit-reason" hint="Stored in the credit ledger and audit log.">
          <Input
            id="credit-reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Goodwill credit for a failed request"
            maxLength={240}
          />
        </Field>

        {wouldGoNegative && (
          <p role="alert" className="text-sm text-red-500">
            That would leave the balance negative. Credits can never go below zero.
          </p>
        )}
        {valid && !wouldGoNegative && user && (
          <p className={cn('text-sm', parsed < 0 ? 'text-red-500' : 'text-emerald-600')}>
            New balance: {user.credits + parsed} credits
          </p>
        )}
      </div>
    </Modal>
  );
}

export function AdminUserDetailPage() {
  const toast = useToast();
  const queryClient = useQueryClient();
  const [creditOpen, setCreditOpen] = useState(false);

  const { id = '' } = useParams<{ id: string }>();
  const detailQuery = useQuery({
    queryKey: ['admin', 'user', id],
    queryFn: () => api<AdminUserDetailDTO>(`/admin/users/${id}`),
  });

  const roleMutation = useMutation({
    mutationFn: (role: UserRole) =>
      api<UserDTO>(`/admin/users/${id}/role`, {
        method: 'PATCH',
        body: { role, reason: 'Changed from user detail view' },
      }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['admin', 'user', id] });
      toast.success('Role updated');
    },
    onError: (err) => toast.error('Could not change the role', err instanceof ApiError ? err.message : undefined),
  });

  if (detailQuery.isLoading) {
    return (
      <div className="space-y-3" aria-hidden>
        <Skeleton className="h-8 w-40" />
        <Skeleton className="h-40" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (detailQuery.isError || !detailQuery.data) {
    return (
      <EmptyState
        title="User not found"
        description="This account may have been removed."
      />
    );
  }

  const { user, creditTransactions, auditLogs, stats, conversationCount, messageCount, sessionCount } =
    detailQuery.data;

  return (
    <div className="space-y-5">
      <div>
        <Link to="/admin/users" className="orbit-faint text-sm hover:underline">
          ← All users
        </Link>
        <h1 className="mt-2 text-2xl">{user.username}</h1>
        <p className="orbit-muted text-sm">{user.email}</p>
        <div className="mt-2 flex flex-wrap items-center gap-1.5">
          <Badge tone={STATUS_TONE[user.status]}>{user.status}</Badge>
          <Badge tone={user.role === 'ADMIN' ? 'accent' : 'neutral'}>{user.role}</Badge>
          <Badge>{user.credits} credits</Badge>
        </div>
        <p className="orbit-faint mt-2 text-xs">
          Joined {formatDateTime(user.createdAt)} · last login {formatRelative(user.lastLoginAt)}
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={() => setCreditOpen(true)} icon={<Coins className="h-4 w-4" aria-hidden />}>
          Adjust credits
        </Button>
        <Button
          variant="outline"
          onClick={() => roleMutation.mutate(user.role === 'ADMIN' ? 'USER' : 'ADMIN')}
          loading={roleMutation.isPending}
          icon={<Shield className="h-4 w-4" aria-hidden />}
        >
          Make {user.role === 'ADMIN' ? 'a user' : 'an admin'}
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        {[
          { label: 'Conversations', value: conversationCount },
          { label: 'Messages', value: messageCount },
          { label: 'Active sessions', value: sessionCount },
          { label: 'AI requests', value: stats.requests },
          { label: 'Succeeded', value: stats.succeeded },
          { label: 'Failed / aborted', value: stats.failed },
        ].map((stat) => (
          <Card key={stat.label} className="p-3">
            <p className="orbit-faint text-xs">{stat.label}</p>
            <p className="mt-1 text-lg font-medium tabular-nums">{stat.value}</p>
          </Card>
        ))}
      </div>

      <Card className="p-5">
        <h2 className="text-base font-medium">Credit history</h2>
        {creditTransactions.length === 0 ? (
          <EmptyState title="No transactions" className="py-6" />
        ) : (
          <ul className="mt-3 divide-y divide-[var(--orbit-border)]">
            {creditTransactions.map((tx) => (
              <li key={tx.id} className="flex items-center justify-between gap-3 py-2.5 text-sm">
                <div className="min-w-0">
                  <p className="truncate">{tx.description || tx.type}</p>
                  <p className="orbit-faint text-xs">
                    {formatDateTime(tx.createdAt)} · {tx.type} · {tx.balanceBefore} → {tx.balanceAfter}
                    {tx.createdBy ? ` · by ${tx.createdBy}` : ''}
                  </p>
                </div>
                <span
                  className={cn(
                    'shrink-0 font-medium tabular-nums',
                    tx.amount > 0 ? 'text-emerald-600' : 'text-red-500',
                  )}
                >
                  {tx.amount > 0 ? '+' : ''}
                  {tx.amount}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card className="p-5">
        <h2 className="text-base font-medium">Audit trail</h2>
        {auditLogs.length === 0 ? (
          <EmptyState title="No admin actions on this account" className="py-6" />
        ) : (
          <ul className="mt-3 divide-y divide-[var(--orbit-border)]">
            {auditLogs.map((log) => (
              <li key={log.id} className="py-2.5 text-sm">
                <p className="flex items-center gap-2">
                  <Badge tone="accent">{log.action}</Badge>
                  <span className="orbit-faint text-xs">by {log.adminUsername}</span>
                </p>
                <p className="orbit-faint mt-1 text-xs">
                  {formatDateTime(log.createdAt)} · {JSON.stringify(log.metadata)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <CreditModal
        user={creditOpen ? user : null}
        onClose={() => setCreditOpen(false)}
        onDone={() => void detailQuery.refetch()}
      />

      {user.status !== 'ACTIVE' && (
        <Card className="border-amber-600/30 p-4 text-sm text-amber-600">
          <Ban className="mr-1.5 inline h-3.5 w-3.5" aria-hidden />
          This account is {user.status.toLowerCase()} and cannot sign in.
        </Card>
      )}
    </div>
  );
}
