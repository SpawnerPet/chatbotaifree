import {
  BarChart3,
  Image as ImageIcon,
  LayoutDashboard,
  Palette,
  ScrollText,
  Users,
} from 'lucide-react';
import { NavLink, Outlet } from 'react-router-dom';
import { Logo } from '../../components/layout/Logo';
import { MusicPlayer } from '../../components/layout/MusicPlayer';
import { ThemeToggle } from '../../components/layout/ThemeToggle';
import { useAuth } from '../../hooks/useAuth';
import { cn } from '../../lib/utils';

const LINKS = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/users', label: 'Users', icon: Users, end: false },
  { to: '/admin/media', label: 'Media', icon: ImageIcon, end: false },
  { to: '/admin/customization', label: 'Customization', icon: Palette, end: false },
  { to: '/admin/audit', label: 'Audit log', icon: ScrollText, end: false },
];

export function AdminLayout() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-full flex-col">
      <header className="sticky top-0 z-30 border-b border-[var(--orbit-border)] bg-[color-mix(in_oklab,var(--orbit-bg)_86%,transparent)] backdrop-blur-sm">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-[var(--space-page)] py-3">
          <div className="flex items-center gap-3">
            <NavLink to="/admin" aria-label="Admin dashboard">
              <Logo />
            </NavLink>
            <span className="orbit-hairline hidden h-5 w-px sm:block" aria-hidden />
            <span className="orbit-faint hidden items-center gap-1.5 text-xs sm:inline-flex">
              <BarChart3 className="h-3.5 w-3.5" aria-hidden />
              Admin
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <MusicPlayer />
            <ThemeToggle />
            <span className="orbit-faint hidden text-xs sm:inline">{user?.username}</span>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-6 px-[var(--space-page)] py-6 lg:flex-row">
        <nav aria-label="Admin sections">
          <ul className="no-scrollbar flex gap-1 overflow-x-auto lg:w-52 lg:flex-col lg:overflow-visible">
            {LINKS.map((link) => (
              <li key={link.to}>
                <NavLink
                  to={link.to}
                  end={link.end}
                  className={({ isActive }) =>
                    cn(
                      'flex shrink-0 items-center gap-2 rounded-md px-3 py-2 text-sm transition-colors',
                      isActive
                        ? 'orbit-surface-strong font-medium'
                        : 'orbit-muted hover:orbit-surface-strong',
                    )
                  }
                >
                  <link.icon className="h-4 w-4" aria-hidden />
                  {link.label}
                </NavLink>
              </li>
            ))}
            <li className="mt-2 hidden lg:block">
              <NavLink
                to="/chat"
                className="orbit-muted hover:text-[var(--orbit-fg)] block rounded-md px-3 py-2 text-sm"
              >
                ← Back to chat
              </NavLink>
            </li>
          </ul>
        </nav>

        <main className="min-w-0 flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
