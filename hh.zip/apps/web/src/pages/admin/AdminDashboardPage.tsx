import { useQuery } from '@tanstack/react-query';
import type { AdminStats } from '@orbit/shared';
import { Activity, AlertTriangle, Coins, MessageSquare, Users as UsersIcon } from 'lucide-react';
import { useMemo } from 'react';
import { Card, ErrorState, Skeleton } from '../../components/ui';
import { api } from '../../lib/api';
import { formatNumber, formatRelative } from '../../lib/utils';
import { AiKeysPanel } from './AiKeysPanel';

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
}: {
  label: string;
  value: number | string;
  sub?: string;
  icon: typeof UsersIcon;
}) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="orbit-faint text-xs font-medium uppercase tracking-wide">{label}</p>
          <p className="mt-1.5 text-2xl font-medium tabular-nums">{value}</p>
          {sub && <p className="orbit-faint mt-0.5 truncate text-xs">{sub}</p>}
        </div>
        <Icon className="orbit-faint h-4 w-4 shrink-0" aria-hidden />
      </div>
    </Card>
  );
}

/** Simple horizontal bar, drawn without a charting dependency. */
function Bar({ label, value, max, tone }: { label: string; value: number; max: number; tone: string }) {
  const pct = max === 0 ? 0 : Math.round((value / max) * 100);
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3 text-sm">
        <span className="orbit-muted">{label}</span>
        <span className="font-medium tabular-nums">{formatNumber(value)}</span>
      </div>
      <div className="orbit-surface-strong mt-1.5 h-1.5 overflow-hidden rounded-full">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: tone }} />
      </div>
    </div>
  );
}

export function AdminDashboardPage() {
  const statsQuery = useQuery({
    queryKey: ['admin', 'stats'],
    queryFn: () => api<AdminStats>('/admin/stats'),
    refetchInterval: 30_000,
  });

  const stats = statsQuery.data;

  const maxRequest = useMemo(
    () => Math.max(1, stats?.requests.succeeded ?? 0, stats?.requests.failed ?? 0, stats?.requests.aborted ?? 0),
    [stats],
  );

  if (statsQuery.isError) {
    return (
      <ErrorState
        title="Could not load statistics"
        message={statsQuery.error instanceof Error ? statsQuery.error.message : undefined}
        onRetry={() => void statsQuery.refetch()}
      />
    );
  }

  if (statsQuery.isLoading || !stats) {
    return (
      <div className="space-y-4" aria-hidden>
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      </div>
    );
  }

  const accent = 'var(--orbit-accent)';

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl">Dashboard</h1>
        <p className="orbit-muted mt-1 text-sm">
          Live figures from the database.{' '}
          {stats.lastRequestAt
            ? `Last AI request ${formatRelative(stats.lastRequestAt)}.`
            : 'No AI requests yet.'}
        </p>
      </div>

      <section aria-label="User metrics">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Total users" value={formatNumber(stats.users.total)} sub={`${stats.users.newLast7Days} new this week`} icon={UsersIcon} />
          <StatCard label="Active" value={formatNumber(stats.users.active)} sub={`${stats.users.suspended} suspended · ${stats.users.banned} banned`} icon={Activity} />
          <StatCard label="Credits outstanding" value={formatNumber(stats.credits.outstanding)} sub={`${formatNumber(stats.credits.consumed)} consumed`} icon={Coins} />
          <StatCard label="Conversations" value={formatNumber(stats.chat.conversations)} sub={`${formatNumber(stats.chat.messages)} messages`} icon={MessageSquare} />
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <h2 className="text-base font-medium">AI requests</h2>
          <p className="orbit-muted mt-0.5 text-sm">
            {formatNumber(stats.requests.total)} total attempts
          </p>
          <div className="mt-4 space-y-3">
            <Bar label="Succeeded" value={stats.requests.succeeded} max={maxRequest} tone="var(--orbit-accent)" />
            <Bar label="Failed" value={stats.requests.failed} max={maxRequest} tone="#dc2626" />
            <Bar label="Aborted by user" value={stats.requests.aborted} max={maxRequest} tone="#b08a5a" />
          </div>
        </Card>

        <Card className="p-5">
          <h2 className="text-base font-medium">Credit ledger</h2>
          <dl className="mt-4 space-y-3">
            {[
              { label: 'Granted (all time)', value: stats.credits.granted },
              { label: 'Consumed by chat', value: stats.credits.consumed },
              { label: 'Refunded', value: stats.credits.refunded },
              { label: 'Still held by users', value: stats.credits.outstanding },
            ].map((row) => (
              <div key={row.label} className="flex items-baseline justify-between gap-3 text-sm">
                <dt className="orbit-muted">{row.label}</dt>
                <dd className="font-medium tabular-nums">{formatNumber(row.value)}</dd>
              </div>
            ))}
          </dl>

          {stats.requests.failed > 0 && (
            <p className="mt-4 flex items-start gap-2 rounded-md border border-amber-600/30 bg-amber-500/10 p-3 text-xs text-amber-600">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden />
              {stats.requests.failed} provider call(s) failed. Those users were refunded automatically.
            </p>
          )}
        </Card>
      </div>

      <Card className="p-5">
        <h2 className="text-base font-medium">Platform</h2>
        <dl className="mt-4 grid gap-4 sm:grid-cols-3">
          {[
            { label: 'Administrators', value: stats.users.admins },
            { label: 'Assistant messages', value: stats.chat.assistantMessages },
            { label: 'Total requests', value: stats.requests.total },
          ].map((row) => (
            <div key={row.label}>
              <dt className="orbit-faint text-xs">{row.label}</dt>
              <dd className="mt-0.5 text-lg font-medium tabular-nums">{formatNumber(row.value)}</dd>
            </div>
          ))}
        </dl>
        <p className="orbit-faint mt-4 text-xs" style={{ color: accent }}>
          Figures refresh every 30 seconds.
        </p>
      </Card>

      <AiKeysPanel />
    </div>
  );
}
