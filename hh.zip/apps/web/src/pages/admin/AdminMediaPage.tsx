import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { PublicMedia } from '@orbit/shared';
import { Copy, FileAudio, FileVideo, Image as ImageIcon, Trash2, Upload } from 'lucide-react';
import { useRef, useState } from 'react';
import { Badge, Button, Card, EmptyState, Select, Skeleton } from '../../components/ui';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../hooks/useToast';
import { api, ApiError } from '../../lib/api';
import { formatBytes, formatDateTime } from '../../lib/utils';

function KindIcon({ kind }: { kind: PublicMedia['kind'] }) {
  if (kind === 'AUDIO') return <FileAudio className="h-4 w-4" aria-hidden />;
  if (kind === 'VIDEO') return <FileVideo className="h-4 w-4" aria-hidden />;
  return <ImageIcon className="h-4 w-4" aria-hidden />;
}

export function AdminMediaPage() {
  const toast = useToast();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [kindFilter, setKindFilter] = useState('');
  const [pendingDelete, setPendingDelete] = useState<PublicMedia | null>(null);
  const [uploading, setUploading] = useState(false);

  const mediaQuery = useQuery({
    queryKey: ['admin', 'media', kindFilter],
    queryFn: () =>
      api<PublicMedia[]>(`/admin/media${kindFilter ? `?kind=${kindFilter}` : ''}`),
  });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ['admin', 'media'] });
    void queryClient.invalidateQueries({ queryKey: ['settings'] });
  };

  const upload = async (file: File) => {
    setUploading(true);
    try {
      const buffer = await file.arrayBuffer();
      const category = file.type.startsWith('video/')
        ? 'video'
        : file.type.startsWith('audio/')
          ? 'audio'
          : 'image';
      // Raw bytes: the server re-validates the type from the file's magic bytes.
      const params = new URLSearchParams({
        category,
        filename: file.name,
      });
      await api(`/admin/media?${params.toString()}`, {
        method: 'POST',
        body: new Blob([buffer], { type: file.type }),
        headers: { 'Content-Type': file.type || 'application/octet-stream' },
      });
      toast.success('Uploaded', `${file.name} is available in the library.`);
      invalidate();
    } catch (err) {
      toast.error(
        'Upload rejected',
        err instanceof ApiError ? err.message : 'The file could not be uploaded.',
      );
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const remove = useMutation({
    mutationFn: (id: string) => api(`/admin/media/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      toast.success('Media deleted');
      setPendingDelete(null);
      invalidate();
    },
    onError: (err) =>
      toast.error('Could not delete', err instanceof ApiError ? err.message : undefined),
  });

  const copyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      toast.success('URL copied');
    } catch {
      toast.error('Could not copy the URL');
    }
  };

  const items = mediaQuery.data ?? [];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl">Media</h1>
        <p className="orbit-muted mt-1 max-w-xl text-sm">
          Logos, backgrounds, GIFs, videos and music. Files are validated by their actual
          contents, not just their extension.
        </p>
      </div>

      <Card className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={fileRef}
            type="file"
            className="hidden"
            accept="image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm,audio/mpeg"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void upload(file);
            }}
          />
          <Button
            onClick={() => fileRef.current?.click()}
            loading={uploading}
            icon={<Upload className="h-4 w-4" aria-hidden />}
          >
            Upload file
          </Button>

          <label htmlFor="media-kind" className="sr-only">
            Filter by type
          </label>
          <Select
            id="media-kind"
            value={kindFilter}
            onChange={(e) => setKindFilter(e.target.value)}
            className="w-auto"
          >
            <option value="">All types</option>
            <option value="IMAGE">Images</option>
            <option value="GIF">GIFs</option>
            <option value="VIDEO">Videos</option>
            <option value="AUDIO">Audio</option>
            <option value="ICON">Icons</option>
          </Select>
        </div>
        <p className="orbit-faint mt-2 text-xs">
          Images up to 5 MB · video up to 25 MB · MP3 up to 10 MB. Executable and HTML files are
          always rejected.
        </p>
      </Card>

      {mediaQuery.isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3" aria-hidden>
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <Card>
          <EmptyState
            icon={<ImageIcon className="h-5 w-5" aria-hidden />}
            title="No media yet"
            description="Upload a logo, background or audio file to get started."
          />
        </Card>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((item) => (
            <li key={item.id}>
              <Card className="flex h-full flex-col overflow-hidden">
                <div className="flex h-32 items-center justify-center overflow-hidden border-b border-[var(--orbit-border)] bg-[var(--orbit-surface-strong)]">
                  {item.kind === 'IMAGE' || item.kind === 'GIF' || item.kind === 'ICON' ? (
                    <img
                      src={item.url}
                      alt={item.altText || item.filename}
                      className="h-full w-full object-contain"
                      loading="lazy"
                    />
                  ) : item.kind === 'VIDEO' ? (
                    <video
                      src={item.url}
                      className="h-full w-full object-contain"
                      muted
                      playsInline
                      preload="metadata"
                    />
                  ) : (
                    <FileAudio className="h-8 w-8 opacity-50" aria-hidden />
                  )}
                </div>

                <div className="flex flex-1 flex-col gap-2 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <p className="min-w-0 flex-1 truncate text-sm font-medium">{item.filename}</p>
                    <Badge>
                      <span className="mr-1 inline-flex">
                        <KindIcon kind={item.kind} />
                      </span>
                      {item.kind}
                    </Badge>
                  </div>
                  <p className="orbit-faint text-xs">
                    {formatBytes(item.size)} · {item.mimeType} · {formatDateTime(item.createdAt)}
                  </p>
                  <p className="orbit-faint break-all font-mono text-[11px]">{item.id}</p>

                  <div className="mt-auto flex gap-1.5 pt-1">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => void copyUrl(item.url)}
                      icon={<Copy className="h-3.5 w-3.5" aria-hidden />}
                    >
                      Copy URL
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setPendingDelete(item)}
                      aria-label={`Delete ${item.filename}`}
                      icon={<Trash2 className="h-3.5 w-3.5" aria-hidden />}
                    />
                  </div>
                </div>
              </Card>
            </li>
          ))}
        </ul>
      )}

      <Modal
        open={Boolean(pendingDelete)}
        onClose={() => setPendingDelete(null)}
        title="Delete this file?"
        description={
          pendingDelete
            ? `${pendingDelete.filename} will be removed from storage. Any setting using it falls back to a flat colour.`
            : undefined
        }
        footer={
          <>
            <Button variant="ghost" onClick={() => setPendingDelete(null)}>
              Cancel
            </Button>
            <Button
              variant="danger"
              loading={remove.isPending}
              onClick={() => pendingDelete && remove.mutate(pendingDelete.id)}
            >
              Delete permanently
            </Button>
          </>
        }
      >
        {pendingDelete && (pendingDelete.kind === 'IMAGE' || pendingDelete.kind === 'GIF') && (
          <img
            src={pendingDelete.url}
            alt=""
            className="mx-auto max-h-40 rounded-md border border-[var(--orbit-border)] object-contain"
          />
        )}
      </Modal>
    </div>
  );
}
