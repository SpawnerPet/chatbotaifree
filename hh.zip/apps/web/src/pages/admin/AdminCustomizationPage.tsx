import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type { PublicSettings } from '@orbit/shared';
import { useEffect, useState } from 'react';
import { Button, Card, Field, Input, Select, Textarea } from '../../components/ui';
import { useToast } from '../../hooks/useToast';
import { api, ApiError } from '../../lib/api';

type Draft = Omit<PublicSettings, 'backgroundUrl' | 'backgroundPosterUrl' | 'updatedAt'>;

const SECTIONS: Array<{ title: string; description: string; fields: Array<keyof Draft> }> = [
  {
    title: 'Identity',
    description: 'The name and mark used across the product.',
    fields: ['siteName', 'siteTagline', 'logoUrl', 'faviconUrl', 'footerText', 'supportEmail'],
  },
  {
    title: 'Landing page',
    description: 'What visitors see before they sign in.',
    fields: ['landingTitle', 'landingDescription', 'primaryCtaText', 'secondaryCtaText'],
  },
  {
    title: 'Authentication',
    description: 'Copy shown on the sign-in screen.',
    fields: ['loginTitle', 'loginSubtitle'],
  },
  {
    title: 'Chat',
    description: 'The empty state inside the chat window.',
    fields: ['chatWelcomeMessage', 'chatEmptyPrompts'],
  },
  {
    title: 'Appearance',
    description: 'Colours, typography and contrast.',
    fields: [
      'accentColor',
      'backgroundColor',
      'textColor',
      'borderColor',
      'buttonStyle',
      'fontChoice',
      'defaultTheme',
    ],
  },
  {
    title: 'Background',
    description: 'Choose a flat colour, an image, a GIF or a video.',
    fields: [
      'backgroundType',
      'backgroundMediaId',
      'backgroundOverlayOpacity',
      'backgroundParallax',
    ],
  },
  {
    title: 'Music',
    description: 'Optional background audio. Never forced on.',
    fields: ['musicEnabled', 'musicUrl', 'musicVolume', 'musicAutoplay'],
  },
];

export function AdminCustomizationPage() {
  const toast = useToast();
  const queryClient = useQueryClient();
  const [draft, setDraft] = useState<Draft | null>(null);
  const [saving, setSaving] = useState(false);

  const settingsQuery = useQuery({
    queryKey: ['settings'],
    queryFn: () => api<PublicSettings>('/settings'),
  });

  useEffect(() => {
    if (!settingsQuery.data) return;
    const { backgroundUrl: _u, backgroundPosterUrl: _p, updatedAt: _d, ...rest } = settingsQuery.data;
    setDraft(rest as Draft);
  }, [settingsQuery.data]);

  const saveMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) =>
      api<PublicSettings>('/admin/settings', { method: 'PATCH', body: payload }),
    onSuccess: (updated) => {
      queryClient.setQueryData(['settings'], updated);
      const { backgroundUrl: _u, backgroundPosterUrl: _p, updatedAt: _d, ...rest } = updated;
      setDraft(rest as Draft);
      toast.success('Settings saved', 'The whole site is updated immediately.');
    },
    onError: (err) =>
      toast.error('Could not save settings', err instanceof ApiError ? err.message : undefined),
  });

  const save = async () => {
    if (!draft) return;
    setSaving(true);
    // Send only what the admin actually touched, so a partial form never
    // wipes fields that are not on this screen.
    const original = settingsQuery.data;
    const payload: Record<string, unknown> = {};
    if (original) {
      for (const key of Object.keys(draft) as Array<keyof Draft>) {
        if (JSON.stringify(draft[key]) !== JSON.stringify(original[key])) {
          payload[key] = draft[key];
        }
      }
    } else {
      Object.assign(payload, draft);
    }

    if (Object.keys(payload).length === 0) {
      setSaving(false);
      toast.info('Nothing changed');
      return;
    }
    saveMutation.mutate(payload);
    setSaving(false);
  };

  const set = <K extends keyof Draft>(key: K, value: Draft[K]) =>
    setDraft((prev) => (prev ? { ...prev, [key]: value } : prev));

  if (!draft) {
    return <div className="h-64" aria-hidden />;
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl">Customization</h1>
          <p className="orbit-muted mt-1 max-w-xl text-sm">
            Every change here applies to the live site immediately — no deploy, no code edit.
          </p>
        </div>
        <Button onClick={() => void save()} loading={saving} disabled={saving}>
          Save changes
        </Button>
      </div>

      {SECTIONS.map((section) => (
        <Card key={section.title} className="p-5">
          <h2 className="text-base font-medium">{section.title}</h2>
          <p className="orbit-muted mt-0.5 text-sm">{section.description}</p>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {section.fields.map((key) => (
              <FieldRenderer
                key={String(key)}
                fieldKey={key}
                draft={draft}
                set={set}
                currentMediaUrl={settingsQuery.data?.backgroundUrl ?? null}
              />
            ))}
          </div>
        </Card>
      ))}

      <Card className="p-5">
        <h2 className="text-base font-medium">Custom CSS</h2>
        <p className="orbit-muted mt-0.5 text-sm">
          Optional escape hatch. <code>@import</code>, <code>javascript:</code> URLs and HTML tags
          are rejected by the server.
        </p>
        <Textarea
          value={draft.customCss}
          onChange={(e) => set('customCss', e.target.value)}
          rows={6}
          className="mt-3 font-mono text-xs"
          placeholder={'.card { border-radius: 4px; }'}
          maxLength={8000}
        />
        <p className="orbit-faint mt-1 text-xs">{draft.customCss.length} / 8000 characters</p>
      </Card>

      <div className="sticky bottom-4 z-10 flex justify-end">
        <Button onClick={() => void save()} loading={saving} disabled={saving}>
          Save changes
        </Button>
      </div>
    </div>
  );
}

function FieldRenderer<K extends keyof Draft>({
  fieldKey,
  draft,
  set,
  currentMediaUrl,
}: {
  fieldKey: K;
  draft: Draft;
  set<K2 extends keyof Draft>(key: K2, value: Draft[K2]): void;
  currentMediaUrl: string | null;
}) {
  const value = draft[fieldKey];

  if (fieldKey === 'chatEmptyPrompts') {
    const prompts = Array.isArray(value) ? (value as string[]) : [];
    return (
      <div className="sm:col-span-2">
        <span className="label">Suggestion prompts</span>
        <p className="orbit-faint mb-2 text-xs">
          Up to six prompts shown in the chat empty state. One per line.
        </p>
        <div className="space-y-2">
          {prompts.map((prompt, index) => (
            <Input
              key={index}
              value={prompt}
              onChange={(e) => {
                const next = [...prompts];
                next[index] = e.target.value;
                set('chatEmptyPrompts', next as Draft['chatEmptyPrompts']);
              }}
              maxLength={200}
              aria-label={`Prompt ${index + 1}`}
            />
          ))}
        </div>
        <div className="mt-2 flex gap-2">
          <Button
            variant="outline"
            size="sm"
            disabled={prompts.length >= 6}
            onClick={() =>
              set('chatEmptyPrompts', [...prompts, ''] as Draft['chatEmptyPrompts'])
            }
          >
            Add prompt
          </Button>
          {prompts.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                set('chatEmptyPrompts', prompts.slice(0, -1) as Draft['chatEmptyPrompts'])
              }
            >
              Remove last
            </Button>
          )}
        </div>
      </div>
    );
  }

  if (fieldKey === 'buttonStyle' || fieldKey === 'fontChoice' || fieldKey === 'defaultTheme') {
    const options: Record<string, Array<{ value: string; label: string }>> = {
      buttonStyle: [
        { value: 'solid', label: 'Solid' },
        { value: 'outline', label: 'Outline' },
        { value: 'ghost', label: 'Ghost' },
      ],
      fontChoice: [
        { value: 'inter', label: 'Inter (default)' },
        { value: 'system', label: 'System UI' },
        { value: 'serif', label: 'Serif' },
        { value: 'mono', label: 'Monospace' },
        { value: 'grotesk', label: 'Grotesk' },
      ],
      defaultTheme: [
        { value: 'dark', label: 'Dark' },
        { value: 'light', label: 'Light' },
        { value: 'system', label: 'Match the system' },
      ],
    };
    const list = options[String(fieldKey)] ?? [];
    return (
      <Field label={LABELS[String(fieldKey)]} htmlFor={String(fieldKey)}>
        <Select
          id={String(fieldKey)}
          value={String(value)}
          onChange={(e) => set(fieldKey, e.target.value as Draft[K])}
        >
          {list.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>
      </Field>
    );
  }

  if (fieldKey === 'musicVolume' || fieldKey === 'backgroundOverlayOpacity') {
    const numeric = Number(value);
    return (
      <Field
        label={LABELS[String(fieldKey)]}
        htmlFor={String(fieldKey)}
        hint={fieldKey === 'musicVolume' ? `${Math.round(numeric * 100)}%` : 'Dims the media so text stays readable.'}
      >
        <input
          id={String(fieldKey)}
          type="range"
          min={0}
          max={1}
          step={0.05}
          value={numeric}
          onChange={(e) => set(fieldKey, Number(e.target.value) as Draft[K])}
          className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-[var(--orbit-border)] accent-[var(--orbit-accent)]"
        />
      </Field>
    );
  }

  if (typeof value === 'boolean') {
    const enabled = Boolean(value);
    return (
      <div className="flex items-center justify-between gap-3 rounded-[var(--radius-md)] border border-[var(--orbit-border)] p-3">
        <span className="text-sm">{LABELS[String(fieldKey)]}</span>
        <button
          type="button"
          role="switch"
          aria-checked={enabled}
          aria-label={LABELS[String(fieldKey)]}
          onClick={() => set(fieldKey, (!enabled) as Draft[K])}
          className="relative h-5 w-9 shrink-0 rounded-full border border-[var(--orbit-border)] transition-colors"
          style={{
            backgroundColor: enabled ? 'var(--orbit-accent)' : 'var(--orbit-surface-strong)',
          }}
        >
          <span
            className="absolute top-0.5 h-3.5 w-3.5 rounded-full bg-white transition-all"
            style={{ left: enabled ? '1.15rem' : '0.15rem' }}
            aria-hidden
          />
        </button>
      </div>
    );
  }

  if (fieldKey === 'backgroundMediaId') {
    return (
      <Field
        label="Background media"
        htmlFor="backgroundMediaId"
        hint="Pick an item uploaded in Admin → Media. Leave empty for a flat colour."
      >
        <Input
          id="backgroundMediaId"
          value={(value as string | null) ?? ''}
          onChange={(e) => set('backgroundMediaId', e.target.value || null)}
          placeholder="media id"
        />
        {currentMediaUrl && (
          <p className="orbit-faint mt-1 break-all text-xs">Currently: {currentMediaUrl}</p>
        )}
      </Field>
    );
  }

  if (fieldKey === 'backgroundType') {
    return (
      <Field label="Background type" htmlFor="backgroundType">
        <Select
          id="backgroundType"
          value={String(value)}
          onChange={(e) => set('backgroundType', e.target.value as Draft['backgroundType'])}
        >
          <option value="STATIC_COLOR">Solid colour</option>
          <option value="IMAGE">Image</option>
          <option value="GIF">Animated GIF</option>
          <option value="VIDEO">Video</option>
        </Select>
      </Field>
    );
  }

  const isColor = /Color$/.test(String(fieldKey));
  const isLong = ['landingDescription', 'chatWelcomeMessage', 'customCss'].includes(
    String(fieldKey),
  );

  return (
    <Field
      label={LABELS[String(fieldKey)]}
      htmlFor={String(fieldKey)}
      className={isLong ? 'sm:col-span-2' : undefined}
    >
      {isLong ? (
        <Textarea
          id={String(fieldKey)}
          value={String(value ?? '')}
          onChange={(e) => set(fieldKey, e.target.value as Draft[K])}
          rows={3}
        />
      ) : (
        <span className="flex gap-2">
          <Input
            id={String(fieldKey)}
            type={isColor ? 'text' : 'text'}
            value={String(value ?? '')}
            onChange={(e) => set(fieldKey, e.target.value as Draft[K])}
            maxLength={isColor ? 7 : 2048}
            className={isColor ? 'font-mono' : undefined}
          />
          {isColor && (
            <input
              type="color"
              value={String(value ?? '#000000')}
              onChange={(e) => set(fieldKey, e.target.value as Draft[K])}
              aria-label={`${LABELS[String(fieldKey)]} picker`}
              className="h-9 w-11 shrink-0 cursor-pointer rounded-md border border-[var(--orbit-border)] bg-transparent"
            />
          )}
        </span>
      )}
    </Field>
  );
}

const LABELS: Record<string, string> = {
  siteName: 'Site name',
  siteTagline: 'Tagline',
  logoUrl: 'Logo URL',
  faviconUrl: 'Favicon URL',
  footerText: 'Footer text',
  supportEmail: 'Support email',
  landingTitle: 'Hero title',
  landingDescription: 'Hero description',
  primaryCtaText: 'Primary button text',
  secondaryCtaText: 'Secondary button text',
  loginTitle: 'Sign-in title',
  loginSubtitle: 'Sign-in subtitle',
  chatWelcomeMessage: 'Chat welcome message',
  accentColor: 'Accent colour',
  backgroundColor: 'Background colour',
  textColor: 'Text colour',
  borderColor: 'Border colour',
  buttonStyle: 'Button style',
  fontChoice: 'Typography',
  defaultTheme: 'Default theme',
  backgroundType: 'Background type',
  backgroundMediaId: 'Background media',
  backgroundOverlayOpacity: 'Overlay strength',
  backgroundParallax: 'Parallax',
  musicEnabled: 'Background music',
  musicUrl: 'Music URL',
  musicVolume: 'Music volume',
  musicAutoplay: 'Autoplay music',
  customCss: 'Custom CSS',
};
