import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useSettings } from '../hooks/useSettings';
import { useToast } from '../hooks/useToast';
import { Field, Input } from '../components/ui';
import { AuthForm, AuthLayout } from './AuthLayout';
import { useAuthError } from '../hooks/useAuthError';

export function RegisterPage() {
  const { register } = useAuth();
  const { settings } = useSettings();
  const toast = useToast();
  const navigate = useNavigate();
  const toError = useAuthError();

  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);

    // Mirrors the server policy so the user gets instant feedback.
    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
      setError('Password must be at least 8 characters and contain a letter and a number.');
      return;
    }

    setLoading(true);
    try {
      const user = await register(email.trim(), username.trim(), password);
      toast.success('Account created', `You have ${user.credits} credits to start with.`);
      navigate('/chat', { replace: true });
    } catch (err) {
      setError(toError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle={settings.siteTagline}
      footer={
        <p>
          Already registered?{' '}
          <Link to="/login" className="text-[var(--orbit-accent)] hover:underline">
            Sign in
          </Link>
        </p>
      }
    >
      <AuthForm onSubmit={submit} error={error} submitLabel="Create account" loading={loading}>
        <Field label="Username" htmlFor="username" hint="Letters, numbers and underscores.">
          <Input
            id="username"
            name="username"
            autoComplete="username"
            required
            minLength={3}
            maxLength={32}
            pattern="[A-Za-z0-9_]+"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="ada"
          />
        </Field>

        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
        </Field>

        <Field
          label="Password"
          htmlFor="password"
          hint="At least 8 characters, with a letter and a number."
        >
          <Input
            id="password"
            name="password"
            type="password"
            autoComplete="new-password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
      </AuthForm>
    </AuthLayout>
  );
}
