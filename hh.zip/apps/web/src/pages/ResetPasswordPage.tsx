import { useState, type FormEvent } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { api, ApiError } from '../lib/api';
import { useToast } from '../hooks/useToast';
import { Field, Input } from '../components/ui';
import { AuthForm, AuthLayout } from './AuthLayout';

export function ResetPasswordPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const toast = useToast();
  const token = params.get('token') ?? '';

  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError('The two passwords do not match.');
      return;
    }
    if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
      setError('Password must be at least 8 characters and contain a letter and a number.');
      return;
    }

    setLoading(true);
    try {
      await api('/auth/reset-password', { method: 'POST', body: { token, password } });
      toast.success('Password updated', 'Sign in with your new password.');
      navigate('/login', { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'That reset link is no longer valid.');
    } finally {
      setLoading(false);
    }
  };

  if (token.length === 0) {
    return (
      <AuthLayout
        title="Reset link missing"
        subtitle="This page needs a reset token. Request a new link and try again."
        footer={
          <Link to="/forgot-password" className="text-[var(--orbit-accent)] hover:underline">
            Request a new link
          </Link>
        }
      >
        <Link to="/forgot-password" className="btn btn-outline w-full">
          Request a new link
        </Link>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Choose a new password"
      subtitle="This will sign you out everywhere else."
      footer={
        <Link to="/login" className="text-[var(--orbit-accent)] hover:underline">
          Back to sign in
        </Link>
      }
    >
      <AuthForm onSubmit={submit} error={error} submitLabel="Update password" loading={loading}>
        <Field
          label="New password"
          htmlFor="password"
          hint="At least 8 characters, with a letter and a number."
        >
          <Input
            id="password"
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Field>
        <Field label="Confirm password" htmlFor="confirm">
          <Input
            id="confirm"
            type="password"
            autoComplete="new-password"
            required
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
        </Field>
      </AuthForm>
    </AuthLayout>
  );
}
