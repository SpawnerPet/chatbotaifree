import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { Field, Input } from '../components/ui';
import { AuthForm, AuthLayout } from './AuthLayout';
import { useAuthError } from '../hooks/useAuthError';

export function ForgotPasswordPage() {
  const toError = useAuthError();
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [devToken, setDevToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email: email.trim() }),
      });
      if (!response.ok) {
        const body = (await response.json().catch(() => null)) as
          | { error?: { message?: string } }
          | null;
        throw new Error(body?.error?.message ?? 'Request failed.');
      }
      // Development convenience: the API returns the token so a local user is
      // not forced to dig through a mail server. Never set in production.
      if (import.meta.env.DEV) {
        setDevToken(response.headers.get('x-dev-reset-token'));
      }
      setSent(true);
    } catch (err) {
      setError(toError(err));
    } finally {
      setLoading(false);
    }
  };

  if (sent) {
    return (
      <AuthLayout
        title="Check your inbox"
        subtitle="If an account exists for that email, a reset link is on its way."
        footer={
          <Link to="/login" className="text-[var(--orbit-accent)] hover:underline">
            Back to sign in
          </Link>
        }
      >
        {devToken && (
          <div className="rounded-md border border-amber-600/30 bg-amber-500/10 p-3 text-sm">
            <p className="font-medium text-amber-600">Development mode</p>
            <p className="mt-1 break-all text-xs">{devToken}</p>
            <Link
              to={`/reset-password?token=${encodeURIComponent(devToken)}`}
              className="btn btn-outline btn-sm mt-3"
            >
              Continue to reset
            </Link>
          </div>
        )}
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      title="Reset your password"
      subtitle="Enter your email and we will send you a link to set a new password."
      footer={
        <Link to="/login" className="text-[var(--orbit-accent)] hover:underline">
          Back to sign in
        </Link>
      }
    >
      <AuthForm onSubmit={submit} error={error} submitLabel="Send reset link" loading={loading}>
        <Field label="Email" htmlFor="email">
          <Input
            id="email"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@example.com"
          />
        </Field>
      </AuthForm>
    </AuthLayout>
  );
}
