import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import type {
  ConversationDetailDTO,
  ConversationDTO,
  ModelOption,
  Paginated,
} from '@orbit/shared';
import { Menu, Pencil, Sparkles, Trash2, Wallet } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { Composer } from '../components/chat/Composer';
import { MessageItem } from '../components/chat/MessageItem';
import { Logo } from '../components/layout/Logo';
import { MusicPlayer } from '../components/layout/MusicPlayer';
import { Sidebar } from '../components/layout/Sidebar';
import { ThemeToggle } from '../components/layout/ThemeToggle';
import { Badge, Button, ErrorState, Select, Skeleton } from '../components/ui';
import { useAuth } from '../hooks/useAuth';
import { useSettings } from '../hooks/useSettings';
import { useToast } from '../hooks/useToast';
import { useChatStream } from '../hooks/useChatStream';
import { api, ApiError } from '../lib/api';
import { useDebouncedValue } from '../hooks/useDebouncedValue';

const MODEL_KEY = 'orbit.model';

export function ChatPage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const toast = useToast();
  const { settings } = useSettings();
  const { credits, refresh: refreshUser } = useAuth();

  const activeId = id ?? null;
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebouncedValue(search.trim(), 300);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [model, setModel] = useState<string>(
    () => localStorage.getItem(MODEL_KEY) ?? '',
  );
  const effectiveModel = model || searchParams.get('model') || '';

  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  // ── Data ────────────────────────────────────────────────────────────
  const conversationsQuery = useQuery({
    queryKey: ['conversations', debouncedSearch],
    queryFn: () =>
      api<Paginated<ConversationDTO>>(
        `/conversations?page=1&pageSize=50${debouncedSearch ? `&search=${encodeURIComponent(debouncedSearch)}` : ''}`,
      ),
    staleTime: 10_000,
  });

  const detailQuery = useQuery({
    queryKey: ['conversation', activeId],
    queryFn: () => api<ConversationDetailDTO>(`/conversations/${activeId}`),
    enabled: Boolean(activeId),
  });

  const modelsQuery = useQuery({
    queryKey: ['models'],
    queryFn: () =>
      api<{ models: ModelOption[]; defaultModel: string }>('/models'),
    staleTime: 5 * 60_000,
  });

  const conversations = useMemo(
    () => conversationsQuery.data?.items ?? [],
    [conversationsQuery.data],
  );

  const messages = useMemo(
    () => detailQuery.data?.messages ?? [],
    [detailQuery.data],
  );

  const models = modelsQuery.data?.models ?? [];
  const defaultModel = modelsQuery.data?.defaultModel ?? '';
  const activeModel = effectiveModel || defaultModel;

  // ── Streaming ────────────────────────────────────────────────────────
  const invalidateConversation = useCallback(
    (conversationId: string) => {
      void queryClient.invalidateQueries({ queryKey: ['conversation', conversationId] });
      void queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
    [queryClient],
  );

  const stream = useChatStream({
    onMeta(conversationId) {
      setError(null);
      // A brand new conversation gets its id from the server; adopt it so the
      // URL, the sidebar and future messages all point at the same record.
      if (conversationId !== activeId) {
        navigate(`/chat/${conversationId}`, { replace: true });
      }
      invalidateConversation(conversationId);
    },
    onDone(conversationId) {
      if (conversationId !== activeId) {
        navigate(`/chat/${conversationId}`, { replace: true });
      }
      invalidateConversation(conversationId);
      void queryClient.invalidateQueries({ queryKey: ['credits'] });
      void refreshUser();
    },
    onError(streamError) {
      setError(streamError.message);
      if (streamError.code === 'INSUFFICIENT_CREDITS') {
        toast.error('Out of credits', 'Ask an administrator to top up your balance.');
      } else {
        toast.error('The request failed', streamError.message);
      }
      if (activeId) invalidateConversation(activeId);
    },
    onAborted() {
      if (activeId) invalidateConversation(activeId);
      void refreshUser();
    },
  });

  const send = useCallback(
    (text: string) => {
      setError(null);
      void stream.send('/chat/stream', {
        message: text,
        conversationId: activeId ?? undefined,
        model: activeModel || undefined,
      });
    },
    [activeId, activeModel, stream],
  );

  const regenerate = useCallback(
    (userMessageId: string) => {
      if (!activeId) return;
      setError(null);
      void stream.send('/chat/regenerate', {
        conversationId: activeId,
        messageId: userMessageId,
        model: activeModel || undefined,
      });
    },
    [activeId, activeModel, stream],
  );

  /**
   * Regenerating restarts the turn an assistant answer belongs to, so walk
   * backwards to the user message that prompted it.
   */
  const regenerateTurn = useCallback(
    (assistantMessageId: string) => {
      const index = messages.findIndex((m) => m.id === assistantMessageId);
      for (let i = index; i >= 0; i -= 1) {
        const candidate = messages[i];
        if (candidate?.role === 'USER') {
          regenerate(candidate.id);
          return;
        }
      }
    },
    [messages, regenerate],
  );

  const editMessage = useCallback(
    async (messageId: string, content: string) => {
      if (!activeId) return;
      await api(`/messages/${messageId}`, { method: 'PATCH', body: { content } });
      invalidateConversation(activeId);
      toast.success('Message updated', 'Regenerating the reply…');
      // Re-run the assistant turn for the edited message.
      await new Promise((resolve) => setTimeout(resolve, 120));
      regenerate(messageId);
    },
    [activeId, invalidateConversation, regenerate, toast],
  );

  // ── Conversation actions ─────────────────────────────────────────────
  const newChat = useCallback(() => {
    navigate('/chat');
    setSearchParams({});
    setSidebarOpen(false);
  }, [navigate, setSearchParams]);

  const renameMutation = useMutation({
    mutationFn: (input: { id: string; title: string }) =>
      api(`/conversations/${input.id}`, { method: 'PATCH', body: { title: input.title } }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ['conversations'] });
      if (activeId) invalidateConversation(activeId);
      toast.success('Conversation renamed');
    },
    onError: () => toast.error('Could not rename the conversation'),
  });

  const deleteMutation = useMutation({
    mutationFn: (conversationId: string) =>
      api(`/conversations/${conversationId}`, { method: 'DELETE' }),
    onSuccess: (_data, conversationId) => {
      void queryClient.invalidateQueries({ queryKey: ['conversations'] });
      if (conversationId === activeId) navigate('/chat', { replace: true });
      toast.success('Conversation deleted');
    },
    onError: () => toast.error('Could not delete the conversation'),
  });

  const handleRename = useCallback(() => {
    if (!detailQuery.data) return;
    const next = window.prompt('Conversation title', detailQuery.data.title);
    if (next && next.trim().length > 0) {
      renameMutation.mutate({ id: detailQuery.data.id, title: next.trim() });
    }
  }, [detailQuery.data, renameMutation]);

  const onSearchChange = useCallback((value: string) => setSearch(value), []);

  const onModelChange = useCallback((value: string) => {
    setModel(value);
    if (value) localStorage.setItem(MODEL_KEY, value);
  }, []);

  // ── Scroll behaviour ─────────────────────────────────────────────────
  const messageCount = messages.length;
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'end' });
  }, [messageCount, stream.text, activeId]);

  useEffect(() => {
    if (stream.isBusy) return;
    if (activeId) void queryClient.invalidateQueries({ queryKey: ['credits'] });
  }, [stream.isBusy, activeId, queryClient]);

  const outOfCredits = credits <= 0;
  const lastUserMessageId = useMemo(() => {
    for (let i = messages.length - 1; i >= 0; i -= 1) {
      if (messages[i]?.role === 'USER') return messages[i]!.id;
    }
    return null;
  }, [messages]);

  return (
    <div className="flex h-full min-h-0">
      {/* Desktop sidebar --------------------------------------------- */}
      <aside
        className="hidden w-[var(--sidebar-w)] shrink-0 border-r border-[var(--orbit-border)] lg:block"
        aria-label="Conversation list"
      >
        <Sidebar
          conversations={conversations}
          isLoading={conversationsQuery.isLoading}
          search={search}
          onSearchChange={onSearchChange}
          activeId={activeId}
          onSelect={(conversationId) => navigate(`/chat/${conversationId}`)}
          onNewChat={newChat}
        />
      </aside>

      {/* Mobile drawer ----------------------------------------------- */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div
            className="absolute inset-0 bg-black/50"
            onClick={() => setSidebarOpen(false)}
            aria-hidden
          />
          <div
            className="animate-in-soft absolute inset-y-0 left-0 w-[min(20rem,85vw)] border-r border-[var(--orbit-border)] bg-[var(--orbit-bg)]"
            role="dialog"
            aria-label="Conversations"
          >
            <Sidebar
              conversations={conversations}
              isLoading={conversationsQuery.isLoading}
              search={search}
              onSearchChange={onSearchChange}
              activeId={activeId}
              onSelect={(conversationId) => navigate(`/chat/${conversationId}`)}
              onNewChat={newChat}
              onClose={() => setSidebarOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Main column -------------------------------------------------- */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-[var(--header-h)] shrink-0 items-center gap-2 border-b border-[var(--orbit-border)] px-3 sm:px-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden"
            aria-label="Open conversations"
            icon={<Menu className="h-4 w-4" aria-hidden />}
          />

          <div className="min-w-0 flex-1">
            {detailQuery.data ? (
              <div className="flex min-w-0 items-center gap-1.5">
                <h1 className="truncate text-sm font-medium">{detailQuery.data.title}</h1>
                <button
                  type="button"
                  onClick={handleRename}
                  className="btn btn-ghost btn-icon h-7 w-7"
                  aria-label="Rename conversation"
                >
                  <Pencil className="h-3.5 w-3.5" aria-hidden />
                </button>
                <button
                  type="button"
                  onClick={() => deleteMutation.mutate(activeId!)}
                  className="btn btn-ghost btn-icon h-7 w-7 text-red-500"
                  aria-label="Delete conversation"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden />
                </button>
              </div>
            ) : (
              <span className="orbit-faint text-sm">New conversation</span>
            )}
          </div>

          {models.length > 1 ? (
            <>
              <label htmlFor="model-select" className="sr-only">
                Model
              </label>
              <Select
                id="model-select"
                value={activeModel}
                onChange={(e) => onModelChange(e.target.value)}
                className="h-8 w-auto max-w-[11rem] py-1 text-xs"
              >
                {models.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.label}
                  </option>
                ))}
              </Select>
            </>
          ) : (
            <Badge tone="accent" className="hidden sm:inline-flex">
              {activeModel || 'default model'}
            </Badge>
          )}

          <div className="hidden items-center gap-1 sm:flex">
            <MusicPlayer />
            <ThemeToggle />
          </div>
        </header>

        {/* Messages --------------------------------------------------- */}
        <div ref={scrollRef} className="scroll-area min-h-0 flex-1">
          <div className="mx-auto w-full max-w-3xl px-[var(--space-page)] py-6">
            {detailQuery.isError ? (
              <ErrorState
                title="Could not load this conversation"
                message={
                  detailQuery.error instanceof ApiError
                    ? detailQuery.error.message
                    : 'Please try again.'
                }
                onRetry={() => void detailQuery.refetch()}
              />
            ) : detailQuery.isLoading && activeId ? (
              <div className="space-y-6" aria-hidden>
                <Skeleton className="ml-auto h-12 w-2/3" />
                <Skeleton className="h-24 w-full" />
                <Skeleton className="ml-auto h-10 w-1/2" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : messages.length === 0 && !stream.isBusy ? (
              <EmptyChat
                welcome={settings.chatWelcomeMessage}
                prompts={settings.chatEmptyPrompts}
                onPick={send}
                disabled={outOfCredits}
              />
            ) : (
              <div className="space-y-6">
                {messages.map((message) => (
                  <MessageItem
                    key={message.id}
                    message={message}
                    isLastAssistant={message.role === 'ASSISTANT' && message.id === messages[messages.length - 1]?.id}
                    onRegenerate={regenerateTurn}
                    onEdit={message.role === 'USER' ? editMessage : undefined}
                  />
                ))}

                {stream.isBusy && (
                  <MessageItem
                    message={{
                      id: 'streaming',
                      conversationId: activeId ?? '',
                      role: 'ASSISTANT',
                      content: stream.text || '',
                      model: activeModel || null,
                      createdAt: new Date().toISOString(),
                      updatedAt: new Date().toISOString(),
                      cost: 0,
                    }}
                    streaming
                  />
                )}

                {error && (
                  <div
                    role="alert"
                    className="rounded-md border border-red-500/30 bg-red-500/10 p-3"
                  >
                    <p className="text-sm text-red-500">{error}</p>
                    {lastUserMessageId && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="mt-2"
                        onClick={() => regenerate(lastUserMessageId)}
                      >
                        Try again
                      </Button>
                    )}
                  </div>
                )}

                <div ref={bottomRef} />
              </div>
            )}
          </div>
        </div>

        {/* Composer --------------------------------------------------- */}
        <div className="shrink-0 border-t border-[var(--orbit-border)] px-[var(--space-page)] pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3">
          <div className="mx-auto w-full max-w-3xl">
            <Composer
              credits={credits}
              isStreaming={stream.isBusy}
              isStopping={stream.status === 'stopping'}
              disabled={outOfCredits}
              disabledReason="You are out of credits — ask an admin for more."
              onSend={send}
              onStop={stream.stop}
            />
            {outOfCredits && (
              <p className="mt-1.5 flex items-center gap-1.5 text-xs text-red-500">
                <Wallet className="h-3.5 w-3.5" aria-hidden />
                You have no credits left. Chat is paused until your balance is topped up.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function EmptyChat({
  welcome,
  prompts,
  onPick,
  disabled,
}: {
  welcome: string;
  prompts: string[];
  onPick(text: string): void;
  disabled: boolean;
}) {
  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center py-10 text-center">
      <Logo showWordmark={false} className="mb-5" />
      <h2 className="max-w-md text-balance text-xl">{welcome}</h2>

      {prompts.length > 0 && (
        <ul className="mt-7 grid w-full max-w-lg gap-2">
          {prompts.slice(0, 4).map((prompt) => (
            <li key={prompt}>
              <button
                type="button"
                onClick={() => onPick(prompt)}
                disabled={disabled}
                className="orbit-surface hover:orbit-surface-strong w-full rounded-[var(--radius-md)] border border-[var(--orbit-border)] px-3.5 py-2.5 text-left text-sm transition-colors disabled:opacity-50"
              >
                <Sparkles className="mr-1.5 inline h-3.5 w-3.5 align-[-2px] opacity-60" aria-hidden />
                {prompt}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
