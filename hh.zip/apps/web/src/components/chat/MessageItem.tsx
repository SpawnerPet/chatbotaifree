import type { MessageDTO } from '@orbit/shared';
import { Check, Copy, Pencil, RefreshCw, RotateCcw, User as UserIcon } from 'lucide-react';
import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { useToast } from '../../hooks/useToast';
import { cn } from '../../lib/utils';
import { Button, Textarea } from '../ui';
import { MarkdownView } from './MarkdownView';

interface MessageItemProps {
  message: MessageDTO;
  /** True for the assistant bubble currently receiving stream deltas. */
  streaming?: boolean;
  isLastAssistant?: boolean;
  /** Regenerate the turn this assistant message belongs to. */
  onRegenerate?: (assistantMessageId: string) => void;
  onEdit?: (messageId: string, content: string) => void | Promise<void>;
  onRetry?: () => void;
  retryLabel?: string;
}

function MessageItemBase({
  message,
  streaming = false,
  isLastAssistant = false,
  onRegenerate,
  onEdit,
  onRetry,
  retryLabel = 'Retry',
}: MessageItemProps) {
  const toast = useToast();
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(message.content);
  const [saving, setSaving] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isUser = message.role === 'USER';

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      toast.success('Message copied');
      if (timer.current) clearTimeout(timer.current);
      timer.current = setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error('Could not copy', 'Your browser blocked clipboard access.');
    }
  }, [message.content, toast]);

  const startEdit = () => {
    setDraft(message.content);
    setEditing(true);
  };

  const saveEdit = async () => {
    const next = draft.trim();
    if (next.length === 0 || !onEdit) return;
    setSaving(true);
    try {
      await onEdit(message.id, next);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <article
      className={cn('group flex w-full gap-3', isUser ? 'justify-end' : 'justify-start')}
      aria-label={isUser ? 'Your message' : 'Assistant message'}
    >
      {!isUser && (
        <div
          className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[var(--orbit-border)]"
          aria-hidden
        >
          <span className="h-2 w-2 rounded-full bg-[var(--orbit-accent)]" />
        </div>
      )}

      <div className={cn('min-w-0', isUser ? 'max-w-[85%] sm:max-w-[75%]' : 'w-full max-w-3xl')}>
        {editing ? (
          <div className="space-y-2">
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              rows={Math.min(16, draft.split('\n').length + 2)}
              autoFocus
              aria-label="Edit message"
            />
            <div className="flex gap-2">
              <Button size="sm" loading={saving} onClick={saveEdit}>
                Save &amp; resend
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
                Cancel
              </Button>
            </div>
            <p className="orbit-faint text-xs">
              Saving removes the replies that came after this message.
            </p>
          </div>
        ) : (
          <>
            <div
              className={cn(
                'text-[0.9375rem] leading-relaxed',
                isUser &&
                  'orbit-surface-strong rounded-[var(--radius-lg)] rounded-tr-sm border border-[var(--orbit-border)] px-3.5 py-2.5',
              )}
            >
              {isUser ? (
                <p className="whitespace-pre-wrap break-words">{message.content}</p>
              ) : (
                <>
                  <MarkdownView
                    content={message.content}
                    className={cn(streaming && 'caret')}
                  />
                  {streaming && (
                    <span className="sr-only" role="status">
                      The assistant is typing.
                    </span>
                  )}
                </>
              )}
            </div>

            {!streaming && (
              <div
                className={cn(
                  'mt-1.5 flex items-center gap-1 opacity-0 transition-opacity focus-within:opacity-100 group-hover:opacity-100',
                  // Touch devices have no hover — keep actions always visible.
                  '[@media(hover:none)]:opacity-100',
                  isUser && 'justify-end',
                )}
              >
                <button
                  type="button"
                  onClick={copy}
                  className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors"
                  aria-label="Copy message"
                >
                  {copied ? (
                    <Check className="h-3.5 w-3.5" aria-hidden />
                  ) : (
                    <Copy className="h-3.5 w-3.5" aria-hidden />
                  )}
                  <span className="sr-only sm:not-sr-only">{copied ? 'Copied' : 'Copy'}</span>
                </button>

                {isUser && onEdit && (
                  <button
                    type="button"
                    onClick={startEdit}
                    className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors"
                    aria-label="Edit message"
                  >
                    <Pencil className="h-3.5 w-3.5" aria-hidden />
                    <span className="sr-only sm:not-sr-only">Edit</span>
                  </button>
                )}

                {!isUser && isLastAssistant && onRegenerate && (
                  <button
                    type="button"
                    onClick={() => onRegenerate(message.id)}
                    className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors"
                    aria-label="Regenerate this answer"
                  >
                    <RefreshCw className="h-3.5 w-3.5" aria-hidden />
                    <span className="sr-only sm:not-sr-only">Regenerate</span>
                  </button>
                )}

                {onRetry && !isUser && (
                  <button
                    type="button"
                    onClick={onRetry}
                    className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1 rounded px-1.5 py-1 text-xs transition-colors"
                    aria-label={retryLabel}
                  >
                    <RotateCcw className="h-3.5 w-3.5" aria-hidden />
                    <span className="sr-only sm:not-sr-only">{retryLabel}</span>
                  </button>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {isUser && (
        <div
          className="orbit-surface-strong mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[var(--orbit-border)]"
          aria-hidden
        >
          <UserIcon className="h-3.5 w-3.5" />
        </div>
      )}
    </article>
  );
}

export const MessageItem = memo(MessageItemBase);
