import { ArrowUp, Coins, Paperclip, Square } from 'lucide-react';
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { cn } from '../../lib/utils';

interface ComposerProps {
  disabled?: boolean;
  disabledReason?: string;
  credits: number;
  isStreaming: boolean;
  isStopping?: boolean;
  onSend(text: string): void;
  onStop(): void;
  placeholder?: string;
}

const MAX_HEIGHT = 200;
const MIN_HEIGHT = 24;

/**
 * Auto-growing textarea composer.
 *
 * Enter sends, Shift+Enter inserts a newline. The textarea is hidden from
 * assistive tech because the surrounding form carries the accessible name and
 * a live status region announces the send state.
 */
export function Composer({
  disabled = false,
  disabledReason,
  credits,
  isStreaming,
  isStopping = false,
  onSend,
  onStop,
  placeholder = 'Send a message…',
}: ComposerProps) {
  const [value, setValue] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useLayoutEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    const next = Math.min(MAX_HEIGHT, Math.max(MIN_HEIGHT, el.scrollHeight));
    el.style.height = `${next}px`;
    el.style.overflowY = el.scrollHeight > MAX_HEIGHT ? 'auto' : 'hidden';
  }, [value]);

  useEffect(() => {
    if (!disabled && !isStreaming) textareaRef.current?.focus();
  }, [disabled, isStreaming]);

  const submit = useCallback(() => {
    const text = value.trim();
    if (text.length === 0 || disabled || isStreaming) return;
    onSend(text);
    setValue('');
  }, [value, disabled, isStreaming, onSend]);

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === 'Enter' && !event.shiftKey && !event.nativeEvent.isComposing) {
      event.preventDefault();
      submit();
    }
  };

  const canSend = value.trim().length > 0 && !disabled && !isStreaming;

  return (
    <form
      ref={formRef}
      className="w-full"
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
    >
      <div className="orbit-surface flex items-end gap-2 rounded-[var(--radius-lg)] border border-[var(--orbit-border)] p-2 shadow-[var(--shadow-soft)] transition-colors focus-within:border-[color-mix(in_oklab,var(--orbit-border)_55%,var(--orbit-fg))]">
        {/*
          Attachment affordance. The chat pipeline is text-only today, so this
          is presentational only — it is disabled rather than a dead button.
        */}
        <button
          type="button"
          disabled
          title="File attachments are not enabled on this deployment"
          aria-label="Attach a file (not available)"
          className="btn btn-ghost btn-icon mb-0.5 hidden shrink-0 sm:inline-flex"
        >
          <Paperclip className="h-4 w-4" aria-hidden />
        </button>

        <label htmlFor="orbit-composer" className="sr-only">
          Message
        </label>
        <textarea
          id="orbit-composer"
          ref={textareaRef}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={1}
          placeholder={disabled ? (disabledReason ?? 'You are out of credits.') : placeholder}
          disabled={disabled}
          className="scroll-area max-h-[200px] min-h-[24px] w-full resize-none border-0 bg-transparent px-1 py-1.5 text-[0.9375rem] leading-relaxed outline-none placeholder:text-[var(--orbit-faint)]"
        />

        {isStreaming ? (
          <button
            type="button"
            onClick={onStop}
            disabled={isStopping}
            className="btn btn-outline btn-icon mb-0.5 shrink-0"
            aria-label="Stop generating"
            title="Stop generating"
          >
            <Square className="h-3.5 w-3.5 fill-current" aria-hidden />
          </button>
        ) : (
          <button
            type="submit"
            disabled={!canSend}
            className="btn btn-solid btn-icon mb-0.5 shrink-0"
            aria-label="Send message"
            title="Send (Enter)"
          >
            <ArrowUp className="h-4 w-4" aria-hidden />
          </button>
        )}
      </div>

      <div className="mt-1.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 px-1">
        <p className="orbit-faint text-xs">
          <kbd className="orbit-hairline rounded px-1 py-0.5 font-sans">Enter</kbd> to send ·{' '}
          <kbd className="orbit-hairline rounded px-1 py-0.5 font-sans">Shift</kbd>+
          <kbd className="orbit-hairline rounded px-1 py-0.5 font-sans">Enter</kbd> for a new line
        </p>
        <p
          className={cn(
            'inline-flex items-center gap-1 text-xs',
            credits > 0 ? 'orbit-faint' : 'text-red-500',
          )}
          aria-live="polite"
        >
          <Coins className="h-3.5 w-3.5" aria-hidden />
          <span>
            {credits} {credits === 1 ? 'credit' : 'credits'}
          </span>
        </p>
      </div>
    </form>
  );
}
