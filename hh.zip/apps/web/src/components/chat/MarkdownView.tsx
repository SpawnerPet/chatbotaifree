import { Check, Copy } from 'lucide-react';
import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import Markdown from 'react-markdown';
import rehypeHighlight from 'rehype-highlight';
import remarkGfm from 'remark-gfm';
import { useToast } from '../../hooks/useToast';
import { cn } from '../../lib/utils';

function CodeBlock({ language, children }: { language: string; children: ReactNode }) {
  const [copied, setCopied] = useState(false);
  const toast = useToast();
  const codeRef = useRef<HTMLElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  // Read the text from the DOM at click time. `children` are highlighted React
  // nodes, so stringifying them would produce "[object Object]".
  const readCode = () => codeRef.current?.textContent ?? '';

  const copy = useCallback(async () => {
    const code = readCode();
    if (code.length === 0) return;
    try {
      await navigator.clipboard.writeText(code);
    } catch {
      // Clipboard API is blocked in some contexts — fall back to a textarea.
      const area = document.createElement('textarea');
      area.value = code;
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();
      const ok = document.execCommand('copy');
      document.body.removeChild(area);
      if (!ok) {
        toast.error('Could not copy', 'Your browser blocked clipboard access.');
        return;
      }
    }
    setCopied(true);
    toast.success('Code copied');
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setCopied(false), 1800);
  }, [toast]);

  return (
    <div className="code-block">
      <div className="flex items-center justify-between border-b border-[var(--orbit-border)] px-3 py-1.5">
        <span className="orbit-faint font-mono text-[11px] uppercase tracking-wider">
          {language || 'text'}
        </span>
        <button
          type="button"
          onClick={() => void copy()}
          className="orbit-faint hover:text-[var(--orbit-fg)] inline-flex items-center gap-1.5 text-xs transition-colors"
          aria-label={copied ? 'Code copied' : 'Copy code to clipboard'}
        >
          {copied ? (
            <Check className="h-3.5 w-3.5" aria-hidden />
          ) : (
            <Copy className="h-3.5 w-3.5" aria-hidden />
          )}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre>
        <code
          ref={codeRef}
          className={cn('hljs', language && `language-${language}`)}
        >
          {children}
        </code>
      </pre>
    </div>
  );
}

/**
 * Markdown renderer for assistant output.
 *
 * Raw HTML is intentionally NOT enabled (react-markdown escapes it by default),
 * which is the primary XSS defence for model-generated text. External links
 * get rel="noopener noreferrer".
 */
export function MarkdownView({ content, className }: { content: string; className?: string }) {
  return (
    <div className={cn('md', className)}>
      <Markdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[[rehypeHighlight, { detect: true, ignoreMissing: true }]]}
        components={{
          a({ href, children, ...rest }) {
            const external = Boolean(href && /^https?:\/\//i.test(href));
            return (
              <a
                href={href}
                {...rest}
                {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
              >
                {children as ReactNode}
              </a>
            );
          },
          pre({ children }) {
            // The `code` renderer below produces the CodeBlock; unwrap here.
            return <>{children}</>;
          },
          code({ className: codeClassName, children, ...rest }) {
            const language = /language-([\w+#-]+)/.exec(codeClassName ?? '')?.[1];
            const text = typeof children === 'string' ? children : '';
            const isBlock = Boolean(language) || text.includes('\n');

            if (!isBlock) {
              return (
                <code className={codeClassName} {...rest}>
                  {children}
                </code>
              );
            }
            // Pass the highlighted children straight through — rebuilding the
            // block from a plain string would discard every highlight span
            // rehype-highlight produced.
            return <CodeBlock language={language ?? ''}>{children}</CodeBlock>;
          },
        }}
      >
        {content}
      </Markdown>
    </div>
  );
}
