import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
  /** Changing this resets the boundary — e.g. pass the route path. */
  resetKey?: string;
  label?: string;
}

interface State {
  error: Error | null;
}

/**
 * Catches render-time crashes so a single broken component never blanks the
 * whole app. The user gets a recoverable panel instead of a white screen.
 */
export class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidUpdate(previous: Props): void {
    if (this.state.error && previous.resetKey !== this.props.resetKey) {
      this.setState({ error: null });
    }
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    // Kept in the console for developers; never contains user secrets.
    console.error('React error boundary caught:', error.message, info.componentStack);
  }

  private reset = () => this.setState({ error: null });

  render(): ReactNode {
    const { error } = this.state;
    if (!error) return this.props.children;

    return (
      <div className="flex min-h-[60vh] items-center justify-center p-6">
        <div className="card max-w-md p-6 text-center">
          <AlertTriangle className="mx-auto h-6 w-6 text-red-500" aria-hidden />
          <h2 className="mt-3 text-base font-medium">
            {this.props.label ?? 'This part of the app crashed'}
          </h2>
          <p className="orbit-muted mt-1.5 text-sm leading-relaxed">
            The rest of the app still works. You can retry this view.
          </p>
          <div className="mt-4 flex justify-center gap-2">
            <button type="button" className="btn btn-solid" onClick={this.reset}>
              Try again
            </button>
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => window.location.assign('/')}
            >
              Go home
            </button>
          </div>
          {import.meta.env.DEV && (
            <pre className="orbit-faint mt-4 max-h-32 overflow-auto whitespace-pre-wrap text-left text-xs">
              {error.message}
            </pre>
          )}
        </div>
      </div>
    );
  }
}
