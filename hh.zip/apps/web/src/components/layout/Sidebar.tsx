import {
  ChevronsLeft,
  LogOut,
  MessageSquare,
  MoreHorizontal,
  Pencil,
  Plus,
  Search,
  Settings as SettingsIcon,
  Shield,
  Trash2,
  X,
} from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import type { ConversationDTO } from '@orbit/shared';
import { useAuth } from '../../hooks/useAuth';
import { useToast } from '../../hooks/useToast';
import { api } from '../../lib/api';
import { cn, formatRelative, initials } from '../../lib/utils';
import { Button, EmptyState, Skeleton } from '../ui';
import { Logo } from './Logo';

interface SidebarProps {
  conversations: ConversationDTO[];
  isLoading: boolean;
  search: string;
  onSearchChange(value: string): void;
  activeId: string | null;
  onSelect(id: string): void;
  onNewChat(): void;
  onClose?(): void;
}

export function Sidebar({
  conversations,
  isLoading,
  search,
  onSearchChange,
  activeId,
  onSelect,
  onNewChat,
  onClose,
}: SidebarProps) {
  const { user, isAdmin, logout } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [renaming, setRenaming] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!menuFor) return;
    const onClick = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) setMenuFor(null);
    };
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuFor(null);
    };
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [menuFor]);

  const startRename = (conversation: ConversationDTO) => {
    setMenuFor(null);
    setRenaming(conversation.id);
    setDraft(conversation.title);
  };

  const commitRename = async (id: string) => {
    const title = draft.trim();
    setRenaming(null);
    if (title.length === 0) return;
    try {
      await api(`/conversations/${id}`, { method: 'PATCH', body: { title } });
      toast.success('Conversation renamed');
    } catch {
      toast.error('Could not rename', 'The conversation was not changed.');
    }
  };

  const remove = async (id: string) => {
    setMenuFor(null);
    try {
      await api(`/conversations/${id}`, { method: 'DELETE' });
      toast.success('Conversation deleted');
    } catch {
      toast.error('Could not delete', 'The conversation was still there.');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/', { replace: true });
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex items-center justify-between gap-2 border-b border-[var(--orbit-border)] px-3 py-3">
        <NavLink to="/chat" className="min-w-0" aria-label="Go to chat">
          <Logo />
        </NavLink>
        {onClose && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            aria-label="Close sidebar"
            icon={<X className="h-4 w-4" aria-hidden />}
          />
        )}
      </div>

      <div className="space-y-2 p-3">
        <Button onClick={onNewChat} className="w-full justify-start" icon={<Plus className="h-4 w-4" aria-hidden />}>
          New chat
        </Button>

        <div className="relative">
          <Search
            className="orbit-faint pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2"
            aria-hidden
          />
          <label htmlFor="conversation-search" className="sr-only">
            Search conversations
          </label>
          <input
            id="conversation-search"
            type="search"
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search conversations"
            className="field pl-8"
            autoComplete="off"
          />
        </div>
      </div>

      <nav className="scroll-area min-h-0 flex-1 px-2 pb-2" aria-label="Conversations">
        {isLoading ? (
          <div className="space-y-1.5 px-1" aria-hidden>
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : conversations.length === 0 ? (
          <EmptyState
            icon={<MessageSquare className="h-5 w-5" aria-hidden />}
            title={search ? 'No matches' : 'No conversations yet'}
            description={
              search ? 'Try a different word.' : 'Start a chat and it will appear here.'
            }
            className="py-8"
          />
        ) : (
          <ul className="space-y-0.5">
            {conversations.map((conversation) => {
              const isActive = conversation.id === activeId;
              if (renaming === conversation.id) {
                return (
                  <li key={conversation.id}>
                    <input
                      className="field"
                      value={draft}
                      autoFocus
                      onChange={(e) => setDraft(e.target.value)}
                      onBlur={() => void commitRename(conversation.id)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          void commitRename(conversation.id);
                        }
                        if (e.key === 'Escape') setRenaming(null);
                      }}
                      aria-label="Conversation title"
                    />
                  </li>
                );
              }

              return (
                <li key={conversation.id} className="relative">
                  <div
                    className={cn(
                      'group flex items-center gap-1 rounded-md pr-1 transition-colors',
                      isActive
                        ? 'orbit-surface-strong'
                        : 'hover:orbit-surface hover:bg-[color-mix(in_oklab,var(--orbit-surface)_60%,var(--orbit-fg))]',
                    )}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onSelect(conversation.id);
                        onClose?.();
                      }}
                      className="min-w-0 flex-1 px-2.5 py-2 text-left"
                      aria-current={isActive ? 'page' : undefined}
                    >
                      <span className="block truncate text-sm font-medium">
                        {conversation.title}
                      </span>
                      <span className="orbit-faint block truncate text-xs">
                        {formatRelative(conversation.updatedAt)}
                        {conversation.messageCount > 0 && ` · ${conversation.messageCount} messages`}
                      </span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setMenuFor(menuFor === conversation.id ? null : conversation.id)}
                      className="btn btn-ghost btn-icon h-7 w-7 opacity-0 transition-opacity focus:opacity-100 group-hover:opacity-100 [@media(hover:none)]:opacity-100"
                      aria-label={`Actions for ${conversation.title}`}
                      aria-expanded={menuFor === conversation.id}
                    >
                      <MoreHorizontal className="h-4 w-4" aria-hidden />
                    </button>
                  </div>

                  {menuFor === conversation.id && (
                    <div
                      ref={menuRef}
                      className="card animate-in-soft absolute right-1 top-full z-20 mt-1 w-44 overflow-hidden p-1 shadow-[var(--shadow-lift)]"
                      role="menu"
                    >
                      <button
                        type="button"
                        role="menuitem"
                        onClick={() => startRename(conversation)}
                        className="hover:orbit-surface-strong flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm"
                      >
                        <Pencil className="h-3.5 w-3.5" aria-hidden />
                        Rename
                      </button>
                      <button
                        type="button"
                        role="menuitem"
                        onClick={() => void remove(conversation.id)}
                        className="flex w-full items-center gap-2 rounded px-2 py-1.5 text-left text-sm text-red-500 hover:bg-red-500/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden />
                        Delete
                      </button>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </nav>

      <div className="border-t border-[var(--orbit-border)] p-2">
        {isAdmin && (
          <NavLink
            to="/admin"
            onClick={onClose}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-2 rounded-md px-2.5 py-2 text-sm transition-colors',
                isActive ? 'orbit-surface-strong font-medium' : 'orbit-muted hover:orbit-surface-strong',
              )
            }
          >
            <Shield className="h-4 w-4" aria-hidden />
            Admin
          </NavLink>
        )}

        <NavLink
          to="/settings"
          onClick={onClose}
          className={({ isActive }) =>
            cn(
              'flex items-center gap-2 rounded-md px-2.5 py-2 text-sm transition-colors',
              isActive ? 'orbit-surface-strong font-medium' : 'orbit-muted hover:orbit-surface-strong',
            )
          }
        >
          <SettingsIcon className="h-4 w-4" aria-hidden />
          Settings
        </NavLink>

        <div className="mt-1 flex items-center gap-2 rounded-md px-2 py-2">
          <span
            className="orbit-surface-strong flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[var(--orbit-border)] text-[11px] font-semibold"
            aria-hidden
          >
            {user?.avatar ? (
              <img src={user.avatar} alt="" className="h-full w-full rounded-full object-cover" />
            ) : (
              initials(user?.username ?? '?')
            )}
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-medium">{user?.username}</p>
            <p className="orbit-faint truncate text-xs">{user?.credits} credits</p>
          </div>
          <button
            type="button"
            onClick={() => void handleLogout()}
            className="btn btn-ghost btn-icon h-8 w-8"
            aria-label="Sign out"
            title="Sign out"
          >
            <LogOut className="h-4 w-4" aria-hidden />
          </button>
        </div>
      </div>
    </div>
  );
}

export function SidebarCollapseHint({ onClick }: { onClick(): void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="btn btn-ghost btn-icon lg:hidden"
      aria-label="Open sidebar"
    >
      <ChevronsLeft className="h-4 w-4 rotate-180" aria-hidden />
    </button>
  );
}
