import { Moon, Sun } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { THEME_STORAGE_KEY } from '../../context/SettingsContext';

type Mode = 'dark' | 'light';

/** Persisted light/dark switch. Defaults to the admin-configured theme. */
export function ThemeToggle({ className }: { className?: string }) {
  const [mode, setMode] = useState<Mode>(() => {
    const stored = localStorage.getItem(THEME_STORAGE_KEY);
    if (stored === 'dark' || stored === 'light') return stored;
    return document.documentElement.dataset.theme === 'light' ? 'light' : 'dark';
  });

  useEffect(() => {
    document.documentElement.dataset.theme = mode;
    document.documentElement.classList.toggle('dark', mode === 'dark');
    localStorage.setItem(THEME_STORAGE_KEY, mode);
  }, [mode]);

  const toggle = useCallback(() => setMode((prev) => (prev === 'dark' ? 'light' : 'dark')), []);

  return (
    <button
      type="button"
      onClick={toggle}
      className={`btn btn-ghost btn-icon ${className ?? ''}`}
      aria-label={mode === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
      title={mode === 'dark' ? 'Light theme' : 'Dark theme'}
    >
      {mode === 'dark' ? (
        <Sun className="h-4 w-4" aria-hidden />
      ) : (
        <Moon className="h-4 w-4" aria-hidden />
      )}
    </button>
  );
}
