import { useEffect, useRef } from 'react';
import { useSettings } from '../../hooks/useSettings';

const isSmallScreen = () =>
  typeof window !== 'undefined' && window.matchMedia('(max-width: 767px)').matches;

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/**
 * Renders the admin-configured page background.
 *
 *  - STATIC_COLOR → the flat brand colour (no extra element).
 *  - IMAGE / GIF   → a single <img>.
 *  - VIDEO         → muted, looping, playsinline, with a static poster on
 *                    small screens and when the user prefers reduced motion.
 *
 * The layer is fixed and inert so it never intercepts pointer events or causes
 * layout shift.
 */
export function BackgroundLayer() {
  const { settings, background } = useSettings();
  const videoRef = useRef<HTMLVideoElement>(null);

  const type = settings.backgroundType;
  const overlay = settings.backgroundOverlayOpacity;

  useEffect(() => {
    if (type !== 'VIDEO' || !videoRef.current) return;
    const video = videoRef.current;
    // Autoplay can be rejected; that is fine — the poster stays visible.
    void video.play().catch(() => undefined);
  }, [type, background]);

  if (type === 'STATIC_COLOR' || !background) return null;

  const shouldFallbackToImage =
    type === 'VIDEO' && (isSmallScreen() || prefersReducedMotion());

  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden" aria-hidden>
      {type === 'VIDEO' && !shouldFallbackToImage ? (
        <video
          ref={videoRef}
          className="h-full w-full object-cover"
          src={background}
          poster={settings.backgroundPosterUrl ?? undefined}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          tabIndex={-1}
        />
      ) : (
        <img
          src={background}
          alt=""
          className="h-full w-full object-cover"
          loading="lazy"
          decoding="async"
        />
      )}

      {overlay > 0 && (
        <div
          className="absolute inset-0"
          style={{ backgroundColor: `rgb(0 0 0 / ${overlay})` }}
        />
      )}
    </div>
  );
}
