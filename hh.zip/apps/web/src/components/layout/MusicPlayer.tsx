import { Music2, Volume2, VolumeX } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useSettings } from '../../hooks/useSettings';

/**
 * Background music control.
 *
 * Browsers block audio autoplay without a user gesture, so the player never
 * forces sound: it starts paused unless a previous visit already granted
 * playback, in which case the admin's autoplay preference is honoured. Volume
 * and mute state persist in localStorage.
 */
export function MusicPlayer() {
  const { music, settings } = useSettings();
  const audioRef = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(() => localStorage.getItem('orbit.music.muted') === '1');
  const [volume, setVolume] = useState(() => {
    const stored = Number(localStorage.getItem('orbit.music.volume'));
    return Number.isFinite(stored) && stored >= 0 && stored <= 1 ? stored : settings.musicVolume;
  });
  const gestureRef = useRef(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio || !music) return;
    audio.volume = muted ? 0 : volume;
  }, [volume, muted, music]);

  const tryAutoplay = useCallback(() => {
    if (!settings.musicAutoplay || !music || gestureRef.current) return;
    const audio = audioRef.current;
    if (!audio) return;
    void audio
      .play()
      .then(() => setPlaying(true))
      .catch(() => {
        // Blocked by the browser — stay paused and let the user start it.
        setPlaying(false);
      });
  }, [music, settings.musicAutoplay]);

  useEffect(() => {
    tryAutoplay();
    // A single user gesture anywhere unlocks autoplay for the rest of the session.
    const unlock = () => {
      gestureRef.current = true;
      tryAutoplay();
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, [tryAutoplay]);

  if (!music) return null;

  const toggle = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (audio.paused) {
      void audio.play().then(() => setPlaying(true)).catch(() => undefined);
    } else {
      audio.pause();
      setPlaying(false);
    }
  };

  const toggleMute = () => {
    setMuted((prev) => {
      const next = !prev;
      localStorage.setItem('orbit.music.muted', next ? '1' : '0');
      return next;
    });
  };

  const changeVolume = (value: number) => {
    setVolume(value);
    localStorage.setItem('orbit.music.volume', String(value));
    if (value > 0 && muted) {
      setMuted(false);
      localStorage.setItem('orbit.music.muted', '0');
    }
  };

  return (
    <div
      className="orbit-surface flex items-center gap-1 rounded-full border border-[var(--orbit-border)] p-1"
      role="group"
      aria-label="Background music"
    >
      <audio ref={audioRef} src={music} loop preload="none" />

      <button
        type="button"
        onClick={toggle}
        className="btn btn-ghost btn-icon h-7 w-7"
        aria-label={playing ? 'Pause background music' : 'Play background music'}
        aria-pressed={playing}
      >
        <Music2 className="h-3.5 w-3.5" aria-hidden />
      </button>

      <button
        type="button"
        onClick={toggleMute}
        className="btn btn-ghost btn-icon h-7 w-7"
        aria-label={muted ? 'Unmute' : 'Mute'}
        aria-pressed={muted}
      >
        {muted ? (
          <VolumeX className="h-3.5 w-3.5" aria-hidden />
        ) : (
          <Volume2 className="h-3.5 w-3.5" aria-hidden />
        )}
      </button>

      <label htmlFor="orbit-music-volume" className="sr-only">
        Music volume
      </label>
      <input
        id="orbit-music-volume"
        type="range"
        min={0}
        max={1}
        step={0.05}
        value={muted ? 0 : volume}
        onChange={(e) => changeVolume(Number(e.target.value))}
        className="h-1 w-16 cursor-pointer appearance-none rounded-full bg-[var(--orbit-border)] accent-[var(--orbit-accent)] sm:w-24"
      />
    </div>
  );
}
