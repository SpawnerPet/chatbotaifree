import { useSettings } from '../../hooks/useSettings';
import { cn } from '../../lib/utils';

/**
 * Brand mark. Uses the admin-uploaded logo when one exists, otherwise a
 * drawn fallback so the UI is never missing an identity.
 */
export function Logo({ className, showWordmark = true }: { className?: string; showWordmark?: boolean }) {
  const { logo, settings } = useSettings();

  return (
    <span className={cn('inline-flex min-w-0 items-center gap-2', className)}>
      {logo ? (
        <img
          src={logo}
          alt={`${settings.siteName} logo`}
          className="h-7 w-7 shrink-0 rounded-md object-contain"
          width={28}
          height={28}
        />
      ) : (
        <span
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md border border-[var(--orbit-border)]"
          aria-hidden
        >
          <svg viewBox="0 0 32 32" className="h-4 w-4">
            <circle cx="16" cy="16" r="11" fill="none" stroke="var(--orbit-accent)" strokeWidth="2" />
            <circle cx="16" cy="5" r="3" fill="var(--orbit-accent)" />
          </svg>
        </span>
      )}
      {showWordmark && (
        <span className="truncate text-sm font-semibold tracking-tight">{settings.siteName}</span>
      )}
    </span>
  );
}
