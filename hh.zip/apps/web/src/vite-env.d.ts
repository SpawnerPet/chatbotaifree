/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Absolute base URL of the API. Empty means same-origin / dev proxy. */
  readonly VITE_API_URL?: string;
  /** Dev-server proxy target. Never present in a production bundle. */
  readonly VITE_API_PROXY?: string;
  readonly DEV: boolean;
  readonly PROD: boolean;
  readonly MODE: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
