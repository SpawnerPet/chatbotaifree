import { ApiError } from '../lib/api';

/**
 * Turns any thrown value into a message that is safe to show a visitor.
 * Never surfaces a stack trace or a raw driver error.
 */
export function useAuthError(): (err: unknown) => string {
  return (err: unknown) => {
    if (err instanceof ApiError) return err.message;
    if (err instanceof Error) return err.message;
    return 'Something went wrong. Please try again.';
  };
}
