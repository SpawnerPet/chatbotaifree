import { useState, type Dispatch, type SetStateAction } from 'react';

/** Minimal controlled-form state for the auth screens. */
export function useFormState<T extends Record<string, string>>(initial: T): {
  values: T;
  setValues: Dispatch<SetStateAction<T>>;
  update(key: keyof T): (event: { target: { value: string } }) => void;
} {
  const [values, setValues] = useState<T>(initial);
  const update =
    (key: keyof T) =>
    (event: { target: { value: string } }) =>
      setValues((prev) => ({ ...prev, [key]: event.target.value }));
  return { values, setValues, update };
}
