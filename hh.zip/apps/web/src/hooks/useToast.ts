import { useContext } from 'react';
import { ToastContext, type ToastContextValue } from '../context/ToastContext.js';

/** Show a toast notification. Must be used inside <ToastProvider>. */
export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used inside the matching provider.');
  return ctx;
}
