import type { StreamEvent } from '@orbit/shared';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ApiError, assetUrl } from '../lib/api';

export type StreamStatus = 'idle' | 'connecting' | 'streaming' | 'stopping';

export interface StreamCallbacks {
  /** Called once with the ids the server assigned to the new turn. */
  onMeta(convId: string, assistantMessageId: string): void;
  onDone(convId: string, assistantMessageId: string, model: string): void;
  onError(error: ApiError, refunded: boolean): void;
  onAborted(): void;
  onConversationCreated?(convId: string): void;
}

const CSRF_COOKIE = 'orbit.csrf';

function readCsrf(): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${CSRF_COOKIE}=([^;]*)`));
  return match?.[1] ? decodeURIComponent(match[1]) : null;
}

const API_BASE = (import.meta.env.VITE_API_URL ?? '').replace(/\/+$/, '');

/**
 * Drives POST /api/chat/stream.
 *
 * The body is read incrementally and buffered into a ref, then flushed to
 * state on an animation frame. That keeps a 2,000-token response from
 * triggering 2,000 React renders while still feeling instant.
 */
export function useChatStream(callbacks: StreamCallbacks) {
  const [status, setStatus] = useState<StreamStatus>('idle');
  const [text, setText] = useState('');

  const controllerRef = useRef<AbortController | null>(null);
  const bufferRef = useRef('');
  const frameRef = useRef<number | null>(null);
  const abortedByUserRef = useRef(false);
  const terminalRef = useRef(false);
  const callbacksRef = useRef(callbacks);
  callbacksRef.current = callbacks;

  const flush = useCallback(() => {
    frameRef.current = null;
    if (bufferRef.current.length > 0) {
      setText(bufferRef.current);
    }
  }, []);

  const scheduleFlush = useCallback(() => {
    if (frameRef.current !== null) return;
    frameRef.current = requestAnimationFrame(flush);
  }, [flush]);

  useEffect(
    () => () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
      controllerRef.current?.abort();
    },
    [],
  );

  const reset = useCallback(() => {
    bufferRef.current = '';
    setText('');
    setStatus('idle');
  }, []);

  const run = useCallback(
    async (path: string, body: Record<string, unknown>) => {
      if (controllerRef.current) return;

      const controller = new AbortController();
      controllerRef.current = controller;
      abortedByUserRef.current = false;
      terminalRef.current = false;
      bufferRef.current = '';
      setText('');
      setStatus('connecting');

      let sawConversationId: string | null = null;

      try {
        const headers: Record<string, string> = {
          'Content-Type': 'application/json',
          Accept: 'text/event-stream',
        };
        const csrf = readCsrf();
        if (csrf) headers['X-CSRF-Token'] = csrf;

        const response = await fetch(`${API_BASE}/api${path}`, {
          method: 'POST',
          headers,
          credentials: 'include',
          body: JSON.stringify(body),
          signal: controller.signal,
        });

        if (!response.ok || !response.body) {
          // Non-SSE error path: the server returned the standard JSON envelope.
          const text = await response.text();
          let code = 'UNKNOWN';
          let message = `Request failed (${response.status}).`;
          try {
            const parsed = JSON.parse(text) as { error?: { code?: string; message?: string } };
            code = parsed.error?.code ?? code;
            message = parsed.error?.message ?? message;
          } catch {
            /* keep defaults */
          }
          throw new ApiError(response.status, code, message);
        }

        setStatus('streaming');

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let sseBuffer = '';

        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          sseBuffer += decoder.decode(value, { stream: true });

          let sep = sseBuffer.indexOf('\n\n');
          while (sep !== -1) {
            const frame = sseBuffer.slice(0, sep);
            sseBuffer = sseBuffer.slice(sep + 2);
            const line = frame.split('\n').find((l) => l.startsWith('data:'));
            if (line) {
              const payload = line.slice(5).trim();
              if (payload.length > 0) {
                let event: StreamEvent | null = null;
                try {
                  event = JSON.parse(payload) as StreamEvent;
                } catch {
                  event = null;
                }
                if (event) handleEvent(event);
              }
            }
            sep = sseBuffer.indexOf('\n\n');
          }
        }

        // The stream ended without an explicit terminal event.
        if (!terminalRef.current) {
          terminalRef.current = true;
          callbacksRef.current.onAborted();
        }
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') {
          if (!abortedByUserRef.current) callbacksRef.current.onAborted();
        } else if (err instanceof ApiError) {
          setStatus('idle');
          callbacksRef.current.onError(err, false);
        } else {
          setStatus('idle');
          callbacksRef.current.onError(
            new ApiError(0, 'NETWORK_ERROR', 'The connection to the server was lost.'),
            false,
          );
        }
      } finally {
        if (frameRef.current !== null) {
          cancelAnimationFrame(frameRef.current);
          frameRef.current = null;
        }
        if (bufferRef.current.length > 0) setText(bufferRef.current);
        controllerRef.current = null;
        setStatus('idle');
        if (sawConversationId && callbacksRef.current.onConversationCreated) {
          callbacksRef.current.onConversationCreated(sawConversationId);
        }
      }

      function handleEvent(event: StreamEvent): void {
        switch (event.event) {
          case 'meta':
            sawConversationId = event.conversationId;
            setStatus('streaming');
            callbacksRef.current.onMeta(event.conversationId, event.assistantMessageId);
            break;
          case 'delta':
            bufferRef.current += event.text;
            scheduleFlush();
            break;
          case 'done':
            terminalRef.current = true;
            setStatus('idle');
            callbacksRef.current.onDone(
              event.conversationId,
              event.assistantMessageId,
              event.model,
            );
            break;
          case 'error':
            terminalRef.current = true;
            setStatus('idle');
            callbacksRef.current.onError(
              new ApiError(400, event.code, event.message),
              event.refunded,
            );
            break;
          case 'aborted':
            terminalRef.current = true;
            setStatus('idle');
            callbacksRef.current.onAborted();
            break;
          default:
            break;
        }
      }
    },
    [scheduleFlush],
  );

  const stop = useCallback(() => {
    if (!controllerRef.current) return;
    abortedByUserRef.current = true;
    setStatus('stopping');
    controllerRef.current.abort();
  }, []);

  const isBusy = status !== 'idle';

  return { status, text, isBusy, send: run, stop, reset };
}

export { assetUrl };
