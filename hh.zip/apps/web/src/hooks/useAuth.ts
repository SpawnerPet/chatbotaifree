import { useContext } from 'react';
import { AuthContext, type AuthContextValue } from '../context/AuthContext.js';

/** Access the signed-in user and the auth actions. Must be used inside <AuthProvider>. */
export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside the matching provider.');
  return ctx;
}
