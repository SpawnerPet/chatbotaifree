#!/usr/bin/env bash
#
# Re-provisions the local development database inside the sandbox.
#
# The sandbox container is occasionally rebuilt, which removes the PostgreSQL
# packages along with the data directory. This script reinstalls PostgreSQL,
# starts the cluster and recreates the two databases the project uses:
#
#   orbit       — development data (the seeded admin lives here)
#   orbit_test  — the test suite; globalSetup force-resets it on every run
#
# Usage: bash scripts/dev-db.sh [--seed]

set -euo pipefail

DB_USER="${PGUSER_LOCAL:-orbit}"
DB_PASS="${PGPASSWORD_LOCAL:-orbit_dev_pw}"
DEV_DB="${DEV_DB:-orbit}"
TEST_DB="${TEST_DB:-orbit_test}"

if ! command -v pg_ctlcluster >/dev/null 2>&1; then
  echo "→ installing PostgreSQL"
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq postgresql postgresql-contrib
fi

if ! pg_lsclusters 2>/dev/null | grep -q online; then
  echo "→ starting the cluster"
  pg_ctlcluster 15 main start || true
  sleep 3
fi

pg_lsclusters

if ! su postgres -c "psql -tAc \"SELECT 1 FROM pg_roles WHERE rolname='${DB_USER}'\"" | grep -q 1; then
  echo "→ creating role ${DB_USER}"
  su postgres -c "psql -c \"CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASS}' CREATEDB;\""
fi

for db in "$DEV_DB" "$TEST_DB"; do
  if ! su postgres -c "psql -tAc \"SELECT 1 FROM pg_database WHERE datname='${db}'\"" | grep -q 1; then
    echo "→ creating database ${db}"
    su postgres -c "createdb -O ${DB_USER} ${db}"
  fi
done

echo "→ applying migrations to ${DEV_DB}"
node apps/api/scripts/with-env.mjs npx prisma migrate deploy --schema apps/api/prisma/schema.prisma

if [ "${1:-}" = "--seed" ]; then
  echo "→ seeding ${DEV_DB}"
  (cd apps/api && node scripts/with-env.mjs npx tsx prisma/seed.ts)
fi

echo "✓ ready: postgresql://${DB_USER}:***@127.0.0.1:5432/${DEV_DB}"
echo "  test database: ${TEST_DB} (reset automatically by npm test)"
